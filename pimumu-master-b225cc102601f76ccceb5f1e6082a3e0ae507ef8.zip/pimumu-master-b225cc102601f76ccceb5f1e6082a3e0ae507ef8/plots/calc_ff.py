#! /usr/bin/env python
from value import Value

jpsimumu = Value(0.05, 0)
bujpsipi = Value(1.3E-3, 0.05E-3) * jpsimumu
bdjpsikst = Value(1.3E-3, 0.05E-3) * jpsimumu
bujpsik = Value(1.3E-3, 0.05E-3) * jpsimumu
bsjpsif0 = Value(1.3E-4, 0.5E-5) * jpsimumu

print bsjpsif0 / bujpsik

bupimumu = Value(2.2E-8, 0.5E-8) 
bdkstmumu = Value(1.06E-6, 0.05E-6) 
bukmumu = Value(4.4E-7, 0.7E-7) 



import ROOT
ROOT.gROOT.SetBatch(True)
from lhcbStyle import setLHCbStyle
setLHCbStyle()
#bspipimumu = 
tbuf = ROOT.TFile( "~/data/Pimm/partreco/with_bdt_bujpsix_mc12_newpid_updated.root")
tbsf = ROOT.TFile( "~/data/Pimm/partreco/with_bdt_bsjpsix_mc12_newpid_updated.root")
tbdf = ROOT.TFile( "~/data/Pimm/partreco/with_bdt_bdjpsix_mc12_newpid_updated.root")

tbut = tbuf.Get("DecayTree")
tbdt = tbdf.Get("DecayTree")
tbst = tbsf.Get("DecayTree")


selstring = "(B_BKGCAT==50 && abs(hadron_TRUEID)<321 && B_M>5000)"

bunstrip = Value(tbut.GetEntries(selstring), -1)
bdnstrip = Value(tbdt.GetEntries(selstring), -1)
bsnstrip = Value(tbst.GetEntries(selstring), -1)



buf = ROOT.TFile( "~/data/Pimm/partreco/with_bdt_bujpsix_mc12_newpid_updated_presel_offsel.root")
bsf = ROOT.TFile( "~/data/Pimm/partreco/with_bdt_bsjpsix_mc12_newpid_updated_presel_offsel.root")
bdf = ROOT.TFile( "~/data/Pimm/partreco/with_bdt_bdjpsix_mc12_newpid_updated_presel_offsel.root")

but = buf.Get("DecayTree")
bst = bsf.Get("DecayTree")
bdt = bdf.Get("DecayTree")

bunsel = Value(but.GetEntries(selstring), -1)
bdnsel = Value(bdt.GetEntries(selstring), -1)
bsnsel = Value(bst.GetEntries(selstring), -1)

print bunstrip, bunsel, bunsel / bunstrip
print bdnstrip, bdnsel, bdnsel / bdnstrip
print bsnstrip, bsnsel, bsnsel / bsnstrip

jpsipieff = Value(0.014, 0.001) / Value(0.16) / Value(0.20)

print jpsipieff

h1 = ROOT.TH1D("h1", "", 40, 5000, 5400)
h2 = ROOT.TH1D("h2", "", 40, 5000, 5400)
h3 = ROOT.TH1D("h3", "", 40, 5000, 5400)

but.Draw("B_M>>h1", selstring, "goff")
bst.Draw("B_M>>h2", selstring+"*0.33", "goff")
bdt.Draw("B_M>>h3", selstring, "goff")

h2.SetLineColor(2)
h2.SetMarkerColor(2)
h3.SetLineColor(4)
h3.SetMarkerColor(4)

maxval = max(h1.GetBinContent(h1.GetMaximumBin()), \
        h2.GetBinContent(h2.GetMaximumBin()))

h1.GetYaxis().SetRangeUser(0, 2.5*maxval)
h1.GetXaxis().SetTitle("m(#pi#mu#mu) [MeV]")
h1.GetYaxis().SetTitle("events")

c = ROOT.TCanvas("c", "", 800, 600)
h1.Draw("e")
h2.Draw("esame")
h3.Draw("esame")
c.SaveAs("partrecoplot.pdf")







