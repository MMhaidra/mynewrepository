#! /usr/bin/env python
import sys
from ROOT import TH1D, TCanvas

class config:
    def __init__(self, _name ,  _min , _max , _nbins, _name2="", _label="" , _logx=False, _logy=False) :
        self.name = _name 
        self.max = _max 
        self.min = _min  
        self.nbins = _nbins 
        self.save = False 
        self.label = _label
        self.name2 = _name2
        if self.label == "" :
            self.label = self.name
        if self.name2 == "" :
            self.name2 = self.name
        #print self.label
        self.logx = _logx
        self.logy = _logy

if __name__ == '__main__' : 
    ROOT.gROOT.SetBatch(True)
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()
    filename = "" 
    treename = "DecayTree"

    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument( "-d", "--debug", dest="test", action="store_true"
            , default=False , help="testing" ) 
    parser.add_argument(  "--fileone", dest="fileone", default="" 
            , type=str, help="filename" ) 
    parser.add_argument(  "--treeone", dest="treeone", default="DecayTree" 
            , type=str, help="treename" ) 
    parser.add_argument(  "--filetwo", dest="filetwo", default="" 
            , type=str, help="filename" ) 
    parser.add_argument(  "--treetwo", dest="treetwo", default="DecayTree" 
            , type=str, help="treename" ) 
    parser.add_argument(  "--sweightone", dest="wgtone", action="store_true"
            , default=False , help="" ) 
    parser.add_argument( "--sweighttwo", dest="wgttwo", action="store_true"
            , default=False , help="" ) 
    parser.add_argument(  "--simone", dest="simone", action="store_true"
            , default=False , help="first datafile contains sim" ) 
    parser.add_argument(  "--simtwo", dest="simtwo", action="store_true"
            , default=False , help="second datafile contains sim " ) 
    parser.add_argument( "--scale", dest="scale", action="store_true"
            , default=False , help="scale histograms" ) 
    options = parser.parse_args()
    
    f1 = ROOT.TFile( options.fileone , "READ" ) 
    if not f1.IsOpen() :
        print "file not found"
        sys.exit(9)
    t1 = f1.Get( options.treeone ) 
    if not t1 :
        print " no tree 1 "
        sys.exit(9)


    f2 = ROOT.TFile( options.filetwo , "READ" ) 
    if not f2.IsOpen() :
        print "file not found"
        sys.exit(9)
    t2 = f2.Get( options.treetwo ) 
    if not t2 :
        print " no tree 2 "
        sys.exit(9)


    #plot PID




