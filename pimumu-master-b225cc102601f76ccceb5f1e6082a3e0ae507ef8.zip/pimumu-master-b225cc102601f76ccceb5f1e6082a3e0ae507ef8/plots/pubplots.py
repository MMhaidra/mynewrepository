#! /usr/bin/env python

import os,sys,re,ROOT,time,math

topmargin = 0.1

def plottwod() :

    mass_min = 4900
    mass_max = 6100
    mumu_max = 25
    mumu_min = 0
    nbins_mass = 200
    nbins_mumu = 200
    kaname = "/home/alexshires/data/Pimm/norm/with_bdt_kmumu_tot_isoln_bdt_sel_vars.root"
    piname = "/home/alexshires/data/Pimm/norm/with_bdt_pimumu_tot_isoln_bdt_sel_vars.root"
    fe = ROOT.TFile( kaname ) 
    te = fe.Get("DecayTree")
    fm = ROOT.TFile( piname ) 
    tm = fm.Get("DecayTree")
    ROOT.gStyle.SetPadRightMargin(0.15)
    ROOT.gStyle.SetPadTopMargin(topmargin)
    ROOT.gStyle.SetOptStat(0)
    ROOT.gStyle.SetPalette(51)
    c = ROOT.TCanvas("c","",800,600)
    c.SetLogz() 
    h1 = ROOT.TH2D("he","",nbins_mass,mass_min,mass_max,nbins_mumu,mumu_min,mumu_max)
    h2 = ROOT.TH2D("hm","",nbins_mass,mass_min,mass_max,nbins_mumu,mumu_min,mumu_max)
    h1.GetXaxis().SetTitle( '#font[12]{m}(#it{K}^{+}#it{#mu}^{+}#it{#mu}^{#font[122]{-}}) [MeV/#font[12]{c}^{2}]' ) 
    h1.GetYaxis().SetTitle( '#it{q}^{2} [GeV^{2}/#it{c}^{4}]' ) 
    h2.GetXaxis().SetTitle( '#font[12]{m}(#it{#pi}^{+}#it{#mu}^{+}#it{#mu}^{#font[122]{-}}) [MeV/#font[12]{c}^{2}]' ) 
    h2.GetYaxis().SetTitle( '#it{q}^{2} [GeV^{2}/#it{c}^{4}]' ) 
    te.Draw("qsq:B_M>>he","","goff")
    tm.Draw("qsq:B_M>>hm","","goff")
    h1.Draw("colz")
    lhcbName1 = ROOT.TPaveText( 0.15, 0.80, 0.35, 0.90, "BRNDC" )
    lhcbName1.AddText("LHCb (b)"  ) 
    lhcbName1.SetFillColor(0)
    lhcbName1.SetBorderSize(0)
    lhcbName1.Draw()
    c.SaveAs("BuKmumu2D.pdf")
    h2.Draw("colz")
    lhcbName1 = ROOT.TPaveText( 0.15, 0.80, 0.35, 0.90, "BRNDC" )
    lhcbName1.AddText("LHCb (a)"  ) 
    lhcbName1.SetFillColor(0)
    lhcbName1.SetBorderSize(0)
    lhcbName1.Draw()
    c.SaveAs("BuPimumu2D.pdf")
    fe.Close()
    fm.Close()



if __name__=='__main__' :
    


    ROOT.gROOT.SetBatch(True)
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()

    plottwod()


