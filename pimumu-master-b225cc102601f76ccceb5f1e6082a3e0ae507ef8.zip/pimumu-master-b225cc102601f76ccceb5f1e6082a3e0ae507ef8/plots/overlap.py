#! /usr/bin/env python



import ROOT

from collections import Counter


#class Event( namedtuple( 'eventNumber', 'runNumber', 'KaonP', 'PionP', 'MuplusP', 'MuminusP' ) ) :
#    def __eq__(self,




def get_evts( t, old=False, ctype = 1 ) :
    """returns list of event number+runnumber"""
    n = t.GetEntries() 
    ids = []
    for i in xrange(n):
        t.GetEntry(i)
        if old and t.Bplus_M < 5175 :
            continue
        if old and t.Bplus_M > 5375 :
            continue
        if not old and t.B_M < 5175 :
            continue
        if not old and t.B_M > 5375 :
            continue
        #print i, t.eventNumber, t.runNumber
        if ctype == 1 :
            ids += [ (t.eventNumber, t.runNumber ) ]
        elif ctype == 2:
            ids += [ t.runNumber    ]
        elif ctype == 3:
            ids += [ t.BCID  ]
        #ids += [ (t.muplus_P, t.muminus_P)    ]
        #ids += [ long(t.eventNumber)    ]
    print n, len(ids)
    return ids



if __name__ == '__main__' : 

    ROOT.gROOT.SetBatch(True)
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()

    print "pimumu"

    f1 = ROOT.TFile( "~/data/Pimm/greg/PIMUMU.root")
    f2 = ROOT.TFile( "~/data/Pimm/presel/with_bdt_pimumu_tot_isoln_presel_offsel.root" )

    t1 = f1.Get("DecayTree")
    t2 = f2.Get("DecayTree")

    t1.GetEntries()
    t2.GetEntries()

    ids1 = get_evts( t1, True, 1 ) 
    ids2 = get_evts( t2, False, 1 ) 
    overlap = set(ids1) & set(ids2)
    n1 = float(len(ids1))
    n2 = float(len(ids2))
    o = float(len(overlap))
    print "1: %s, 2: %s, overlap: %s, frac1: %s, frac2: %s" \
            % (n1, n2, o, o/n1, o/n2)

    ids1 = get_evts( t1, True, 2 ) 
    ids2 = get_evts( t2, False, 2 ) 
    overlap = set(ids1) & set(ids2)
    n1 = float(len(ids1))
    n2 = float(len(ids2))
    o = float(len(overlap))
    print "1: %s, 2: %s, overlap: %s, frac1: %s, frac2: %s" \
            % (n1, n2, o, o/n1, o/n2)

    ids1 = get_evts( t1, True, 3 ) 
    ids2 = get_evts( t2, False, 3 ) 
    overlap = set(ids1) & set(ids2)
    n1 = float(len(ids1))
    n2 = float(len(ids2))
    o = float(len(overlap))
    print "1: %s, 2: %s, overlap: %s, frac1: %s, frac2: %s" \
            % (n1, n2, o, o/n1, o/n2)

    f1.Close()
    f2.Close()

    print "kmumu"
    f1 = ROOT.TFile( "~/data/Pimm/greg/KMUMU.root")
    f2 = ROOT.TFile( "~/data/Pimm/presel/with_bdt_kmumu_tot_isoln_presel_offsel.root" )

    t1 = f1.Get("DecayTree")
    t2 = f2.Get("DecayTree")
    print t1.GetEntries() ,t2.GetEntries()

    ids1 = get_evts( t1, True, 1 ) 
    ids2 = get_evts( t2, False, 1 ) 
    overlap = set(ids1) & set(ids2)
    n1 = float(len(ids1))
    n2 = float(len(ids2))
    o = float(len(overlap))
    print "1: %s, 2: %s, overlap: %s, frac1: %s, frac2: %s" \
            % (n1, n2, o, o/n1, o/n2)

    ids1 = get_evts( t1, True, 2 ) 
    ids2 = get_evts( t2, False, 2 ) 
    overlap = set(ids1) & set(ids2)
    n1 = float(len(ids1))
    n2 = float(len(ids2))
    o = float(len(overlap))
    print "1: %s, 2: %s, overlap: %s, frac1: %s, frac2: %s" \
            % (n1, n2, o, o/n1, o/n2)

    ids1 = get_evts( t1, True, 3 ) 
    ids2 = get_evts( t2, False, 3 ) 
    overlap = set(ids1) & set(ids2)
    n1 = float(len(ids1))
    n2 = float(len(ids2))
    o = float(len(overlap))
    print "1: %s, 2: %s, overlap: %s, frac1: %s, frac2: %s" \
            % (n1, n2, o, o/n1, o/n2)

    f1.Close()
    f2.Close()

    print "jpsik"
    f1 = ROOT.TFile( "~/data/Pimm/greg/OldJpsiK_presel_loosepid.root")
    f2 = ROOT.TFile( "~/data/Pimm/presel/with_bdt_jpsik_tot_isoln_presel_loosepid.root" )

    t1 = f1.Get("DecayTree")
    t2 = f2.Get("DecayTree")

    ids1 = get_evts( t1, True, 1 ) 
    ids2 = get_evts( t2, False, 1 ) 
    overlap = set(ids1) & set(ids2)
    n1 = float(len(ids1))
    n2 = float(len(ids2))
    o = float(len(overlap))
    print "1: %s, 2: %s, overlap: %s, frac1: %s, frac2: %s" \
            % (n1, n2, o, o/n1, o/n2)

    ids1 = get_evts( t1, True, 2 ) 
    ids2 = get_evts( t2, False, 2 ) 
    overlap = set(ids1) & set(ids2)
    n1 = float(len(ids1))
    n2 = float(len(ids2))
    o = float(len(overlap))
    print "1: %s, 2: %s, overlap: %s, frac1: %s, frac2: %s" \
            % (n1, n2, o, o/n1, o/n2)

    ids1 = get_evts( t1, True, 3 ) 
    ids2 = get_evts( t2, False, 3 ) 
    overlap = set(ids1) & set(ids2)
    n1 = float(len(ids1))
    n2 = float(len(ids2))
    o = float(len(overlap))
    print "1: %s, 2: %s, overlap: %s, frac1: %s, frac2: %s" \
            % (n1, n2, o, o/n1, o/n2)

    f1.Close()
    f2.Close()



    
    print "jpsipi"

    f1 = ROOT.TFile( "~/data/Pimm/greg/OldJpsiPi_presel_loosepid.root")
    f2 = ROOT.TFile( "~/data/Pimm/presel/with_bdt_jpsipi_tot_isoln_presel_loosepid.root" )

    t1 = f1.Get("DecayTree")
    t2 = f2.Get("DecayTree")

    ids1 = get_evts( t1, True, 1 ) 
    ids2 = get_evts( t2, False, 1 ) 
    overlap = set(ids1) & set(ids2)
    n1 = float(len(ids1))
    n2 = float(len(ids2))
    o = float(len(overlap))
    print "1: %s, 2: %s, overlap: %s, frac1: %s, frac2: %s" \
            % (n1, n2, o, o/n1, o/n2)

    ids1 = get_evts( t1, True, 2 ) 
    ids2 = get_evts( t2, False, 2 ) 
    overlap = set(ids1) & set(ids2)
    n1 = float(len(ids1))
    n2 = float(len(ids2))
    o = float(len(overlap))
    print "1: %s, 2: %s, overlap: %s, frac1: %s, frac2: %s" \
            % (n1, n2, o, o/n1, o/n2)

    ids1 = get_evts( t1, True, 3 ) 
    ids2 = get_evts( t2, False, 3 ) 
    overlap = set(ids1) & set(ids2)
    n1 = float(len(ids1))
    n2 = float(len(ids2))
    o = float(len(overlap))
    print "1: %s, 2: %s, overlap: %s, frac1: %s, frac2: %s" \
            % (n1, n2, o, o/n1, o/n2)

    f1.Close()
    f2.Close()





