#! /usr/bin/env python
import os,sys,re,ROOT,time,math

from ROOT import TH1D, TCanvas

class config:
    def __init__(self, _name ,  _min , _max , _nbins, _name2="", _label="" , _logx=False, _logy=False) :
        self.name = _name 
        self.max = _max 
        self.min = _min  
        self.nbins = _nbins 
        self.save = False 
        self.label = _label
        self.name2 = _name2
        if self.label == "" :
            self.label = self.name
        if self.name2 == "" :
            self.name2 = self.name
        #print self.label
        self.logx = _logx
        self.logy = _logy





colours = { 0:1, 1:4, 2:ROOT.kMagenta+2, 3:2, 4:3 }

markers = { 0:20, 1:24, 2:21, 3:24, 4:26}

names = [ "Old Data", "New Data" , "Old Simulation" , "New Simulation"]

def PlotHists( name, histlist, histnames, xaxisname="", yaxisname="", rootfile=False ) :
    c = TCanvas("c2", "", 800 , 600)
    #load plotting
    m = 0
    for h in histlist :
        m = max(m, h.GetBinContent(h.GetMaximumBin()))
    #    #h.Sumw2()
    #    h.Scale( histlist[0].Integral("width" ) / h.Integral("width") ) 
    histlist[0].GetXaxis().SetTitle(xaxisname)
    histlist[0].GetYaxis().SetTitle(yaxisname)
    histlist[0].GetYaxis().SetRangeUser(0, 1.1*m)
    histlist[0].Draw("e")
    i = 0
    ms = []
    ts = []
    from ROOT import gStyle, TMarker, TLatex
    for h in histlist :
        h.SetLineColor( colours[i] ) 
        h.SetMarkerColor( colours[i] ) 
        h.SetMarkerStyle( markers[i] ) 
        h.Draw("esame")
        if len(histlist) > 1 :
            t = TLatex()
            t.SetTextSize(0.06)
            t.SetNDC(True)
            t.DrawLatex(0.22, 0.72+i*0.05, histnames[i]) 
            ts.append(t)
            m = TMarker(0.20, 0.735+i*0.05, 20)
            m.SetMarkerColor( colours[i]) ;
            m.SetMarkerStyle( markers[i]) ;
            m.SetNDC(True)
            m.Draw()
            ms.append( m ) 
        i += 1
     
    c.SaveAs(name+".pdf")
    if rootfile :
        c.SaveAs(name+".root")
        c.SaveAs(name+".C")
        f = ROOT.TFile(name+".root","RECREATE")
        for h in histlist :
            f.WriteTObject(h) 
        f.Close()
        del f
    del c





def plot_comp( datatree, simtree, c , sel1, sel2, simone=False
        , simtwo=False, scale=False , g_canvas=None, plotfilename="", off_sel3="1.0" ) :
    #print " plot functions " , c.nbins , c.min , c.max  , g_canvas

    h1 = ROOT.TH1D("h1", "", c.nbins, c.min, c.max) 
    h2 = ROOT.TH1D("h2", "", c.nbins, c.min, c.max) 
    h3 = ROOT.TH1D("h3", "", c.nbins, c.min, c.max) 
    #get correct branches
    h1.Sumw2() 
    h2.Sumw2() 
    h3.Sumw2() 
    branch1 = c.name 
    branch2 = c.name2 
    off_sel1 = sel1
    off_sel2 = sel2

    if "ETA" in branch1  :
        part = branch1[:-4]
        branch1 = "0.5*log(("+part+"_P+"+part+"_PZ)/("+part+"_P-"+part+"_PZ))"
        branch2 = "0.5*log(("+part+"_P+"+part+"_PZ)/("+part+"_P-"+part+"_PZ))"

    print " comparing " , branch1 , branch2 #
    print  off_sel1, off_sel2, off_sel3
    n1 = 0
    n2 = 0
    #Draw histograms
    datatree.Draw( ( branch1+">>h1"), off_sel1 , "goff" ) 
    simtree.Draw( ( branch2+">>h2"),  off_sel2 , "goff" ) 
    simtree.Draw( ( branch1+">>h3"),  off_sel3 , "goff" ) 
    n1 = datatree.GetEntries( off_sel1 ) 
    n2 = simtree.GetEntries( off_sel2 ) 
    n3 = simtree.GetEntries( off_sel3 ) 
    
         
        #print " drawn second tree "  
    # 
    print n1 , n2, n3  
    if scale :
        val =  1.0 / h1.Integral( "width" )
        h1.Scale( 1.0 / h1.Integral( "width" ) )  
        h2.Scale( 1.0 / h2.Integral( "width" ) )  
        h3.Scale( 1.0 / h3.Integral( "width" ) )  

    chisq0 = h1.Chi2Test(h2, "WWCHI2/NDF") #v.s. corrsim
    chisq1 = h1.Chi2Test(h3, "WWCHI2/NDF") #v.s. prev sim
    print "chisqs: " , chisq0, chisq1

    #Plotting
    if True :
        #
        g_canvas.cd() 
        g_canvas.SetLogx(c.logx)
        g_canvas.SetLogy(c.logy)
        h1.GetXaxis( ).SetTitle( c.label ) 
        h1.GetYaxis( ).SetTitle( "" ) 
        m1 = h1.GetBinContent( h1.GetMaximumBin( ) ) 
        m2 = h2.GetBinContent( h2.GetMaximumBin( ) ) 
        m3 = h3.GetBinContent( h3.GetMaximumBin( ) ) 
        h1.GetXaxis( ).SetNdivisions( 505 ) 
        mval = max ( m1, max ( m2, m3 ) ) 
        h1.GetYaxis( ).SetRangeUser( 0,  1.1*mval  )  
        opt = "e" 
        h1.SetLineColor( ROOT.kBlack ) 
        h1.SetMarkerColor( ROOT.kBlack ) 
        h1.SetMarkerStyle( 20 ) 
        h1.Draw( opt ) 
        opt += "same" 
        h3.SetLineColor( ROOT.kMagenta+2 ) 
        h3.SetMarkerColor( ROOT.kMagenta+2 ) 
        h3.SetMarkerStyle( 21 ) 
        h3.Draw( opt ) 
        h2.SetLineColor( ROOT.kBlue ) 
        h2.SetMarkerColor( ROOT.kBlue ) 
        h2.SetMarkerStyle( 22 ) 
        h2.Draw( opt ) 
      #
   
    g_canvas.SaveAs( plotfilename) 
    g_canvas.SetLogx(False)
    g_canvas.SetLogy(False)
 
  

    if ( c.save ) : 
        PlotHists( "comp_dists_"+branch1 , [h1, h2] 
                , ["data","simulation"], c.label , "events" ) 
        h7 = TH1D("h7", "", c.nbins, c.min, c.max) 
        h7.Divide(h1, h2, 1.0, 1.0) 
        PlotHists("comp_ratio_"+branch1, [ h7 ] 
                , [ "ratio"], c.label , "ratio", True )  
        del h7
    del h1 
    del h2 


    return [ chisq0, chisq1 ] 




if __name__ == '__main__' :


    ROOT.gROOT.SetBatch(True)

    
    ROOT.gSystem.Load("libRooFit.so")
    from ROOT import RooFit, TCanvas, RooMsgService
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()
    ROOT.gStyle.SetOptStat(False)
    ROOT.gStyle.SetNdivisions(505,"y")
    ROOT.gStyle.SetNdivisions(505,"x")
    #ROOT.gStyle.SetEndErrorSize(5)
    ROOT.gStyle.SetPadTopMargin(0.1)
    ROOT.gStyle.SetPadLeftMargin(0.1)
    ROOT.gStyle.SetPadRightMargin(0.1)

    filename = "" 
    treename = "DecayTree"

    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument( "-d", "--debug", dest="test", action="store_true"
            , default=False , help="testing" ) 
    parser.add_argument(  "--fileone", dest="fileone", default="" 
            , type=str, help="filename" ) 
    parser.add_argument(  "--treeone", dest="treeone", default="DecayTree" 
            , type=str, help="treename" ) 
    parser.add_argument(  "--filetwo", dest="filetwo", default="" 
            , type=str, help="filename" ) 
    parser.add_argument(  "--treetwo", dest="treetwo", default="DecayTree" 
            , type=str, help="treename" ) 
    parser.add_argument(  "--sweightone", dest="wgtone", action="store_true"
            , default=False , help="" ) 
    parser.add_argument( "--sweighttwo", dest="wgttwo", action="store_true"
            , default=False , help="" ) 
    parser.add_argument(  "--simone", dest="simone", action="store_true"
            , default=False , help="first datafile contains sim" ) 
    parser.add_argument(  "--simtwo", dest="simtwo", action="store_true"
            , default=False , help="second datafile contains sim " ) 
    parser.add_argument( "--scale", dest="scale", action="store_true"
            , default=False , help="scale histograms" ) 
    parser.add_argument( "-r", "--ratio", dest="ratio", action="store_true"
            , default=False , help="scale histograms" ) 
    parser.add_argument( "-p", "--pid", dest="pid", action="store_true"
            , default=False , help="pid cut" ) 
    parser.add_argument( "-m", "--mass", dest="mass", action="store_true"
            , default=False , help="mass cut" ) 
    parser.add_argument( "-b", "--bdt", dest="bdt", action="store_true"
            , default=False , help="bdt cut" ) 

    options = parser.parse_args()




    f1 = ROOT.TFile( options.fileone , "READ" ) 
    if not f1.IsOpen() :
        print "file not found"
        sys.exit(9)
    t1 = f1.Get( options.treeone ) 
    if not t1 :
        print " no tree 1 "
        sys.exit(9)


    f2 = ROOT.TFile( options.filetwo , "READ" ) 
    if not f2.IsOpen() :
        print "file not found"
        sys.exit(9)
    t2 = f2.Get( options.treetwo ) 
    if not t2 :
        print " no tree 2 "
        sys.exit(9)


    jpsiksel = "B_M>5175 && B_M<5375 && Psi_M>3000 && Psi_M<3200"
    dataoffsel = jpsiksel
    simoffsel = jpsiksel

    if options.pid :
        dataoffsel = "&& Kplus_ProbNNk>0.05 && muplus_ProbNNmu>0.05"\
                +" && muminus_ProbNNmu>0.05"
        simoffsel = "&& Kplus_DataProbNNk>0.05 && muplus_DataProbNNmu>0.05"\
                +" && muminus_DataProbNNmu>0.05"
    if options.bdt :
        dataoffsel += " && BDT_4>0.0"
        simoffsel += " && BDT_4>0.0"
   
    mct = "B_BKGCAT<11"
    #choosoe weights
    if options.simone and not options.wgtone :
        tmpoffsel1 = "total_weight*("+simoffsel+")"
    elif options.wgtone and not options.simone : 
        tmpoffsel1 = "sweight*("+dataoffsel+")"
    elif options.wgtone and options.simone : 
        tmpoffsel1 = "total_weight*sweight*("+simoffsel+")"
    else :
        tmpoffsel1 = dataoffsel

    if options.simtwo and not options.wgttwo :
        tmpoffsel2 = "total_weight*("+simoffsel+")"
    elif options.wgttwo and not options.simtwo :
        tmpoffsel2 = "sweight*("+dataoffsel+")"
    elif options.wgttwo and options.simtwo :
        tmpoffsel2 = "total_weight*sweight*("+simoffsel+")"
    else :
        tmpoffsel2 = simoffsel

    offsel1 = tmpoffsel1
    offsel2 = tmpoffsel2
    offsel3 = simoffsel

    print offsel1, offsel2, offsel3


    #binning configuration
    bdt0_config  = config ( "BDT_0" , -1.0 , 1.0 , 60, "", "BDT (unweighted)" ) 
    bdt1_config  = config ( "BDT_1" , -1.0 , 1.0 , 60, "", "BDT (SPD,BPT weighted)" ) 
    bdt2_config  = config ( "BDT_2" , -1.0 , 1.0 , 60, "", "BDT (no mu PT)" ) 
    bdt3_config  = config ( "BDT_3" , -1.0 , 1.0 , 60, "", "BDT (no PVNDOF)" ) 
    bdt4_config  = config ( "BDT_4" , -1.0 , 1.0 , 60, "", "BDT " ) 
    bdt5_config  = config ( "BDT_5" , -1.0 , 1.0 , 60, "", "BDT (2D weighted, no iso, no pvndof)" ) 
    

    # b variables
    b_ipconfig = config ( "B_IP_OWNPV" ,  0.0 ,  0.1 ,  20 )
    b_ipchi2config  = config ( "B_IPCHI2_OWNPV" , 0.0 , 15 , 20 
            , "", "#it{B} IP #chi^{2}", False) 
    b_logipchi2config  = config ( "log10(B_IPCHI2_OWNPV)" , 0, 1.2, 20
            , "", "#it{B} log10 (IP #chi^{2})") 
    b_fdchi2config  = config ( "B_FDCHI2_OWNPV" , 0.0 , 30000 , 20 ,
            "", "#it{B} flight distance #chi^{2}" ) 
    b_momconfig  = config ( "B_P" , 0.0 ,  500000.0 , 50 
            , "", "B #it{p} " ) 
    b_ptconfig  = config ( "B_PT" ,  0.0 , 50000.0 , 50 
            , "", " B #it{p}_{T}") 
    b_etaconfig  = config ( "B_ETA" ,  1.0 , 6.0 , 40 
            , "", " B #eta") 
    b_vtxchi2_config  = config ( "B_ENDVERTEX_CHI2" , 0.0 , 20.0 ,  50 
            , "" , "B vtx #chi^{2}" ) 
    b_tau_config  = config ( "B_TAU" , 0.0 , 0.01 ,  40 
            , "", "#tau_{B}" ) 
    b_ownpvndof_config  = config ( "B_OWNPV_NDOF" , 0.0 , 250.0 ,  250 ) 
    b_m_config  = config ( "B_M" , 5100, 5500 ,  40 
            , "" , "m_{B}" ) 
    b_dira_config  = config ( "B_DIRA_OWNPV" , 0.9999 , 1. 
            ,  40, "" , "B cos(#theta)", False ) 

    #kaon variables
    k_ipconfig  = config ( "Kplus_IP_OWNPV" , 0.0 , 2.0 , 50 ,
            "", "K^{+} IP" ) 
    k_ipchi2config  = config ( "Kplus_IPCHI2_OWNPV" , 0.0 , 10000.0 
            , 100 , "", "K^{+} IP #chi^{2}", False) 
    k_logipchi2config  = config ( "log10(Kplus_IPCHI2_OWNPV)" , 0.0 , 5.0 
            , 20 , "", "K^{+} log(IP #chi^{2})", False) 
    k_momconfig  = config ( "Kplus_P" , 0.0 , 200000.0 , 50 ,
            "", " K^{+} #it{P}" ) 
    k_ptconfig  = config ( "Kplus_PT" , 0.0 , 10000.0 , 50 , 
            "", " K^{+} #it{P}_{T}" ) 
    k_etaconfig  = config ( "Kplus_ETA" , 1.0 , 6.0 , 40 ) 
    k_pidkconfig  = config ( "Kplus_PIDK" , -20, 120, 40
            , "Kplus_DataPIDK" , "K^{+} PIDK") 
    k_pidmuconfig  = config ( "Kplus_PIDmu" , -15.0 , 15.0, 30
            , "Kplus_DataPIDmu", "K^{+} PIDmu" ) 
    k_probnnpiconfig  = config ( "Kplus_ProbNNpi" , 0.0 ,  1.0 , 20
            , "Kplus_DataProbNNpi" , "K^{+} ProbNNpi") 
    k_probnnkconfig  = config ( "Kplus_ProbNNk" , 0.05 ,  1.0 , 20  
            , "Kplus_DataProbNNk" , "K^{+} ProbNNk") 
    k_probnnmuconfig  = config ( "Kplus_ProbNNmu" , 0.0 ,  1.0 , 20  
            , "Kplus_DataProbNNmu" , "K^{+} ProbNNmu" ) 
    k_trackchi2config  = config ( "Kplus_TRACK_CHI2NDOF" , 0.0 , 3.0 , 40, "" 
            ,  "K^{+} track #chi^{2}/ndof" ) 
    #muon
    mum_momconfig  = config ( "muminus_P" , 0.0 , 100000.0 , 50 ) 
    mum_ptconfig  = config (  "muminus_PT" , 0.0 , 10000.0 , 50 ) 
    mup_momconfig = config ( "muplus_P" , 0.0 , 100000.0 , 50) 
    mup_ptconfig  = config ( "muplus_PT" , 0.0 , 10000.0 , 50 ) 
    mum_pidkconfig  = config ( "muminus_PIDK" , -150.0 , 150.0 , 30 
            , "muminus_DataPIDK" , "#mu^{-} PIDK" ) 
    mup_pidkconfig  = config ( "muplus_PIDK" , -150.0 , 150.0 , 30 
            , "muplus_DataPIDK" , "#mu^{+} PIDK") 
    mum_pidmuconfig  = config ( "muminus_PIDmu" , -5.0 , 15.0 , 30 
            , "muminus_DataPIDmu" , "#mu^{-} PIDmu") 
    mup_pidmuconfig = config ( "muplus_PIDmu" , -5.0 , 15.0 , 30
            , "muplus_DataPIDmu", "#mu^{+} PIDmu" ) 
    mum_probnnkconfig  = config ( "muminus_ProbNNk" , 0.0 , 1.0 , 20 
            , "muminus_DataProbNNk", "#mu^{-} ProbNNk" ) 
    mup_probnnkconfig  = config ( "muplus_ProbNNk" , 0.0 , 1.0 , 20 
            , "muplus_DataProbNNk", "#mu^{+} ProbNNk" ) 
    mum_probnnmuconfig  = config ( "muminus_ProbNNmu" , 0.05 , 1.0 , 20 
            , "muminus_DataProbNNmu", "#mu^{-} ProbNNmu" ) 
    mup_probnnmuconfig = config ( "muplus_ProbNNmu" , 0.05 , 1.0 , 20
            , "muplus_DataProbNNmu", "#mu^{+} ProbNNmu" ) 
    mum_probnnpiconfig  = config ( "muminus_ProbNNpi" , 0.0 , 1.0 , 20 
            , "muminus_DataProbNNpi" ) 
    mup_probnnpiconfig  = config ( "muplus_ProbNNpi" , 0.0 , 1.0 , 20 
            , "muplus_DataProbNNpi" ) 

    mup_etaconfig  = config ( "muplus_ETA" , 1.0 , 6.0 , 40 , ""  , "#mu^{+} #eta") 
    mum_etaconfig  = config ( "muminus_ETA" , 1.0 , 6.0 , 40 , "" , "#mu^{-} #eta") 

    mup_ipchi2config  = config ( "muplus_IPCHI2_OWNPV" , 0.0 , 10000.0 , 50 
            , "", "#mu^{+} IP #chi^{2}", True) 
    mum_ipchi2config  = config ( "muminus_IPCHI2_OWNPV" , 0.0 , 10000.0 , 50 
            , "", "#mu^{-} IP #chi^{2}", True) 
    mup_logipchi2config  = config ( "log10(muplus_IPCHI2_OWNPV)" , 0.0 , 5.0 
            , 20 , "", "#mu^{+} log(IP #chi^{2})", False) 
    mum_logipchi2config  = config ( "log10(muminus_IPCHI2_OWNPV)" , 0.0 , 5.0 
            , 20 , "", "#mu^{-} log(IP #chi^{2})", False) 
    mup_trackchi2config  = config ( "muplus_TRACK_CHI2NDOF" , 0.0 , 3.0 , 40 
            , "", "#mu^{+} track #chi^{2}/ndof") 
    mum_trackchi2config  = config ( "muminus_TRACK_CHI2NDOF" , 0.0 , 3.0 , 40 
            , "", "#mu^{-} track #chi^{2}/ndof") 

    m_dptconfig  = config ( "abs(muplus_P-muminus_P)" , 0 , 1E5 , 50, ""
            , "|p_{#mu^{+}} - p_{#mu^{-}}|" ) 
    
    isoh_config  = config ( "B_ISOLATION_BDT_Hard" , -1 , 1 , 40 ) 
    isos_config  = config ( "B_ISOLATION_BDT_Soft" , -1 , 1 , 40 ) 
    
    npvs_config  = config ( "nPV" , 0.0 , 10.0 ,  10 ) 
    ntracks_config  = config  ( "nTracks" ,  0 , 600 , 40 ) 
    spdhits_config = config ( "nSPDHits", 0, 600, 40 ) 



    #if options.ratio :
        #ep_momconfig.save = True
        #em_momconfig.save = True
        #b_ptconfig.save = True
        #spdhits_config.save = True
        #k_ptconfig.save = True
        #mu_aptconfig.save = True
        #e_apconfig.save = True
        #mu_apconfig.save = True
        #ep_ptconfig.save = True
        #em_ptconfig.save = True
        #mup_ptconfig.save = True
        #mum_ptconfig.save = True
        #ep_ptconfig.save = True

    configvec = []

    #configvec += [ b_m_config] 
    #configvec += [ b_fm_config] 
    configvec += [ b_ipchi2config] 
    configvec += [ b_fdchi2config] 
    configvec += [ b_vtxchi2_config] 
    configvec += [ b_momconfig] 
    configvec += [ b_ptconfig] 
    #configvec += [ b_etaconfig] 
    configvec += [ b_ownpvndof_config] 
    #configvec += [ b_dira_config ]

    #configvec += [ k_ipconfig]
    configvec += [ k_momconfig] 
    configvec += [ k_ptconfig] 
    #configvec += [ k_etaconfig] 
    configvec += [ k_pidkconfig] 
    #configvec += [ k_probnnkconfig] 
    #configvec += [ k_pideconfig] 
    #configvec += [ k_pidmuconfig] 
    #configvec += [ k_pidpconfig] 
    configvec += [ k_ipchi2config]
    configvec += [ k_trackchi2config]

    
    configvec += [ mum_momconfig] 
    configvec += [ mum_ptconfig] 
    configvec += [ mup_momconfig] 
    configvec += [ mup_ptconfig] 
        
    configvec += [ mum_pidmuconfig ]
    configvec += [ mup_pidmuconfig ]
    configvec += [ mum_probnnmuconfig ]
    configvec += [ mup_probnnmuconfig ]

    configvec += [ mup_ipchi2config]
    configvec += [ mum_ipchi2config]
    #configvec += [ mup_trackchi2config]
    #configvec += [ mum_trackchi2config]

    configvec += [ m_dptconfig] 
    #configvec += [ mup_etaconfig] 
    #configvec += [ mum_etaconfig] 

    configvec += [ isos_config] 
    configvec += [ isoh_config] 

    #configvec += [ npvs_config] 
    configvec += [ ntracks_config ] 
    configvec += [ spdhits_config ]
    #configvec += [ bdt0_config] 
    #configvec += [ bdt1_config] 
    #configvec += [ bdt2_config] 
    #configvec += [ bdt3_config] 
    configvec += [ bdt4_config] 
    #configvec += [ bdt5_config] 
    configvec += [ b_logipchi2config] 
    configvec += [ k_logipchi2config]
    configvec += [ mup_logipchi2config]
    configvec += [ mum_logipchi2config]


    plotfilename = "compare_tuples.pdf" 





    g_canvas = ROOT.TCanvas( plotfilename, plotfilename, 800, 600 ) 
    g_canvas.SaveAs( (plotfilename+"[")) 
    
    chisqhist1 = ROOT.TH1D("chisq1", "", len(configvec), 0, len(configvec))
    chisqhist2 = ROOT.TH1D("chisq2", "", len(configvec), 0, len(configvec))
    chisqhist1.Sumw2()
    chisqhist2.Sumw2()
    avechisq0 = 0.0
    avechisq1 = 0.0
    i = 0
    for it in configvec :
        #it.nbins = 100
        chisqs = plot_comp(  t1, t2, it, offsel1, offsel2 , options.simone
            , options.simtwo, options.scale, g_canvas, plotfilename, offsel3 )  

        chisqhist1.GetXaxis().SetBinLabel(i+1, it.label ) 
        chisqhist2.GetXaxis().SetBinLabel(i+1, it.label ) 
        chisqhist1.SetBinContent(i+1, chisqs[0] ) 
        chisqhist2.SetBinContent(i+1, chisqs[1] ) 
        i += 1
        if "ProbNN" in it.name or "PID" in it.name or "OWNPV" in it.name :
            continue
        else :
            avechisq0 += chisqs[0]
            avechisq1 += chisqs[1]

    print"before", avechisq0 / i
    print "after", avechisq1 / i

    #g_canvas.SaveAs((plotfilename)) 
    g_canvas.SaveAs((plotfilename+"]")) 
   
    ROOT.gStyle.SetPadRightMargin(0.02)
    ROOT.gStyle.SetPadTopMargin(0.02)
    ROOT.gStyle.SetPadLeftMargin(0.15)
    ROOT.gStyle.SetPadBottomMargin(0.3)
    c = ROOT.TCanvas("c", "", 800, 800)
    c.SaveAs("compare_tuples_chisq.pdf[")
    c.SetLogy(True)
    chisqhist1.GetYaxis().SetRangeUser(0.1, 1E4)
    chisqhist1.GetYaxis().SetTitle("#chi^{2} / n.d.o.f.")
    chisqhist2.GetYaxis().SetRangeUser(0.1, 1E4)
    chisqhist2.GetYaxis().SetTitle("#chi^{2} / n.d.o.f.")
    chisqhist1.SetMarkerColor(4)
    chisqhist1.SetLineColor(4)
    chisqhist2.SetMarkerColor(ROOT.kMagenta+2)
    chisqhist2.SetLineColor(ROOT.kMagenta+2)
    chisqhist2.LabelsOption("v","X")
    chisqhist2.Draw("e") # data v.s. plain sim
    chisqhist1.Draw("esame")    # data v.s. prev sim
    c.SaveAs("compare_tuples_chisq.pdf")
    c.SetLogy(False)
    chisqhist1.GetYaxis().SetRangeUser(0.1, 20)
    chisqhist2.GetYaxis().SetRangeUser(0.1, 20)
    chisqhist2.Draw("e") # data v.s. plain sim
    chisqhist1.Draw("esame")    # data v.s. prev sim
    c.SaveAs("compare_tuples_chisq.pdf")
    c.SaveAs("compare_tuples_chisq.pdf]")




    f1.Close()
    f2.Close()

