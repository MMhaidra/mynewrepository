#! /usr/bin/env python
import ROOT,os,sys,time,math

from tree import TTree

def calc_inv_mass_from_four( E1, PX1, PY1, PZ1, E2, PX2, PY2, PZ2 ): 
 
    a = (E1+E2)*(E1+E2) 
    a -= (PX1+PX2)*(PX1+PX2)
    a -= (PY1+PY2)*(PY1+PY2)
    a -= (PZ1+PZ2)*(PZ1+PZ2)
    if a > 0 :
        return math.sqrt(a)
    else :
        return 0.0 

def calc_inv_mass(  MA, PA, PXA, PYA, PZA, MB, PB, PXB, PYB, PZB  ) :
    #dodgy formula from nicole 
    EA = math.sqrt(PA*PA+ MA*MA)
    EB = math.sqrt(PB*PB+ MB*MB)

    aPdot  = PXA*PXB + PYA*PYB   +  PZA*PZB
    AA = 2*( (EA*EB) - aPdot)
    msq = ((MA*MA) + (MB*MB) + AA )
    massInv= 0.0
    if(msq > 0.0 ):
        massInv = math.sqrt(msq)

    return massInv;


kaon_mass = 493.7
pion_mass = 139.6
muon_mass = 105.7

if __name__=='__main__' :

    start = time.time()
    print time.asctime(time.localtime())
    print " setting batch mode " 
    ROOT.gROOT.SetBatch(True)
    from optparse import OptionParser, OptionGroup
    parser = OptionParser()
    parser.add_option( "-d", "--dir", dest="dir", default=None, type='string', help="testing" ) 
    parser.add_option( "-f", "--file", dest="file", default=None , type="string", help="filename" ) 
    parser.add_option( "-t", "--tree", dest="tree", default="DecayTree" , type="string", help="treename" )  
    (options,args) = parser.parse_args()

    from ROOT import TFile
    f = TFile( options.file , "READ" )
    tt = f.Get( options.tree )
    n = tt.GetEntries()
    res_tuple = {}

    newfilename = options.file[ : options.file.find(".root") ] + "_vars.root" 
    print newfilename
    newfile = TFile( newfilename, "RECREATE" ) 
    t = tt.CopyTree( "", "" , n ) 

    for i in range(n) :

        if n > 10 :
            if (i % (n/10)  )== 0        :
                print "processed %g"%i

        t.GetEntry(i)

        qsq_true = 0.0

        if t.GetBranch( "muplus_TRUEP_E") :
                qsq_true = calc_inv_mass_from_four (
                            t.muplus_TRUEP_E
                            ,t.muplus_TRUEP_X
                            ,t.muplus_TRUEP_Y
                            ,t.muplus_TRUEP_Z
                            ,t.muminus_TRUEP_E
                            ,t.muminus_TRUEP_X
                            ,t.muminus_TRUEP_Y
                            ,t.muminus_TRUEP_Z
                            )
        
        pk = ROOT.TLorentzVector() 
        pp = ROOT.TLorentzVector() 
        pmp = ROOT.TLorentzVector() 
        pmm = ROOT.TLorentzVector() 
        pk.SetXYZM( t.hadron_PX, t.hadron_PY, t.hadron_PZ, kaon_mass ) 
        pp.SetXYZM( t.hadron_PX, t.hadron_PY, t.hadron_PZ, pion_mass ) 
        pmp.SetXYZM( t.muplus_PX, t.muplus_PY, t.muplus_PZ, muon_mass ) 
        pmm.SetXYZM( t.muminus_PX, t.muminus_PY, t.muminus_PZ, muon_mass ) 

        pBkmm = pk+pmp+pmm
        pBpmm = pp+pmp+pmm

        qsq = (1E-3*t.dimuon_M)*(1E-3*t.dimuon_M)
        qsq_true = qsq_true * qsq_true / 1E6

        if i < 100 :
            print qsq,qsq_true,pBkmm.M(), pBpmm.M()

        t.AddVar( qsq  , "qsq", res_tuple)
        t.AddVar( qsq_true  , "qsq_true", res_tuple) 
        t.AddVar( pBkmm.M() , "kmm_mass", res_tuple)
        t.AddVar( pBpmm.M() , "pimm_mass", res_tuple)

        
        #more masses - muon swaps
        # pi mu 1
        muppim_mass = calc_inv_mass( pion_mass, t.muminus_P, t.muminus_PX, t.muminus_PY, t.muminus_PZ
                , muon_mass, t.muplus_P, t.muplus_PX, t.muplus_PY, t.muplus_PZ )
        # pi mu 2
        pipmum_mass = calc_inv_mass( pion_mass, t.muplus_P, t.muplus_PX, t.muplus_PY, t.muplus_PZ
                , muon_mass, t.muminus_P, t.muminus_PX, t.muminus_PY, t.muminus_PZ )


        t.AddVar( muppim_mass  , "muppim_mass", res_tuple)
        t.AddVar( pipmum_mass  , "pipmum_mass", res_tuple)
    
        mupkam_mass = calc_inv_mass( kaon_mass, t.muminus_P, t.muminus_PX, t.muminus_PY, t.muminus_PZ
                , muon_mass, t.muplus_P, t.muplus_PX, t.muplus_PY, t.muplus_PZ )
        # pi mu 2
        kapmum_mass = calc_inv_mass( kaon_mass, t.muplus_P, t.muplus_PX, t.muplus_PY, t.muplus_PZ
                , muon_mass, t.muminus_P, t.muminus_PX, t.muminus_PY, t.muminus_PZ )


        t.AddVar( mupkam_mass  , "mupkam_mass", res_tuple)
        t.AddVar( kapmum_mass  , "kapmum_mass", res_tuple)

        t.FillVars( res_tuple )

    t.OptimizeBaskets()
    t.Write("",ROOT.TObject.kOverwrite)
    newfile.Close()


    f.Close()
    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start
    sys.exit(0)

