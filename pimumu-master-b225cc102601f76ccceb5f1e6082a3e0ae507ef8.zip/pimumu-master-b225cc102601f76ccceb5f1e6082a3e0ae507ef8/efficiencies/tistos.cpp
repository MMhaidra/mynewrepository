#include <iostream>
#include <cmath>
#include "TFile.h"
#include "TTree.h"
#include <ctime>
#include "TH2D.h"
#include "TCanvas.h"
#include "boost/program_options.hpp"
#include "value.h"
#include "lhcbStyle.h"
#include <string>
//#include "boost/filesystem.hpp"
//#include "boost/filesystem/path.hpp"

namespace po = boost::program_options ;
//namespace fs = boost::filesystem ;


struct config {
    bool debug ;
    bool muons ;
    int ptbins ;
    bool data ;
    bool weight ;
    bool sweight ;
    bool plot ;
    bool nonres ;
    double ptmax ;
    std::string file ;
    std::string tree ;
    std::string histfilename ;
} ;




struct effs {
    value etosL0Eff ;
    value htosL0Eff ;
    value tisL0Eff ;
    value etosEff ;
    value tisEff ;
    value htosEff ;
    value mtosEff ;
    value mtosL0Eff ;
    value dtosEff ;
    value dtosL0Eff ;
} ; 


int calc_muon_histos( const config & c ) 
{
    std::string filename = c.file ;
    std::string treename = c.tree ;
    TFile *f = new TFile( filename.c_str() , "READ" ) ;
    if (!f->IsOpen() ) return 1 ;
    TTree* t = (TTree*) f->Get( treename.c_str() ) ;
    if (!t) return 1 ;
    int n = t->GetEntries() ;
    t->SetBranchStatus("*",0) ;
    double muplus_pt , muminus_pt  ;
    t->SetBranchStatus("muplus_PT",1) ;
    t->SetBranchAddress("muplus_PT", &muplus_pt) ;
    t->SetBranchStatus("muminus_PT",1) ;
    t->SetBranchAddress("muminus_PT", &muminus_pt) ;
    //triggers
    bool L0M , L0MT , L0D, L0DT ;
    bool HLT1T, HLT1M, HLT2M2, HLT2M3 ;
    t->SetBranchStatus("B_L0MuonDecision_TOS",1) ;
    t->SetBranchAddress("B_L0MuonDecision_TOS", &L0M) ;
    t->SetBranchStatus("B_L0MuonDecision_TIS",1) ;
    t->SetBranchAddress("B_L0MuonDecision_TIS", &L0MT) ;
    t->SetBranchStatus("B_L0DiMuonDecision_TOS",1) ;
    t->SetBranchAddress("B_L0DiMuonDecision_TOS", &L0D) ;
    t->SetBranchStatus("B_L0DiMuonDecision_TIS",1) ;
    t->SetBranchAddress("B_L0DiMuonDecision_TIS", &L0DT) ;
    int bkgcat(0) ;
    t->SetBranchStatus("B_BKGCAT",1) ;
    t->SetBranchAddress("B_BKGCAT", &bkgcat) ;

    //cuts
    double mass, qsq , weight(1), datamc_weight(1) , sweight(1) ;
    t->SetBranchStatus("B_M",1) ;
    t->SetBranchAddress("B_M", &mass) ;
    t->SetBranchStatus("qsq",1) ;
    t->SetBranchAddress("qsq", &qsq) ;
    if ( !c.data ) {
        t->SetBranchStatus("datamc_weight",1) ; 
        t->SetBranchAddress("datamc_weight", &datamc_weight) ;
    }
    if ( c.data ) {
        t->SetBranchStatus("sweight",1) ;
        t->SetBranchAddress("sweight", &sweight) ;
    }
    TH1D* muselhist = new TH1D("muselhist","",c.ptbins,0,c.ptmax) ;
    TH1D* mutothist = new TH1D("mutothist","",c.ptbins,0,c.ptmax) ;
    TH1D* diselhist = new TH1D("diselhist","",c.ptbins,0,c.ptmax*c.ptmax/2.) ;
    TH1D* ditothist = new TH1D("ditothist","",c.ptbins,0,c.ptmax*c.ptmax/2.) ;
    muselhist->Sumw2();
    mutothist->Sumw2();
    diselhist->Sumw2();
    ditothist->Sumw2();
    double maxpt = 0 ;
    for ( int i = 0 ; i < n ; ++i )
    {
        t->GetEntry(i) ;
        weight = c.weight ? datamc_weight : 1.0 ;
        if ( c.data && c.sweight ) weight *= sweight ;
        if ( qsq < 8.68 || qsq > 10.08 ) continue ;
        if ( mass < 5175 || mass > 5700 ) continue ;
        maxpt = std::max(muplus_pt,muminus_pt) ; 
        if ( L0M && L0MT ) muselhist->Fill( maxpt, weight ) ; 
        if ( L0MT ) mutothist->Fill( maxpt , weight ) ; 
        if ( L0D && L0DT) diselhist->Fill(muplus_pt*muminus_pt , weight ) ; 
        if ( L0DT) ditothist->Fill( muplus_pt*muminus_pt , weight ) ; 
    }
    TH1D* mueffhist = new TH1D("mueffhist","",c.ptbins,0,c.ptmax) ;
    mueffhist->Divide( muselhist, mutothist, 1.0, 1.0, "B" ) ;
    TH1D* dieffhist = new TH1D("dieffhist","",c.ptbins,0,c.ptmax*c.ptmax/2.) ;
    dieffhist->Divide( diselhist, ditothist, 1.0, 1.0, "B" ) ;
    //write histograms
    std::string histfilename = "tistos_effs_muon_sim.root" ;
    if ( c.data ) histfilename = "tistos_effs_muon_data.root" ;

    TFile * nf = new TFile(histfilename.c_str(),"RECREATE") ;
    mueffhist->Write() ;
    dieffhist->Write() ;
    muselhist->Write() ;
    diselhist->Write() ;
    mutothist->Write() ;
    ditothist->Write() ;
    nf->Close() ;



    f->Close() ;
    return 0 ;

}



int apply_muon_histos( config & c, effs & e) 
{
    std::string filename = c.file ;
    std::string treename = c.tree ;
    TFile *f = new TFile( filename.c_str() , "READ" ) ;
    if (!f->IsOpen() ) return 1 ;
    TTree* t = (TTree*) f->Get( treename.c_str() ) ;
    if (!t) return 1 ;
    int n = t->GetEntries() ;
    t->SetBranchStatus("*",0) ;
    double muplus_pt , muminus_pt  ;
    t->SetBranchStatus("muplus_PT",1) ;
    t->SetBranchAddress("muplus_PT", &muplus_pt) ;
    t->SetBranchStatus("muminus_PT",1) ;
    t->SetBranchAddress("muminus_PT", &muminus_pt) ;
    //triggers
    bool L0M , L0MT , L0D, L0DT ;
    bool HLT1T, HLT1M ;
    bool HLT2M2, HLT2M3 , HLT2SM, HLT2DM, HLT2T2, HLT2T3 ;
    t->SetBranchStatus("B_L0MuonDecision_TOS",1) ;
    t->SetBranchAddress("B_L0MuonDecision_TOS", &L0M) ;
    t->SetBranchStatus("B_L0MuonDecision_TIS",1) ;
    t->SetBranchAddress("B_L0MuonDecision_TIS", &L0MT) ;
    t->SetBranchStatus("B_L0DiMuonDecision_TOS",1) ;
    t->SetBranchAddress("B_L0DiMuonDecision_TOS", &L0D) ;
    t->SetBranchStatus("B_L0DiMuonDecision_TIS",1) ;
    t->SetBranchAddress("B_L0DiMuonDecision_TIS", &L0DT) ;
    t->SetBranchStatus("B_Hlt1TrackAllL0Decision_TOS",1) ;
    t->SetBranchAddress("B_Hlt1TrackAllL0Decision_TOS", &HLT1T) ;
    t->SetBranchStatus("B_Hlt1TrackAllL0Decision_TOS",1) ;
    t->SetBranchAddress("B_Hlt1TrackAllL0Decision_TOS", &HLT1M) ;
    t->SetBranchStatus("B_Hlt2SingleMuonDecision_TOS",1) ;
    t->SetBranchAddress("B_Hlt2SingleMuonDecision_TOS", &HLT2SM) ;
    t->SetBranchStatus("B_Hlt2SingleMuonDecision_TOS",1) ;
    t->SetBranchAddress("B_Hlt2SingleMuonDecision_TOS", &HLT2SM) ;
    t->SetBranchStatus("B_Hlt2DiMuonDetachedDecision_TOS",1) ;
    t->SetBranchAddress("B_Hlt2DiMuonDetachedDecision_TOS", &HLT2DM) ;
    t->SetBranchStatus("B_Hlt2DiMuonDetachedDecision_TOS",1) ;
    t->SetBranchAddress("B_Hlt2DiMuonDetachedDecision_TOS", &HLT2DM) ;
    t->SetBranchStatus("B_Hlt2TopoMu2BodyBBDTDecision_TOS",1) ;
    t->SetBranchAddress("B_Hlt2TopoMu2BodyBBDTDecision_TOS", &HLT2M2) ;
    t->SetBranchStatus("B_Hlt2TopoMu3BodyBBDTDecision_TOS",1) ;
    t->SetBranchAddress("B_Hlt2TopoMu3BodyBBDTDecision_TOS", &HLT2M3) ;
    t->SetBranchStatus("B_Hlt2Topo2BodyBBDTDecision_TOS",1) ;
    t->SetBranchAddress("B_Hlt2Topo2BodyBBDTDecision_TOS", &HLT2T2) ;
    t->SetBranchStatus("B_Hlt2Topo3BodyBBDTDecision_TOS",1) ;
    t->SetBranchAddress("B_Hlt2Topo3BodyBBDTDecision_TOS", &HLT2T3) ;

    int bkgcat(0) ;
    t->SetBranchStatus("B_BKGCAT",1) ;
    t->SetBranchAddress("B_BKGCAT", &bkgcat) ;

    //cuts
    double mass, qsq , weight(1), datamc_weight(1), sweight(1) ;
    t->SetBranchStatus("B_M",1) ;
    t->SetBranchAddress("B_M", &mass) ;
    t->SetBranchStatus("qsq",1) ;
    t->SetBranchAddress("qsq", &qsq) ;
    if ( !c.data ) {
        t->SetBranchStatus("datamc_weight",1) ; 
        t->SetBranchAddress("datamc_weight", &datamc_weight) ;
    }
    if ( c.data ) {
        t->SetBranchStatus("sweight",1) ;
        t->SetBranchAddress("sweight", &sweight) ;
    }
    std::string histfilename = "tistos_effs_muon_sim.root" ;
    if ( c.data ) histfilename = "tistos_effs_muon_data.root" ;
    TFile *mf = new TFile( histfilename.c_str()  , "READ" ) ;
    if (!mf->IsOpen() ) return 1 ;
    TH1D* mhist = (TH1D*) mf->Get("mueffhist");
    TH1D* dhist = (TH1D*) mf->Get("dieffhist");
    std::cout << mhist << '\t' << dhist << std::endl ;
    double qsqmin = c.nonres ? 1 : 8.68 ;
    double qsqmax = c.nonres ? 6 : 10.08 ;

    double nmtossel(0), nmtostot(0), nmtossel2(0) ;
    double ndtossel(0), ndtostot(0), ndtossel2(0) ;
    //apply to simulation
    for ( int i = 0 ; i < n ; ++i )
    {
        t->GetEntry(i) ;
        weight = c.weight ? datamc_weight : 1.0 ;
        if ( c.data && c.sweight ) weight *= sweight ;
        if ( bkgcat > 11 ) continue ;
        if ( qsq < qsqmin || qsq > qsqmax ) continue ;
        if ( mass < 5175 || mass > 5700 ) continue ;
        nmtostot += weight ;
        ndtostot += weight ;
        if ( (HLT1M||HLT1T) && (HLT2SM||HLT2DM||HLT2M2||HLT2M3||HLT2T2||HLT2T3)  ) nmtossel2 += mhist->GetBinContent( mhist->FindBin( std::max(muplus_pt,muminus_pt) ) ) ; ;
        nmtossel += mhist->GetBinContent( mhist->FindBin( std::max(muplus_pt,muminus_pt) ) ) ;
        if ( (HLT1M||HLT1T) && (HLT2SM||HLT2DM||HLT2M2||HLT2M3||HLT2T2||HLT2T3)  ) ndtossel2 += dhist->GetBinContent( dhist->FindBin( std::max(muplus_pt,muminus_pt) ) ) ; ;
        ndtossel += dhist->GetBinContent( dhist->FindBin( muplus_pt*muminus_pt ) ) ;
    }
    value mtossel (nmtossel,sqrt(nmtossel));
    value mtossel2 (nmtossel2,sqrt(nmtossel2));
    value mtostot (nmtostot,sqrt(nmtostot));
    value mtoseff = mtossel.divb( mtostot) ;
    value mtoseff2 = mtossel2.divb( mtostot) ;
    value dtossel (ndtossel,sqrt(ndtossel));
    value dtossel2 (ndtossel2,sqrt(ndtossel2));
    value dtostot (ndtostot,sqrt(ndtostot));
    value dtoseff = dtossel.divb( dtostot) ;
    value dtoseff2 = dtossel2.divb( dtostot) ;

    std::cout << "MTOS1 " << nmtossel << " from " << nmtostot << " Eff : " << mtoseff << std::endl ;
    std::cout << "MTOS2 " << nmtossel2 << " from " << nmtostot << " Eff : " << mtoseff2 << std::endl ;
    std::cout << "DTOS1 " << ndtossel << " from " << ndtostot << " Eff : " << dtoseff << std::endl ;
    std::cout << "DTOS2 " << ndtossel2 << " from " << ndtostot << " Eff : " << dtoseff2 << std::endl ;

    e.mtosL0Eff = mtoseff ;
    e.mtosEff = mtoseff2 ;
    e.dtosL0Eff = dtoseff ;
    e.dtosEff = dtoseff2 ;

    f->Close() ;
    mf->Close() ;
    return 0 ;
}





int make_plots(  ) 
{
    lhcbStyle() ;
    TCanvas * c = new TCanvas("c","",800,600);
    std::string simhistfilename = "tistos_effs_muon_sim.root" ;
    std::string datahistfilename = "tistos_effs_muon_data.root" ;
    TFile* sf = new TFile( simhistfilename.c_str() , "READ" ) ;
    TFile* df = new TFile( datahistfilename.c_str() , "READ" ) ;
    TH1D * smhist = (TH1D*) sf->Get("mueffhist") ;
    TH1D* sdhist = (TH1D*) sf->Get("dieffhist") ;
    TH1D * dmhist = (TH1D*) df->Get("mueffhist") ;
    TH1D* ddhist = (TH1D*) df->Get("dieffhist") ;
    std::cout << smhist << '\t' << sdhist << '\t' << ddhist << '\t' << dmhist << std::endl; 
    smhist->SetLineColor(2) ;
    sdhist->SetLineColor(2) ;
    smhist->SetMarkerColor(2) ;
    sdhist->SetMarkerColor(2) ;
    dmhist->GetXaxis()->SetTitle("max #mu p_{T} [MeV/c]");
    dmhist->GetYaxis()->SetTitle("#epsilon");
    ddhist->GetXaxis()->SetTitle("#mu^{+} p_{T} * mu^{-} p_{T} [MeV^{2}/c^{2}]");
    ddhist->GetYaxis()->SetTitle("#epsilon");
    dmhist->GetYaxis()->SetRangeUser(0,1.1) ;
    ddhist->GetYaxis()->SetRangeUser(0,1.1) ;
    c->SaveAs("tistos_eff_hist_muon_plots.pdf[");
    dmhist->Draw("e") ;
    smhist->Draw("esame") ;
    c->SaveAs("tistos_eff_hist_muon_plots.pdf");
    ddhist->Draw("e") ;
    sdhist->Draw("esame") ;
    c->SaveAs("tistos_eff_hist_muon_plots.pdf");
    c->SaveAs("tistos_eff_hist_muon_plots.pdf]");
    df->Close();
    sf->Close();


    return 0 ;
}


int main( int argc, char * argv[] ) 
{
    //standard files
    std::string simdir = "/home/alexshires/data/Pimm/mc/" ;
    std::string datadir = "/home/alexshires/data/Pimm/mc/" ;

    std::string jpsiksimfile = "with_bdt_jpsik_12_mc_isoln_newpid_corr.root"; //res sim
    std::string kmmsimfile = "with_bdt_kmumu_12_mc_isoln_magupdown_newpid_corr.root"; //jpsik data
    std::string pimmsimfile = "with_bdt_pimumu_12_mc_isoln_newpid_corr.root"; //jpsik data

    config c ;

    po::options_description desc("Allowed options") ;
    desc.add_options()
        ("help,h","help!")
        ("debug,v",po::value<bool>(&c.debug)->default_value(false)->zero_tokens(),"debug case - small jpsikstar smaple, or first q2 bin")
        ("nonres,n",po::value<bool>(&c.nonres)->default_value(false)->zero_tokens(),"rfold into nonres")
        ("data,d",po::value<bool>(&c.data)->default_value(false)->zero_tokens(),"data")
        ("weight,w",po::value<bool>(&c.weight)->default_value(false)->zero_tokens(),"weight")
        ("sweight,s",po::value<bool>(&c.sweight)->default_value(false)->zero_tokens(),"weight")
        ("ptbins",po::value<int>(&c.ptbins)->default_value(100),"pt bins")
        ("qsqbins",po::value<int>(&c.ptbins)->default_value(100),"qsq bins")
        ("ptmax",po::value<double>(&c.ptmax)->default_value(15E3),"pt max")
        ("plot,p",po::value<bool>(&c.plot)->default_value(false)->zero_tokens(),"plot")
        ;
    // actually do the parsing
    po::variables_map vm ;
    po::store(po::parse_command_line( argc, argv, desc) , vm ) ;
    po::notify(  vm ) ;

    // show help and exit
    if ((argc < 1) || (vm.count("help"))) {
        std::cout << desc << std::endl;
        return 1 ;
    }
    c.file = simdir + kmmsimfile ;
    c.tree = "DecayTree" ;
    if (c.data) c.file = datadir+kmmdatafile;

    effs dataeffs ;
    effs simeffs ;

    // start the stopwatch
    std::clock_t start_clock = std::clock() ;
    int r(0) ;
    //process
    c.data = false ;
    c.file = simdir + kmmsimfile ;
    std::cout << "calculating histos from sim" << std::endl ;
    r = calc_muon_histos( c ) ;
    c.file = simdir + kmmsimfile ;
    if ( c.nonres ) c.file = simdir + kmmsimfile2 ;
    std::cout << "applying histos to sim" << std::endl ;
    r = apply_muon_histos( c , simeffs ) ;
    c.data = true ;
    std::cout << "calculating histos from data" << std::endl ;
    c.file = datadir + kmmdatafile ;
    r = calc_muon_histos( c ) ;
    c.file = simdir + kmmsimfile ;
    if ( c.nonres ) c.file = simdir + kmmsimfile2 ;
    std::cout << "applying histos to sim" << std::endl ;
    r = apply_muon_histos( c , dataeffs ) ;
    if (c.plot) r = make_plots(  ); 
    //print effs
    std::cout << "MTOS L0 Ratio: " << dataeffs.mtosL0Eff / simeffs.mtosL0Eff << std::endl ;
    std::cout << "MTOS TRIG Ratio: " << dataeffs.mtosEff / simeffs.mtosEff << std::endl ;
    std::cout << "DTOS L0 Ratio: " << dataeffs.dtosL0Eff / simeffs.dtosL0Eff << std::endl ;
    std::cout << "DTOS TRIG Ratio: " << dataeffs.dtosEff / simeffs.dtosEff << std::endl ;


    std::clock_t end_clock = std::clock() ;
    double diff = ( end_clock - start_clock ) / CLOCKS_PER_SEC ;
    std::cout << " time " << diff << " seconds " << std::endl ;

    return r ;
}

