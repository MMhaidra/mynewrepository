#include <iostream>
#include <sstream>
#include "TFile.h"
#include "TTree.h"
#include "TH3D.h"
#include <cmath>
#include <ctime>
#include "value.h"
#include <fstream>

#include "boost/program_options.hpp"
namespace po = boost::program_options ;


//TODO use boost filesystem

struct config {
    bool pions ;
    bool jpsi ;
    bool debug ;
    bool weight ;
};



value count_file( const std::string filename 
        , double qsqmin,  double qsqmax
        , const bool weighted) 
{
    value count ;

    TFile *f = new TFile( filename.c_str() , "READ" ) ;
    if (!f->IsOpen() ) return value(0,0) ;
    TTree* t = (TTree*) f->Get( "DecayTree" ) ;
    if (!t) return value(0,0) ;
    int n = t->GetEntries() ;
    t->SetBranchStatus("*",0) ;
    double weight;
    double qsq ;
    int bkgcat ;
    double bmass(5280) ;
    t->SetBranchStatus("total_weight",1) ;
    t->SetBranchAddress("total_weight", &weight) ;
    t->SetBranchStatus("B_BKGCAT",1) ;
    t->SetBranchAddress("B_BKGCAT", &bkgcat) ;
    t->SetBranchStatus("qsq",1) ;
    t->SetBranchAddress("qsq", &qsq) ;
    t->SetBranchStatus("B_M",1) ;
    t->SetBranchAddress("B_M", &bmass) ;
    double sumw = 0.0 ;
    int npass = 0 ;
    //std::cout << "iterating" << filename << '\t' << n << std::endl ;
    for ( int i = 0 ; i < n ; ++i )
    {
        t->GetEntry(i) ;
        if ( bkgcat < 11 && qsq > qsqmin && qsq < qsqmax) {
            sumw+=weight;
            ++npass ;
        }
    }
    //std::cout << sumw << '\t' << npass << std::endl ;
    f->Close() ;
    if (weighted) return value( sumw, sqrt(sumw) ) ;
    else return value( npass, sqrt(npass) ) ;
}



int main( int argc, char * argv[] ) 
{
    //standard files
    std::string basedir = "/home/alexshires/data/Pimm" ;

    std::string stripdir = "mc";
    std::string seldir = "mc" ;



    std::string jpsikstrip = "with_bdt_jpsik_12_mc_isoln_newpid_corr_vars.root";
    std::string kmumustrip = "with_bdt_kmumu_12_mc_isoln_newpid_corr_vars.root";
    std::string pimumustrip = "with_bdt_pimumu_12_mc_isoln_magupdown_newpid_corr_vars.root";

    std::string jpsikfile = "with_bdt_jpsik_12_mc_isoln_newpid_corr_vars_presel_offsel.root";
    std::string kmumufile = "with_bdt_kmumu_12_mc_isoln_newpid_corr_vars_presel_offsel.root";
    std::string pimumufile = "with_bdt_pimumu_12_mc_isoln_magupdown_newpid_corr_vars_presel_offsel.root";

    std::string jpsikstripfile = basedir +"/"+ stripdir + "/" + jpsikstrip ;
    std::string jpsikselfile = basedir +"/"+ seldir + "/" + jpsikfile ;

    std::string kmumustripfile = basedir +"/"+ stripdir + "/" + kmumustrip ;
    std::string kmumuselfile = basedir +"/"+ seldir + "/" + kmumufile ;

    std::string pimumustripfile = basedir +"/"+ stripdir + "/" + pimumustrip ;
    std::string pimumuselfile = basedir +"/"+ seldir + "/" + pimumufile ;

    config c ;

    po::options_description desc("Allowed options") ;
    desc.add_options()
        ("help,h","help!")
        ("debug,v",po::value<bool>(&c.debug)->default_value(false)->zero_tokens(),"debug case ")
        ("weight,w",po::value<bool>(&c.weight)->default_value(false)->zero_tokens(),"weight case - small jp")
        //("mev,m",po::value<bool>(&c.mev)->default_value(false)->zero_tokens(),"work in mev")
        ("jpsi,j",po::value<bool>(&c.jpsi)->default_value(false)->zero_tokens(),"jpsi case ")
        ;
    // actually do the parsing
    po::variables_map vm ;
    po::store(po::parse_command_line( argc, argv, desc) , vm ) ;
    po::notify(  vm ) ;

    // show help and exit
    if ((argc < 2) || (vm.count("help"))) {
        std::cout << desc << std::endl;
        return 1 ;
    }
    // start the stopwatch
    std::clock_t start_clock = std::clock() ;

    value pimumugeo(0.16459, 0.00046);
    value kmumugeo(0.17050, 0.00090);
    value pimumureco(0.19551, 0.00042);
    value kmumureco(0.19720, 0.00055);
    value jpsikgeo(0.16860, 0.00090);
    value jpsikreco(0.20121, 0.00029);

    std::cout << "eff calc " << std::endl ;
    //choices
    std::string selfile, truthfile, stripfile ;
    //TODO make more generic
    //testing
    value totjpsikeff, totkmumueff, totpimumueff, ratiokpi, ratiojpi, ratiojk ;
    value nstripjpsik, nseljpsik, nstripkmumu, nselkmumu, nstrippimumu, nselpimumu ; 
    //process
    std::vector<double> qsqmins = {0,  0.1, 2, 4, 6, 11,   15, 17, 19, 22, 1, 15} ;
    std::vector<double> qsqmaxs = {25, 2,   4, 6, 8, 12.5, 17, 19, 22, 25, 6, 22} ;
    //loop over q2 bins
    std::vector<double>::iterator it, jt(qsqmaxs.begin());
    //calc each eff as ratio
    std::string filename = "effscpp.txt" ;
    if ( c.weight ) filename = "effscpp_weight.txt" ;
    std::ofstream outfile( filename , std::ostream::out) ;
    //
    nstripjpsik = count_file( jpsikstripfile, 0, 25, c.weight ) ;
    nseljpsik = count_file( jpsikselfile, 0, 25, c.weight ) ;
    totjpsikeff = jpsikgeo * jpsikreco * (nseljpsik/nstripjpsik) ;
    std::cout << "eff calc " << std::endl ;
    //
    for ( it = qsqmins.begin() ; it!=qsqmins.end() ; ++it, ++jt )
    {
        //
        std::cout << "calculating" << *it << '\t' << *jt << std::endl;
        nstripkmumu = count_file( kmumustripfile, *it, *jt, c.weight ) ;
        nselkmumu = count_file( kmumuselfile, *it, *jt, c.weight ) ;
        nstrippimumu = count_file( pimumustripfile, *it, *jt, c.weight ) ;
        nselpimumu = count_file( pimumuselfile, *it, *jt, c.weight ) ;
        //
        totkmumueff = kmumugeo * kmumureco * (nselkmumu/nstripkmumu) ;
        totpimumueff = pimumugeo * pimumureco * (nselpimumu/nstrippimumu) ;

        ratiokpi = totkmumueff / totpimumueff ;
        ratiojpi = totjpsikeff / totpimumueff ;
        ratiojk = totjpsikeff / totkmumueff ;

        outfile << ratiokpi.val() << '\t' << ratiokpi.err() << '\t' ;
        outfile << ratiojpi.val() << '\t' << ratiojpi.err() << '\t' ;
        outfile << ratiojk.val() << '\t' << ratiojk.err() << '\n' ;

        std::cout << nstrippimumu << '\t' << nselpimumu << '\t' << nstripkmumu << '\t' << nselkmumu << std::endl ;

        std::cout << totkmumueff << '\t' << totpimumueff << std::endl ;

        std::cout << ratiokpi <<  '\t' ;
        std::cout << ratiojpi << '\t' ;
        std::cout << ratiojk << '\n' ;


    }

    outfile.close() ;

    //end
    std::clock_t end_clock = std::clock() ;
    double diff = ( end_clock - start_clock ) / CLOCKS_PER_SEC ;
    std::cout << " time " << diff << " seconds " << std::endl ;

    return 0 ;
}

