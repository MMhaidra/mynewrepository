from math import sqrt

def prod_tuple( a, b):
    va, ea = a
    vb, eb = b
    e = sqrt( ea*ea*vb*vb + eb*eb*va*va ) 
    return (va*vb, e ) 

def div_tuple( a, b):
    va, ea = a
    vb, eb = b
    e = sqrt( ea*ea/(vb*vb) + eb*eb*va*va/(vb*vb*vb*vb) ) 
    return (va/vb, e ) 

def add_tuple( a, b):
    va, ea = a
    vb, eb = b
    e = sqrt( ea*ea + eb*eb ) 
    return (va+vb, e ) 

def sub_tuple( a, b):
    va, ea = a
    vb, eb = b
    e = sqrt( ea*ea*va*va + eb*eb*vb*vb ) 
    return (va-vb, e ) 

from math import log10

class Value:
    """ value class """
    def __init__(self, _v, _e=0 ) :
        self.v = float(_v)
        self.e = float(_e)
        if _e is 0 :
            self.e = sqrt(_v)

    def __mul__(self, othervalue ) :
        va = self.v
        vb = othervalue.v
        ea = self.e
        eb = othervalue.e
        tmpv = va * vb
        tmpe = sqrt( ea*ea*vb*vb + eb*eb*va*va ) 
        return Value(tmpv, tmpe)

    def __div__(self, othervalue ) :
        va = self.v
        vb = othervalue.v
        ea = self.e
        eb = othervalue.e
        tmpv = va/vb
        tmpe = sqrt( ea*ea/(vb*vb) + eb*eb*va*va/(vb*vb*vb*vb) )
        return Value(tmpv, tmpe)

    def __add__(self, othervalue ) :
        va = self.v
        vb = othervalue.v
        ea = self.e
        eb = othervalue.e
        tmpv = va+vb
        tmpe = sqrt( ea*ea + eb*eb ) 
        return Value(tmpv, tmpe)

    def __sub__(self, othervalue ) :
        va = self.v
        vb = othervalue.v
        ea = self.e
        eb = othervalue.e
        tmpv = va-vb
        tmpe = sqrt( ea*ea + eb*eb ) 
        return Value(tmpv, tmpe)

    def __str__(self) :
        n = 2
        if self.e > 0 :
            n = int(log10(self.e))
        if n < 1 :
            string = "%%.%gf $\\pm$ %%.%gf" % (-1*n+2, -1*n+2)
        else :
            string = "%d $\\pm$ %d"
        return string % (self.v, self.e)

    def __repr__(self) :
        n = int(log10(self.e))
        if n < 1 :
            string = "(v:%%.%gf s:%%.%gf" % (-1*n+2, -1*n+2)
        else :
            string = "(v:%d e:%d)"
        return string % (self.v, self.e)

    def __iadd__(self, othervalue):
        tmpval = Value( self.v , self.e ) + othervalue
        self.v = tmpval.v
        self.e = tmpval.e
        return self
    def __isub__(self, othervalue):
        tmpval = Value( self.v , self.e ) - othervalue
        self.v = tmpval.v
        self.e = tmpval.e
        return self
    def __imul__(self, othervalue):
        tmpval = Value( self.v , self.e ) * othervalue
        self.v = tmpval.v
        self.e = tmpval.e
        return self
    def __idiv__(self, othervalue):
        tmpval = Value( self.v , self.e ) / othervalue
        self.v = tmpval.v
        self.e = tmpval.e
        return self
    
    def f(self) :
        return self.e / self.v

    def getError(self) :
        return self.e 

    def getValue(self) :
        return self.v
from ROOT import TH1D
from collections import namedtuple

class Config ( namedtuple( "Config", [ 'branch','minval','maxval','nbins','title','logx','logy'] ) ) :
    def getHistogram(self,name=None):
        if not name :
            return None
        else :
            return TH1D(name,"", self.nbins, self.minval, self.maxval)
