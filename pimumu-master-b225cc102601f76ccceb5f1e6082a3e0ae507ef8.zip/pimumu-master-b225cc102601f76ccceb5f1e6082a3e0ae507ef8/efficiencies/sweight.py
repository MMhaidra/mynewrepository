#! /usr/bin/env python

import ROOT,os,sys,time,math

from tree import TTree
from lhcbStyle import setLHCbStyle
def config_pdf( mass, oppo=False ) :
    from ROOT import RooDataSet, RooRealVar, RooArgSet, RooArgList
    from ROOT import RooExponential, RooCBShape, RooAddPdf 
    mean = RooRealVar('mean', 'mean', 5279, 5200, 5400 )
    s0 = RooRealVar('s0' ,'s0' , 10 , 5 , 100  )
    a0 = RooRealVar('a0' ,'a0' , 0.30, 0.05 , 10.0 )
    n0 = RooRealVar('n0' ,'n0' , 30 ) #,0,1000 )
    s1 = RooRealVar('s1' ,'s1' , 30, 0 , 100 )
    a1 = RooRealVar('a1' ,'a1' , 0.40, 0 , 10 )
    if oppo:
        a1 = RooRealVar('a1' ,'a1' , -0.40, -10 , -0.05 )
    n1 = RooRealVar('n1' ,'n1' , 30 ) #,0,1000 )
    f0 = RooRealVar('f0' , 'f0', 0.9, 0.0, 1.0  )
    CBSHP1 = RooCBShape( 'CBSHP1', 'CBSHP1', mass, mean, s0,  a0, n0 )
    CBSHP2 = RooCBShape( 'CBSHP2', 'CBSHP2', mass, mean, s1,  a1, n1 )
    SIG  = RooAddPdf('SIG', 'SIG', RooArgList( CBSHP1, CBSHP2 )
            , RooArgList( f0 ) )
    e0   = RooRealVar('e0', 'e0', 0, -0.01, 0.01)
    BKG  =  RooExponential('BKG', 'BKG', mass, e0) 
    nsig = RooRealVar('nsig', 'nsig', 1e6, 0, 1e9)
    nbkg = RooRealVar('nbkg', 'nbkg', 1e3, 0, 1e9) 
    PDF = RooAddPdf('PDF', 'PDF', RooArgList( SIG, BKG )
            , RooArgList( nsig,nbkg ) )
    #PDF = SIG 
    return (PDF, nsig, nbkg, [CBSHP1, CBSHP2, SIG, BKG] 
            , [mean, s0, a0, n0, s1, a1, n1, f0, e0])


if __name__ == '__main__' :

    start = time.time()
    print time.asctime(time.localtime())
    print " setting batch mode " 
    from ROOT import gStyle, RooMsgService, RooFit
    RooMsgService.instance().setGlobalKillBelow(RooFit.ERROR)
    RooMsgService.instance().setSilentMode(True)
    ROOT.gROOT.SetBatch(True)
    setLHCbStyle()
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument( "-d", "--dir", dest="dir"
            , default=None, type=str, help="testing" ) 
    parser.add_argument( "-f", "--file", dest="file"
            , default=None , type=str, help="filename" ) 
    parser.add_argument( "-t", "--tree", dest="tree"
            , default="DecayTree" , type=str, help="treename" ) 
    parser.add_argument( "-n", "--nevts", dest="nevts"
            , default=-1 , type=int, help="num events" )
    parser.add_argument( "-p", "--plot", dest="plot", action="store_true"
            , default=False , help="plot" ) 

    options = parser.parse_args()

    print "splotting", options.file
    from ROOT import TFile
    f = TFile( options.file , "READ" )
    tree = f.Get( options.tree )
    tree.SetBranchStatus("*", 0)
    tree.SetBranchStatus("B_M", 1)
    minmass = 5200
    maxmass = 5700
    #dataset
    from ROOT import RooDataSet, RooRealVar, RooArgSet, RooFit
    mass = RooRealVar('B_M', 'm(h#mu#mu)', minmass, maxmass)
    PDF, nsig, nbkg, pdfs, vars = config_pdf(mass, True)

    from ROOT import gROOT
    gROOT.cd()
    data = RooDataSet('data', 'data', tree, RooArgSet(mass))

    name = "splottest.pdf"
    c = ROOT.TCanvas("c", "", 800, 600)
    c.SaveAs(name+"[")
    res = PDF.fitTo( data, ROOT.RooFit.NumCPU(5), RooFit.Save(True) )
    res.Print()
    plot = mass.frame()
    data.plotOn( plot )
    PDF.plotOn( plot )
    PDF.plotOn( plot , RooFit.Components("CBSHP1")
            , RooFit.LineStyle( RooFit.kDotted ) 
            , RooFit.LineColor( RooFit.kRed ) 
            )
    PDF.plotOn( plot , RooFit.Components("CBSHP2")
            , RooFit.LineStyle( RooFit.kDotted ) 
            , RooFit.LineColor( RooFit.kRed ) 
            )
    PDF.plotOn( plot , RooFit.Components("BKG") 
            , RooFit.LineStyle( RooFit.kDashed ) 
            , RooFit.LineColor( RooFit.kBlue ) 
            )
    plot.SetMinimum(1)
    #c.SetLogy()
    plot.Draw()
    c.SaveAs(name)
    c.SetLogy()
    plot.Draw()
    c.SaveAs(name)

    c.SaveAs(name+"]")

    if options.plot :
        exit() 


    for v in vars:
        v.setConstant(True)

    from ROOT import RooStats, RooArgList
    # based on our model and our yield variables
    sData = RooStats.SPlot("sData", "An SPlot", data, PDF
            , RooArgList( nsig, nbkg ) )

    sData.Print("V")

    data.Print("V")


    nf = TFile( options.file[:options.file.find(".root")]+"_sweight.root"
            , "RECREATE")
    print "copying tree"
    tree.SetBranchStatus("*", 1)
    nt = tree.CloneTree(-1, "fast")
    nt.SetBranchStatus("*", 0)
    nt.SetBranchStatus("B_M", 1)
    n  = nt.GetEntries() 
    res_tuple = {}
    j = 0
    print n, data.numEntries()
    for i in range(0, n): 
        sw = 0.0 
        nt.GetEntry(i)
        vmass = tree.B_M
        if n > 10 :
            if (i % (n/10)  )== 0 :
                print "processed %g" % j, \
                        "last weight %f,%f"%(j, sw)
        if ( vmass > minmass and vmass < maxmass ) :
            args = data.get(j)
            if j < 10 :
                print vmass, args.getRealValue("B_M")
            sw = args.getRealValue("nsig_sw")
            j += 1
        nt.AddVar(sw, "sweight", res_tuple)
        nt.FillVars(res_tuple)
        
    nt.SetBranchStatus("*", 1)
    nt.OptimizeBaskets()
    nt.Write("", ROOT.TObject.kOverwrite)

    print "closing", nf, f
    nf.Close() 
    f.Close()

    c.SaveAs(name+"]")
    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start
    sys.exit(0)


