#! /usr/bin/env python

import ROOT





if __name__=='__main__':
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()

    ROOT.gROOT.SetBatch(True)
    
    f = ROOT.TFile("~/data/Pimm/presel/with_bdt_pimumu_tot_isoln_presel.root") 
    t = f.Get("DecayTree")


    nbins = 30
    
    h0 = ROOT.TH1D("h0" , "" , nbins , 0 , 6) 
    h9 = ROOT.TH1D("h9" , "" , nbins , 0 , 6) 
    
    h1 = ROOT.TH2D("h1" , "" , nbins , -4   , 20  , nbins , 0 , 1) 
    h2 = ROOT.TH2D("h2" , "" , nbins , -100 , 100 , nbins , 0 , 1) 
    h3 = ROOT.TH2D("h3" , "" , nbins , 0    , 1   , nbins , 0 , 1) 
    h4 = ROOT.TH2D("h4" , "" , nbins , -100 , 100 , nbins , -4 , 20) 
    
    h5 = ROOT.TH2D("h5" , "" , nbins , 0 , 6 , nbins , 0 , 1) 
    h6 = ROOT.TH2D("h6" , "" , nbins , 0 , 6 , nbins , -4 , 20) 
    h7 = ROOT.TH2D("h7" , "" , nbins , 0 , 6 , nbins , 0 , 1) 
    h8 = ROOT.TH2D("h8" , "" , nbins , 0 , 6 , nbins , -100 , 100) 
    qsqtitle = "#it{q}^{2} [GeV^{2}/c^{4}]"
    pidmutitle = "#mu PIDmu"
    probnnmutitle = "#mu ProbNNmu"
    pidktitle = "#mu PIDK"
    probnnktitle = "#mu ProbNNk"


    h0.GetXaxis().SetTitle( qsqtitle )
    h1.GetXaxis().SetTitle( pidmutitle ) 
    h1.GetYaxis().SetTitle( probnnmutitle ) 
    h2.GetXaxis().SetTitle( pidktitle ) 
    h2.GetYaxis().SetTitle( probnnktitle ) 
    h3.GetXaxis().SetTitle( probnnktitle ) 
    h3.GetYaxis().SetTitle( probnnmutitle ) 
    h4.GetXaxis().SetTitle( pidktitle ) 
    h4.GetYaxis().SetTitle( pidmutitle ) 
    h5.GetXaxis().SetTitle( qsqtitle ) 
    h5.GetYaxis().SetTitle( probnnmutitle ) 
    h6.GetXaxis().SetTitle( qsqtitle ) 
    h6.GetYaxis().SetTitle( pidmutitle ) 
    h7.GetXaxis().SetTitle( qsqtitle ) 
    h7.GetYaxis().SetTitle( probnnktitle ) 
    h8.GetXaxis().SetTitle( qsqtitle ) 
    h8.GetYaxis().SetTitle( pidktitle ) 
 

    sel = "B_M<5175 && qsq<6 &&BDT_0>0.5 "
    sel2 = "B_M<5175 && qsq<6 &&BDT_0>0.5 "\
            + "&& muplus_ProbNNmu>0.2 && muminus_ProbNNmu>0.2 "
   
    t.Draw("muplus_ProbNNmu:muplus_PIDmu>>h1" , sel , "goff")
    t.Draw("muplus_ProbNNk:muplus_PIDK>>h2" , sel , "goff")
    t.Draw("muplus_ProbNNmu:muplus_ProbNNk>>h3" , sel , "goff")
    t.Draw("muplus_PIDmu:muplus_PIDK>>h4" , sel , "goff")
    t.Draw("qsq>>h0" , sel , "goff")
    t.Draw("qsq>>h9" , sel2 , "goff")
    t.Draw("muplus_ProbNNmu:qsq>>h5" , sel , "goff")
    t.Draw("muplus_PIDmu:qsq>>h6" , sel , "goff")
    t.Draw("muplus_ProbNNk:qsq>>h7" , sel , "goff")
    t.Draw("muplus_PIDK:qsq>>h8" , sel , "goff")

    h9.SetLineColor(ROOT.kBlue)
    h9.SetMarkerColor(ROOT.kBlue)
  
    ROOT.gStyle.SetPadRightMargin(0.1)
    ROOT.gStyle.SetPalette(51)

    c = ROOT.TCanvas("c" , "" , 800 , 600)
    c.SaveAs("semilep_plots.pdf[")
    h0.Draw("e")
    h9.Draw("esame")
    c.SaveAs("semilep_plots.pdf")
    h5.Draw("colz")
    c.SaveAs("semilep_plots.pdf")
    h6.Draw("colz")
    c.SaveAs("semilep_plots.pdf")
    h7.Draw("colz")
    c.SaveAs("semilep_plots.pdf")
    h8.Draw("colz")
    c.SaveAs("semilep_plots.pdf")
    h1.Draw("colz")
    c.SaveAs("semilep_plots.pdf")
    h2.Draw("colz")
    c.SaveAs("semilep_plots.pdf")
    h3.Draw("colz")
    c.SaveAs("semilep_plots.pdf")
    h4.Draw("colz")
    c.SaveAs("semilep_plots.pdf")

    c.SaveAs("semilep_plots.pdf]")

    f.Close()

    exit()

    #plopt signal
    f = ROOT.TFile("~/data/Pimm/sim/with_bdt_pimumu_12_mc_isoln_updated_newpid_vars_bdt_sim_sel.root") 
    t = f.Get("DecayTree")
    print t.GetEntries()
    h0 = ROOT.TH1D("h0" , "" , nbins , 0 , 8) 
    
    h1 = ROOT.TH2D("h1" , "" , nbins , -4 , 20 , nbins , 0 , 1) 
    h2 = ROOT.TH2D("h2" , "" , nbins , -100 , 100 , nbins , 0 , 1) 
    h3 = ROOT.TH2D("h3" , "" , nbins , 0 , 1 , nbins , 0 , 1) 
    h4 = ROOT.TH2D("h4" , "" , nbins , -100 , 100 , nbins , -4 , 20) 
    
    h5 = ROOT.TH2D("h5" , "" , nbins , 0 , 8 , nbins , 0 , 1) 
    h6 = ROOT.TH2D("h6" , "" , nbins , 0 , 8 , nbins , -4 , 20) 
    h7 = ROOT.TH2D("h7" , "" , nbins , 0 , 8 , nbins , 0 , 1) 
    h8 = ROOT.TH2D("h8" , "" , nbins , 0 , 8 , nbins , -100 , 100) 
    qsqtitle = "#it{q}^{2} [GeV^{2}/c^{4}]"
    pidmutitle = "#mu PIDmu"
    probnnmutitle = "#mu ProbNNmu"
    pidktitle = "#mu PIDK"
    probnnktitle = "#mu ProbNNk"


    h0.GetXaxis().SetTitle( qsqtitle )
    h1.GetXaxis().SetTitle( pidmutitle ) 
    h1.GetYaxis().SetTitle( probnnmutitle ) 
    h2.GetXaxis().SetTitle( pidktitle ) 
    h2.GetYaxis().SetTitle( probnnktitle ) 
    h3.GetXaxis().SetTitle( probnnktitle ) 
    h3.GetYaxis().SetTitle( probnnmutitle ) 
    h4.GetXaxis().SetTitle( pidktitle ) 
    h4.GetYaxis().SetTitle( pidmutitle ) 
    h5.GetXaxis().SetTitle( qsqtitle ) 
    h5.GetYaxis().SetTitle( probnnmutitle ) 
    h6.GetXaxis().SetTitle( qsqtitle ) 
    h6.GetYaxis().SetTitle( pidmutitle ) 
    h7.GetXaxis().SetTitle( qsqtitle ) 
    h7.GetYaxis().SetTitle( probnnktitle ) 
    h8.GetXaxis().SetTitle( qsqtitle ) 
    h8.GetYaxis().SetTitle( pidktitle ) 
 


    t.Draw("muplus_ProbNNmu:muplus_PIDmu>>h1" , "B_M<5575 && qsq<4 " , "goff")
    t.Draw("muplus_ProbNNk:muplus_PIDK>>h2" , "B_M<5575 && qsq<4 " , "goff")
    t.Draw("muplus_ProbNNmu:muplus_ProbNNk>>h3" , "B_M<5575 && qsq<4 " , "goff")
    t.Draw("muplus_PIDmu:muplus_PIDK>>h4" , "B_M<5575 && qsq<4 " , "goff")
    t.Draw("qsq>>h0" , "B_M<5575 && qsq<8" , "goff")
    t.Draw("muplus_ProbNNmu:qsq>>h5" , "B_M<5575 && qsq<8" , "goff")
    t.Draw("muplus_PIDmu:qsq>>h6" , "B_M<5575 && qsq<8" , "goff")
    t.Draw("muplus_ProbNNk:qsq>>h7" , "B_M<5575 && qsq<8" , "goff")
    t.Draw("muplus_PIDK:qsq>>h8" , "B_M<5575 && qsq<8" , "goff")

    c.SaveAs("sim_semilep_plots.pdf[")
    h0.Draw("e")
    c.SaveAs("sim_semilep_plots.pdf")
    h5.Draw("colz")
    c.SaveAs("sim_semilep_plots.pdf")
    h6.Draw("colz")
    c.SaveAs("sim_semilep_plots.pdf")
    h7.Draw("colz")
    c.SaveAs("sim_semilep_plots.pdf")
    h8.Draw("colz")
    c.SaveAs("sim_semilep_plots.pdf")
    h1.Draw("colz")
    c.SaveAs("sim_semilep_plots.pdf")
    h2.Draw("colz")
    c.SaveAs("sim_semilep_plots.pdf")
    h3.Draw("colz")
    c.SaveAs("sim_semilep_plots.pdf")
    h4.Draw("colz")
    c.SaveAs("sim_semilep_plots.pdf")

    c.SaveAs("sim_semilep_plots.pdf]")


    f.Close()
