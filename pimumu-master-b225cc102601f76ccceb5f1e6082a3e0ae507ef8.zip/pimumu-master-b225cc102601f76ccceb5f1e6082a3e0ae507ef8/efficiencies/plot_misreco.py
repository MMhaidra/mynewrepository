#! /usr/bin/env python



import os, ROOT, time, sys




def plot_components (name, t, cutstring=""):
    h1 = ROOT.TH1D("h1", "", 100, 4600, 5600)
    h2 = ROOT.TH1D("h2", "", 100, 4600, 5600)
    h3 = ROOT.TH1D("h3", "", 100, 4600, 5600)
    h4 = ROOT.TH1D("h4", "", 100, 4600, 5600)
    h1.GetXaxis().SetTitle("m_{Kee}")

    h1.SetLineColor(1)
    h1.SetMarkerColor(1)
    h2.SetLineColor(2)
    h2.SetMarkerColor(2)
    h3.SetLineColor(4)
    h3.SetMarkerColor(4)
    h4.SetLineColor(6)
    h4.SetMarkerColor(6)


    n1 = t.Draw("B_M>>h1", "B_M>4880 && B_BKGCAT==50 "+cutstring, "goff")
    #n2 = t.Draw("B_M>>h2", "B_M>4880 && Psi_BKGCAT==0 && B_BKGCAT==50 && abs(Psi_MC_MOTHER_ID)==20443 "+cutstring, "goff")
    #n3 = t.Draw("B_M>>h3", "B_M>4880 && Psi_BKGCAT==0 && B_BKGCAT==50 && abs(Psi_MC_MOTHER_ID)==100443 "+cutstring, "goff")
    #n4 = t.Draw("B_M>>h4", "B_M>4880 && Psi_BKGCAT==0 && B_BKGCAT==50 && abs(Psi_MC_MOTHER_ID)<1000 "+cutstring, "goff")
    #print "signal: %g, misreco: %g, psi: %g, chi: %g"%(n1, n4, n2, n3)


    c = ROOT.TCanvas("c", "", 800, 600)

    m1 = h1.GetBinContent(h1.GetMaximumBin())
    m2 = h2.GetBinContent(h2.GetMaximumBin())
    m3 = h3.GetBinContent(h3.GetMaximumBin())
    m4 = h4.GetBinContent(h4.GetMaximumBin())

    m = max(m1, max(m2, max(m3, m4)))


    h1.GetYaxis().SetRangeUser(0, 1.1*m)
    h1.Draw("e")
    h2.Draw("esame")
    h3.Draw("esame")
    h4.Draw("esame")

    c.SaveAs("misreco_categories_"+name+".pdf")

    #if "bu" not in name : 
    return (float(n1), float(n4), float(n2), float(n3))
    return

    h5 = ROOT.TH1D("h5", "", 100, 0, 100)
    t.Draw("B_BKGCAT>>h5", "", "goff")
    h5.Draw()
    c.SaveAs("misreco_bkgcat.pdf")

    h6 = ROOT.TH1D("h6", "", 110, 0, 11000)
    c.SetLogy()
    t.Draw("Psi_MC_MOTHER_ID>>h6", "", "goff")
    h6.Draw()
    c.SaveAs("misreco_motherid.pdf")


    del c
    ROOT.gStyle.SetPadRightMargin(0.15)
    c = ROOT.TCanvas("c", "", 800, 600)
    h7 = ROOT.TH2D("h7", "", 110, 0, 11000, 100, 0, 100)
    c.SetLogx(False)
    c.SetLogy(False)
    c.SetLogz(False)
    t.Draw("B_BKGCAT:Psi_MC_MOTHER_ID>>h7", "", "goff")
    h7.Draw("colz")
    c.SaveAs("misreco_bkgcat_motherid.pdf")


def calc_frac (tu, td, ts, tl, cutstring=""):
    bus, bum, bup, buc = plot_components ("bu", tu, cutstring)
    bds, bdm, bdp, bdc = plot_components ("bd", td, cutstring)
    bcs, bsm, bsp, bsc = plot_components ("bs", ts, cutstring)
    lbs, lbm, lbp, lbc = plot_components ("lb", tl, cutstring)

    totsig = bus
    totmis = bum+bdm+bsm+lbm
    totchi = buc+bdc+bsc+lbc+bup+bdp+bsp+lbp
    allmis = totmis + totchi
    all = totsig+totmis+totchi

    from math import sqrt
    print " total signal: %.3d +/- %.3d, total misreco %.3d +/- %.3d, totchi %.3d +/- %.3d" %(totsig, sqrt(totsig), totmis, sqrt(totmis), totchi, sqrt(totchi))
    print "frac (all misreco/all)%.3f +/- %.3f, frac (misreco / all)%.3f +/- %.3f, frac (charmonium / all misreco)%.3f +/- %.3f " % (allmis / all, sqrt(allmis)/all, totmis / (totsig+totmis), sqrt(totmis)/(totmis+totsig),  totchi / allmis, sqrt(totchi)/allmis)





bumisrecofile = "/home/alexshires/data/Pimm/partreco/bdjpsipix.root"
bdmisrecofile = "/home/alexshires/data/Pimm/partreco/bujpsipix.root"
bsmisrecofile = "/home/alexshires/data/Pimm/partreco/bsjpsipix.root"


class Decay():
    def __init__(self,_name,_color=ROOT.kBlack,_style=20):
        self.name =_name
        self.color =_color
        self.style =_style
        self.label =_name

    def cfgHist(self, h):
        h.SetLineColor(self.color)
        h.SetMarkerColor(self.color)
        h.SetMarkerStyle(self.style)



def dataLegend(decs = [], drawMarker = True):
    from ROOT import TLine, TMarker, TLatex
    cache_legend = [] 
    
    yoff = 0.95
    xoff = 0.16
    idel = 0.18
    iexp = 0

    for exp in decs:
        line = TLine()
        line.SetLineColor(exp.color)
        line.SetLineStyle(exp.style)
        line.DrawLineNDC(xoff + iexp*idel, yoff- 0.01, 
                          xoff + 0.05 + iexp*idel, yoff - 0.01)

        marker = TMarker(xoff + 0.025 + iexp*idel, yoff - 0.01, exp.style)
        marker.SetMarkerColor(exp.color)
        marker.SetNDC()
        if (drawMarker): marker.Draw()
        tag = TLatex()
        tag.SetTextAlign(12)
        tag.SetTextSize(0.05)
        tag.DrawTextNDC(xoff + 0.055 + iexp*idel, yoff, exp.label)

        iexp += 1
        cache_legend += [ line, marker, tag ]

    return cache_legend 


def plot_part(tu, td, ts):
    #i
    h1 = ROOT.TH1D("h1", "", 40, 4800, 5400)
    h2 = ROOT.TH1D("h2", "", 40, 4800, 5400)
    h3 = ROOT.TH1D("h3", "", 40, 4800, 5400)
    h4 = ROOT.TH1D("h4", "", 40, 4800, 5400)
    h1.GetXaxis().SetTitle("m_{#pi#mu#mu} [MeV/c^{2}]")
    h2.GetXaxis().SetTitle("m_{#pi#mu#mu} [MeV/c^{2}]")
    h3.GetXaxis().SetTitle("m_{#pi#mu#mu} [MeV/c^{2}]")
    h4.GetXaxis().SetTitle("m_{#pi#mu#mu} [MeV/c^{2}]")


    n1 = tu.Draw("B_M>>h1", "1.0*(B_M>4600 && (B_BKGCAT-50)<0.1 && B_M<5200)", "goff")
    n2 = td.Draw("B_M>>h2", "1.0*(B_M>4600 && (B_BKGCAT-50<0.1) && B_M<5200)", "goff")
    n3 = ts.Draw("B_M>>h3", "0.25*(B_M>4600 && (B_BKGCAT-50)<0.1 && B_M<5200)", "goff")

    h4.Add(h1, 1.0)
    h4.Add(h2, 1.0)
    h4.Add(h3, 0.25)

    ROOT.gStyle.SetPadTopMargin(0.05)

    tot = Decay("tot", ROOT.kBlack, 20)
    bu = Decay("$B_{u}$", ROOT.kRed, 21)
    bd = Decay("$B_{d}$", ROOT.kBlue, 22)
    bs = Decay("$B_{s}$", ROOT.kGreen, 24)

    tot.cfgHist(h4)
    bu.cfgHist(h1)
    bd.cfgHist(h2)
    bs.cfgHist(h3)

    c = ROOT.TCanvas("c", "", 800, 600)

    h4.Draw("e")
    h3.Draw("esame")
    h2.Draw("esame")
    h1.Draw("esame")

    #l = dataLegend([tot, bu, bd, bs])

    c.SaveAs("partreco_inclusive.pdf")


#! /usr/bin/env python
import ROOT

if __name__ == '__main__':
    start = time.time()
    print time.asctime(time.localtime())
    ROOT.gROOT.SetBatch(True)

    from lhcbStyle import setLHCbStyle
    setLHCbStyle()


    fu = ROOT.TFile(bumisrecofile, "READ")
    tu = fu.Get("DecayTree")
    fd = ROOT.TFile(bdmisrecofile, "READ")
    td = fd.Get("DecayTree")
    fs = ROOT.TFile(bsmisrecofile, "READ")
    ts = fs.Get("DecayTree")
    #fl = ROOT.TFile(lbmisrecofile, "READ")
    #tl = fl.Get("DecayTree")
    #calc_frac(tu, td, ts, tl)
    plot_part(tu, td, ts)
    fu.Close()
    fd.Close()
    fs.Close()
    #fl.Close()

    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start
    sys.exit(0)

