#! /usr/bin/env python



import os,ROOT, time



def plot_bins( tree, ext="") :
    hists = []

    qsqmin = 0.
    qsqmax = 20.
    nbins = 10
    d = (qsqmax -qsqmin )/ float(nbins)
    binning = [(0,4),(4,8),(8,12),(12,16),(16,18),(18,20)]

    c2 = ROOT.TCanvas("c2","",800,600)
    for i in range(len(binning)):
        binmin,binmax = binning[i]
        cut = "%g < (dimuon_M*dimuon_M/1E6) && (dimuon_M*dimuon_M/1E6) < %g" % ( binmin , binmax)
        h = ROOT.TH1D("h"+str(i),"",10,5100,5400)
        h.Sumw2()
        tree.Draw("B_M>>h"+str(i) , cut, "goff" )
        print i , tree.GetEntries( cut ) 
        h.Scale( 1.0 / h.Integral("width"))
        h.SetLineColor(i+1)
        h.SetMarkerColor(i+1)
        c2.cd()
        h.Draw("esame")
        hists.append(h)
    c2.SaveAs("testhists_"+ext+".pdf")


def fit_bins( tree, ext ) :

    from ROOT import RooDataSet, RooRealVar, RooArgSet, RooArgList
    mass = RooRealVar('B_M','m(K#mu^{+}#mu^{-})',5120,5420)
    mass.setBins(40)
    qsq = RooRealVar('dimuon_M','q',0,5000)

    mean = RooRealVar('mean' ,'mean', 5279, 5200, 5400 )

    s0 = RooRealVar('s0' ,'s0' , 10 , 0 , 100  )
    a0 = RooRealVar('a0' ,'a0' , 0.30, 0 , 3.0 )
    n0 = RooRealVar('n0' ,'n0' , 35 ) #,0,1000 )

    s1 = RooRealVar('s1' ,'s1' , 10, 0 , 100 )
    a1 = RooRealVar('a1' ,'a1' , -0.40, -3 ,0 )
    n1 = RooRealVar('n1' ,'n1' , 35 ) #,0,1000 )

    f0 = RooRealVar('f0' ,'f0' ,0.9, 0.0, 1.0  )
    chisq = RooRealVar('c2' ,'c2' , 0.0, 1.0  )

    from ROOT import RooExponential, RooCBShape, RooAddPdf 
    CBSHP1 = RooCBShape( 'CBSHP1', 'CBSHP1', mass, mean, s0,  a0, n0 )
    CBSHP2 = RooCBShape( 'CBSHP2', 'CBSHP2', mass, mean, s1,  a1, n1 )

    SIG  = RooAddPdf('SIG','SIG', RooArgList( CBSHP1, CBSHP2 ), RooArgList( f0 ) )


    hists = []

    qsqmin = 0.
    qsqmax = 20.
    nbins = 10
    d = (qsqmax -qsqmin )/ float(nbins)

    s0arr = []
    s0err = []
    a0arr = []
    a0err = []
    s1arr = []
    s1err = []
    a1arr = []
    a1err = []
    f0arr = []
    f0err = []
    m0arr = []
    m0err = []
    x0arr = []
    x0err = []
    c1arr = []
    c1err = []
    binning = [(0,2),(4,8),(8,12),(12,16),(16,18),(18,20)]

    c2 = ROOT.TCanvas("c2","",800,600)
    c2.SaveAs("testfit_"+ext+".pdf[")

    #for i in range(len(binning)):
    #    binmin,binmax = binning[i]
    for i in range(nbins-1):
        binmin,binmax = (i*d, (i+1)*d )
        cut = "%g <(dimuon_M*dimuon_M/1E6) && (dimuon_M*dimuon_M/1E6) < %g" % ( binmin , binmax)
        print cut
        data = RooDataSet('data','data',tree,RooArgSet(mass,qsq),cut)
        data.Print()
        hist = data.binnedClone()
        hist.Print()
        res = SIG.fitTo( hist , ROOT.RooFit.Save(True) , ROOT.RooFit.NumCPU(5) )
        res.Print()
        c2.cd()
        p = mass.frame()
        hist.plotOn(p, RooFit.Name("data") )
        SIG.plotOn(p, RooFit.Name("pdf") )
        p.Draw()
        chisqv = p.chiSquare("pdf","data")
        c2.SaveAs("testfit_"+ext+".pdf")

        m0arr += [ mean.getVal() ] 
        m0err += [ mean.getError() ] 
        f0arr += [ f0.getVal() ] 
        f0err += [ f0.getError() ] 
        s0arr += [ s0.getVal() ] 
        s0err += [ s0.getError() ] 
        a0arr += [ a0.getVal() ] 
        a0err += [ a0.getError() ] 
        s1arr += [ s1.getVal() ] 
        s1err += [ s1.getError() ] 
        a1arr += [ a1.getVal() ] 
        a1err += [ a1.getError() ] 
        c1arr += [ chisqv  ] 
        c1err += [ 0.0 ] 
        if i < nbins :
            x0arr += [ i*d+0.5*d ]
        if i == nbins : 
            x0arr += [9]
        if i == nbins+1: 
            x0arr += [9]
        x0err += [ 0.5*d ] 

    c2.SaveAs("testfit_"+ext+".pdf]")

    vals = [ (m0arr,m0err),(f0arr,f0err),(s0arr,s0err),(a0arr,a0err),(s1arr,s1err),(a1arr,a1err),(c1arr,c1err) ]
    titles = [ "mean", "fraction", "sigma0", "a0", "sigma1", "a2", "#chi^{2}" ] 
    vars = [ mean, f0, s0, a0, s1, a1, chisq ] 

    c2.SaveAs("testgraph_"+ext+".pdf[")
    import array
    for v,tit,var in zip(vals,titles,vars) :
        xv,xe = v
        g = ROOT.TGraphErrors( len(x0arr) 
            , array.array('d',x0arr) , array.array('d',xv) 
            , array.array('d',x0err) , array.array('d',xe) 
            ) 
        g.Draw("ap")
        g.GetHistogram().GetXaxis().SetTitle("q^{2} / GeV^{2}")
        g.GetHistogram().GetYaxis().SetTitle( tit )
        g.GetHistogram().GetYaxis().SetRangeUser( var.getMin(), var.getMax() )
        c2.SaveAs("testgraph_"+ext+".pdf")
    c2.SaveAs("testgraph_"+ext+".pdf]")







if __name__=='__main__':
    start = time.time()
    print time.asctime(time.localtime())

    from lhcbStyle import setLHCbStyle
    setLHCbStyle()
    from ROOT import RooMsgService,RooFit
    RooMsgService.instance().setGlobalKillBelow(RooFit.ERROR)
    RooMsgService.instance().setSilentMode(True)
    ROOT.gROOT.SetBatch(True)

    base = "/home/alexshires/data/Pimm/norm/"
    pmmsimfile = os.path.join(base,"with_bdt_kmumu_totisoln_newpid_sel_vars.root")
    kmmsimfile = os.path.join(base,"with_bdt_pimumutot_isoln_newpid_sel_vars.root")



    f = ROOT.TFile( kmmsimfile, "READ")
    t = f.Get("DecayTree")
    plot_bins( t , "kmm" ) 
    fit_bins( t , "kmm" ) 
    f.Close()

    f = ROOT.TFile( pmmsimfile, "READ")
    t = f.Get("DecayTree")
    plot_bins( t , "pimm" ) 
    fit_bins( t , "pimm" ) 
    f.Close()
    
    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start
    sys.exit(0)

