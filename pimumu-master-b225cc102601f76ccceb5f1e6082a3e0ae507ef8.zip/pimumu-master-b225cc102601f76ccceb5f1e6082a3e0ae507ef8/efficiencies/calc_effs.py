#! /usr/bin/env python


import ROOT
presel = ""
presel += "(hadron_isMuonLoose<1)"
presel += "&&(hadron_InAccMuon>0)"
presel += "&&(B_PT > 300)"
presel += "&&(hadron_PT > 300)"
presel += "&&(muplus_PT > 300)"
presel += "&&(muminus_PT > 300)"
presel += "&&(muplus_isMuon == 1)"
presel += "&&(muminus_isMuon == 1)"
trigger = ""
trigger += "(B_L0MuonDecision_TOS==1)"
trigger += "&&(B_Hlt1TrackMuonDecision_TOS==1||B_Hlt1TrackAllL0Decision_TOS==1)"
trigger += "&&(B_Hlt2Topo2BodyBBDTDecision_TOS==1"
trigger += "||B_Hlt2Topo3BodyBBDTDecision_TOS==1"
trigger += "||B_Hlt2TopoMu2BodyBBDTDecision_TOS==1"
trigger += "||B_Hlt2TopoMu3BodyBBDTDecision_TOS==1"
trigger += "||B_Hlt2DiMuonDetachedDecision_TOS==1)"

offsel = "BDT_4>0.5 && hadron_DataPIDK<-3 && muplus_DataProbNNmu>0.2 && muminus_DataProbNNmu>0.2 && muminus_DataProbNNk<0.4"
kaonsel = "BDT_4>0.5 && hadron_DataPIDK>3 && muplus_DataProbNNmu>0.2 && muminus_DataProbNNmu>0.2"

andstr = " && "


piqsqveto = "!((8<qsq && qsq<11) || (12.5<qsq && qsq<15))"
kqsqveto = "!((8<qsq && qsq<11) || (12.5<qsq && qsq<15))"




from ROOT import TFile

def get_tree(filename, treename="DecayTree"):
    f = TFile(filename, "READ")
    print f
    if not f.IsOpen():
        print "file not open"
        f.Close()
        return (None, None)
    tree = f.Get(treename)
    print tree
    if not tree:
        print "no tree"
        f.Close()
    return (f, tree)


import time
from value import Value

pimumugeo = Value(0.16459, 0.00046)
kmumugeo = Value(0.17050, 0.00090)
pimumureco = Value(0.19551, 0.00042)
kmumureco = Value(0.19720, 0.00055)
jpsikgeo = Value(0.16860, 0.00090)
jpsikreco = Value(0.20121, 0.00029)
jpsipigeo = Value(0.16860, 0.00090)
jpsipireco = Value(0.20121, 0.00029)


qsqbins = [(0, 25), (0.1, 2), (2, 4), (4, 6), (6, 8),
           (11, 12.5), (15, 17), (17, 19), (19, 22), (22, 25),
           (1, 6), (15, 22)
          ]

if __name__ == '__main__':
    start = time.time()
    print time.asctime(time.localtime())
    print " setting batch mode "
    ROOT.gROOT.SetBatch(True)
    from argparse import ArgumentParser
    parser = ArgumentParser()

    jpsikfile = "/home/alexshires/data/Pimm/mc/with_bdt_jpsik_12_mc_isoln_newpid_corr_vars.root"
    kmumufile = "/home/alexshires/data/Pimm/mc/with_bdt_kmumu_12_mc_isoln_newpid_corr_vars.root"
    pimumufile = "/home/alexshires/data/Pimm/mc/with_bdt_pimumu_12_mc_isoln_magupdown_newpid_corr_vars.root"
    #jpsipifile = "/home/alexshires/data/Pimm/mc/with_bdt_jpsipi_12_mc_isoln_newpid_corr_qsq_corr_selected_vars.root"

    f1, kmumutree = get_tree(kmumufile)
    f2, pimumutree = get_tree(pimumufile)
    f3, jpsiktree = get_tree(jpsikfile)
    #f4, jpsipitree = get_tree(jpsipifile)

    njpsikstrip = Value(jpsiktree.GetEntries())
    njpsiktrig = Value(jpsiktree.GetEntries(trigger))
    njpsiksel = Value(jpsiktree.GetEntries(presel+andstr+trigger+andstr+kaonsel))

    jpsikseleff = njpsiksel / njpsikstrip

    jpsikeff = jpsikreco * jpsikgeo * jpsikseleff

    njpsipistrip = Value(1) #Value(jpsipitree.GetEntries())
    njpsipitrig = Value(1) #Value(jpsipitree.GetEntries(trigger))
    njpsipisel = Value(1) #Value(jpsipitree.GetEntries(presel+andstr+trigger+andstr+kaonsel))

    jpsipiseleff = njpsipisel / njpsipistrip

    jpsipieff = jpsipireco * jpsipigeo * jpsipiseleff


    geoeff = pimumugeo 
    recoeff = pimumureco
    ntot = Value(pimumutree.GetEntries())
    npresel = Value(pimumutree.GetEntries(presel))
    nqsq = Value(pimumutree.GetEntries(presel+andstr+piqsqveto))
    nbdt = Value(pimumutree.GetEntries(presel+andstr+piqsqveto+andstr+offsel))
    ntrig = Value(pimumutree.GetEntries(presel+andstr+piqsqveto+andstr+offsel+andstr+trigger))


    print geoeff, recoeff, npresel/ntot, nqsq/npresel, nbdt/nqsq, ntrig/nbdt, geoeff * recoeff * ntrig/ntot 

    f = open('effspy.txt', 'w')

    for qb in qsqbins:
        qsqmin, qsqmax = qb
        qsqcut = "B_BKGCAT<11 && %.1f<qsq && qsq<%.1f" % (qsqmin, qsqmax)
        print qsqcut
        nkmmstrip = Value(kmumutree.GetEntries(qsqcut))
        nkmmsel = Value(kmumutree.GetEntries(presel+andstr+qsqcut+andstr+trigger+andstr+kaonsel+andstr+kqsqveto))

        npimmstrip = Value(pimumutree.GetEntries(qsqcut))
        npimmsel = Value(pimumutree.GetEntries(presel+andstr+qsqcut+andstr+trigger+andstr+offsel+andstr+piqsqveto))

        kmmseleff = nkmmsel / nkmmstrip
        pimmseleff = npimmsel / npimmstrip

        kmumueff = kmumugeo * kmumureco * kmmseleff
        pimumueff = pimumugeo * pimumureco * pimmseleff

        effratio_kpi = (kmumueff / pimumueff) 
        effratio_jpi = (jpsikeff / pimumueff)
        effratio_jk = (jpsikeff  / kmumueff)
    
        print npimmstrip, npimmsel, nkmmstrip, nkmmsel

        print pimumueff, kmumueff#, jpsikeff, jpsipieff

        line = "%s\t%s\t%s\t%s\t%s\t%s\n" % \
                (effratio_kpi.v, effratio_kpi.e,
                 effratio_jpi.v, effratio_jpi.e,
                 effratio_jk.v, effratio_jk.e
                )
        f.write(line)
    f.close()

    f1.Close()
    f2.Close()
    f3.Close()
    #f4.Close()

    pass
