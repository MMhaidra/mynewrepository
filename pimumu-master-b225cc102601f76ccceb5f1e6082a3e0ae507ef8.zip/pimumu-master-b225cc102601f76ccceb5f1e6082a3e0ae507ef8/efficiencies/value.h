#ifndef VALUE
#define VALUE

class value {
    public:
        value() { central = 1.0 ; error = 0.0 ; } 
        value(double a, double b = 0.0 ) { central = a ; error = b ; } 

        const double val() const { return central ; } 
        const double err() const { return error ; } 

        value operator* ( const value & v) {
            double error  =  (this->error * this->error * v.val() * v.val()) ;
            error +=  (v.err() * v.err() * this->central * this->central ) ;
            return value( this->central * v.val() , sqrt(error)) ;
        }   

        value operator/ ( const value & v) {
            if (v.val() <= 0 ) return value(0.0,0.0) ;
            double error1  =  (this->error * this->error / v.val() / v.val()) ;
            double error2  =  (v.err() * v.err() * this->central * this->central ) ;
            error2 /=  (v.val() * v.val() * v.val() * v.val() ) ;
            return value( this->central / v.val() , sqrt(error1+error2)) ;
        } 

        value divb ( const value & v ) { //divide using binomial stats
            if (v.val() <= 0 ) return value(0.0,0.0) ;
            double w = this->central / v.val() ;
            double error1 = ( 1. - 2.* w ) * this->error * this->error ;
            error1 +=  ( w * w * v.err() * v.err() ) ;
            error1 /= ( v.val() * v.val() ) ;
            //std::cout << "DEBUG " << w << '\t' << this->central << '\t' << v.val() << '\t' ;
            //std::cout << error1 << '\t' << this->error << '\t' << v.err() << std::endl ;
            return value ( w , sqrt(error1) ) ;
        }

        friend std::ostream& operator<< (std::ostream& stream, const value &v) ; //print

    private:

        double central ;
        double error ;

};

std::ostream& operator<< (std::ostream& stream, const value &v) { //print
    stream << "(" << v.val() << ", " << v.err() << " )" ;
}

#endif /* VLAUE */
