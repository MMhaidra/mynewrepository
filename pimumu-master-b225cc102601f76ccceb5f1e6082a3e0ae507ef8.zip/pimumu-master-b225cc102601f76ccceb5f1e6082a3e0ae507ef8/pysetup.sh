echo `which root`
echo `which gcc`
export PYTHONPATH=${PWD}/selection:${PWD}/efficiencies:${PYTHONPATH}
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${PWD}/cpp/lib
