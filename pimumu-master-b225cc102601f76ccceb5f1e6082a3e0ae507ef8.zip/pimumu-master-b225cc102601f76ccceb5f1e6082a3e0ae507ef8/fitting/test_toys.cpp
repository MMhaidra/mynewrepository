#include <iostream>
#include "RooDataSet.h"
#include "RooGaussian.h"
#include "RooRealVar.h"
#include "RooMsgService.h"
#include "RooArgSet.h"
#include "RooCBShape.h"
#include "RooPlot.h"
#include "RooArgList.h"
#include "RooMinuit.h"
#include "TH1D.h"
#include "TMath.h"
#include "TCanvas.h"
#include "Math/DistFunc.h"
#include "TStyle.h"
#include "RooArgList.h"
#include "RooFit.h"
#include "RooAddPdf.h"
#include "RooFitResult.h"
#include "boost/date_time/posix_time/posix_time.hpp"
#include <sstream>
// boost
#include "boost/program_options.hpp"
namespace dt = boost::posix_time ;
namespace po = boost::program_options;



class Pull {
    public:
        Pull(TString s) {
            pullvar = new RooRealVar(s+"_pull",TString("pull of ")+s,0,-5,5) ;
            args = new RooArgSet(*pullvar) ;
            data = new RooDataSet(s+"_data","",RooArgSet(*pullvar)) ;
            mean = new RooRealVar(s+"_mean","",-10,10);
            sigma = new RooRealVar(s+"_sigma","",0,20);
            pdf = new RooGaussian(s+"_pdf","",*pullvar,*mean,*sigma);
        }

    private :

        Pull( Pull & ) ;
        Pull operator=( const Pull & )  ;
    public :

        ~Pull( ) {
            delete pdf ;
            delete mean ;
            delete sigma ;
        }

        int fitPull(  ) {
            RooFitResult * res = pdf->fitTo( *data , RooFit::Save(true) ) ;
            return 1 ;
        }

        void plotPull( ) {
            gStyle->SetOptFit(1111) ;
            RooPlot * p = pullvar->frame() ;
            data->plotOn(p);
            pdf->plotOn(p) ;
            pdf->paramOn(p);
            p->Draw() ;
        }

        void add( double val ) 
        {
            pullvar->setVal( val ) ;
            data->add( *args ) ;
        }



    private :
        RooRealVar * pullvar ;
        RooArgSet * args ; 
        RooDataSet * data ;
        RooAbsPdf * pdf ;
        RooRealVar * mean ;
        RooRealVar * sigma;

} ;



struct config {
    int ntoys ;
    int ndata ;
    bool quiet ;
    bool gaus ;
    bool ext ;
} ;

int main(int argc, char *argv[])
{

    dt::ptime starttime = dt::second_clock::local_time();

    config c;

    po::options_description desc("Allowed options") ;
    desc.add_options()
        ("help", "show this help")
        ("ntoys,t", po::value<int>(&c.ntoys)->default_value(100), "number of toy datasets to generate")
        ("ndata,d", po::value<int>(&c.ndata)->default_value(100), "number of data per datasets")
        ("quiet,q", po::bool_switch(&c.quiet),"lots of stdout")
        ("gaus,g", po::bool_switch(&c.gaus),"lots of stdout")
        ("ext,e", po::bool_switch(&c.ext),"lots of stdout")
        ;

    // actually do the parsing
    po::variables_map vm;
    po::store(po::parse_command_line(argc, argv, desc), vm);
    po::notify(vm);

    // show help and exit
    if ((argc == 0) || (vm.count("help"))) {
        std::cout << desc << "\n";
        return 1;
    }


    namespace po = boost::program_options;

    double true_meanval =  5279.8 ;
    double true_sigmaval1 = 25 ;
    double true_alphaval1 = 2 ;
    double true_nvalval1 = 4 ;
    double true_sigmaval2 = 15 ;
    double true_alphaval2 = -2 ;
    double true_nvalval2 = 7 ;
    double true_genfracval = 0.7 ;
    const double yieldval = c.ndata ;
    if ( c.quiet ) {
        RooMsgService::instance().setGlobalKillBelow(RooFit::ERROR);
        RooMsgService::instance().setSilentMode(true);
    }



    RooRealVar mass("x","x",5100,5500) ;
    RooRealVar genmean("mean","",true_meanval);
    RooRealVar gensigma1("sigma1","",true_sigmaval1);
    RooRealVar genalpha1("alpha1","",true_alphaval1);
    RooRealVar gennval1("nval1","",true_nvalval1);
    RooRealVar gensigma2("sigma2","",true_sigmaval2);
    RooRealVar genalpha2("alpha2","",true_alphaval2);
    RooRealVar gennval2("nval2","",true_nvalval2);
    RooRealVar genfrac("genfrac","",true_genfracval);
    RooCBShape gencbpdf1("cbpdf1","",mass,genmean,gensigma1,genalpha1,gennval1) ;
    RooCBShape gencbpdf2("cbpdf2","",mass,genmean,gensigma2,genalpha2,gennval2) ;
    RooAbsPdf * gentotpdf ;
    if ( c.gaus )  {
        gentotpdf = new RooGaussian("gentotpdf","",mass,genmean,gensigma1) ;
    }
    else{
        gentotpdf = &gencbpdf1 ; 
        // new RooAddPdf("gentotpdf","", RooArgList(gencbpdf1,gencbpdf2),genfrac);
    }

    //intial data fit to get NLL (0)
    //


    int numfreepars = 0 ;

    RooRealVar fitmean("mean","x",4000,6400);
    RooRealVar fitsigma1("sigma1","",20,-1000,1000);
    RooRealVar fitalpha1("alpha1","",0.1,-1000,1000);
    RooRealVar fitnval1("nval1","",0.1,-1000,1000);
    RooRealVar fitsigma2("sigma2","",20,-1000,1000);
    RooRealVar fitalpha2("alpha2","",-0.1,-1000.,1000.);
    RooRealVar fitnval2("nval2","",1.,-1000.,1000.);
    RooRealVar fitfrac("fitfrac","",0.7,-10,10);
    RooRealVar fityield("yield","",0.1,0,100000);
    RooCBShape fitcbpdf1("cbpdf1","",mass,fitmean,fitsigma1,fitalpha1,fitnval1) ;
    RooCBShape fitcbpdf2("cbpdf2","",mass,fitmean,fitsigma2,fitalpha2,fitnval2) ;
    RooAbsPdf * fittotpdf ;
    if ( c.gaus ) {
        fittotpdf = new RooGaussian("fittotpdf","",mass,fitmean,fitsigma1) ;
        numfreepars += 2 ;
    }
    else{
        //fittotpdf = new RooAddPdf("fittotpdf","", RooArgList(fitcbpdf1,fitcbpdf2),fitfrac);
        fittotpdf = &fitcbpdf1;
        numfreepars += 8 ;
    }
    RooAbsPdf *subpdf = fittotpdf ;
    if ( c.ext ) {
        fittotpdf  = new RooAddPdf("totpdf","",RooArgList(*subpdf), RooArgList( fityield));
        numfreepars += 1 ;
    }

    //toys config
    int ntoys = c.ntoys;
    RooDataSet * data ;
    //pulls
    Pull pullmean("mean");
    Pull pullsigma1("sigma1");
    Pull pullalpha1("alpha1");
    Pull pullnval1("nval1");
    Pull pullsigma2("sigma2");
    Pull pullalpha2("alpha2");
    Pull pullnval2("nval2");
    Pull pullyield("yield");
    Pull pullnll("nll");

    RooFitResult * res ;
    //generating values
    int migradStatusCode, hesseStatusCode, covarianceQuality ;
    bool isAGoodFit ;
    //loop
    TCanvas * tmpcan = new TCanvas("tmpcan","",800,600);
    tmpcan->SaveAs("toytest_debug.pdf[");
    int failedfits(0) ;
    for ( int i=0 ;i<ntoys ; ++i )
    {
        if ( i%(ntoys/10)==0 ) std::cout << "toy : " << i << std::endl ;
        //gen toy data
        data = gentotpdf->generate( RooArgSet(mass)  , c.ndata , RooFit::Extended()) ;
        //create TEST nll
        fitmean.setVal(true_meanval);
        fitsigma1.setVal(true_sigmaval1);
        fitalpha1.setVal(true_alphaval1);
        fitnval1.setVal(true_nvalval1);
        fitsigma2.setVal(true_sigmaval2);
        fitalpha2.setVal(true_alphaval2);
        fitnval2.setVal(true_nvalval2);
        fityield.setVal(yieldval);
        //true values
        //arb starting params
        /*fitmean.setVal(5280);
          fitsigma1.setVal(20);
          fitalpha1.setVal(1);
          fitnval1.setVal(5);
          fitsigma2.setVal(20);
          fitalpha2.setVal(-1);
          fitnval2.setVal(5);
          fityield.setVal(1000);*/
        //constants
        //fitnval1.setVal(true_nvalval1);
        //fitnval1.setConstant(true);
        //fitnval2.setVal(true_nvalval2);
        //fitnval2.setConstant(true);
        //data->Print() ;
        //
        //from Sam
        //// build likelihood
        RooAbsReal * nll = fittotpdf->createNLL(*data);
        double truenllval = nll->getVal() ;

        //
        //// set up MINUIT
        RooMinuit minu(*nll);
        minu.setStrategy(2); // ensure minimum true, errors correct
        //
        //// call MIGRAD -- minimises the likelihood
        migradStatusCode = minu.migrad(); // catch status code
        //
        //// could also get an intermediary RooFitResult if you want
        //// RooFitResult *migradFitResult = m.save();
        //// int migradStatusCode2 = migradFitResult->status();
        //
        //// call HESSE -- calculates error matrix
        hesseStatusCode = minu.hesse();
        //
        res = minu.save(); // equivalent result to that from fitTo call
        //
        //
        //// check for success
        covarianceQuality = res->covQual();
        isAGoodFit = ((hesseStatusCode==0) && (migradStatusCode==0) && (covarianceQuality==3));

        double sign = ( fitmean.getVal() > true_meanval ) ? -1 : 1 ;
        //calc nll
        double dnll = 2.0 *  fabs( nll->getVal() - truenllval ) ;
        //change d.ofo.f
        //
        double pv = 1. - TMath::Prob(dnll,numfreepars) ;
        double qc = ROOT::Math::chisquared_quantile(pv,1);
        double pullnllval = sign * sqrt(qc) ;

        //debug
        if ( i < 10 ) {
            //data->Print();
            //res->Print() ;
            //std::cout << p.pullmean << '\t' << p.pullsigma << '\t' << p.pullyield << std::endl ;
            RooPlot * p = mass.frame() ;
            data->plotOn(p) ;
            fittotpdf->plotOn(p) ;
            p->Draw();
            tmpcan->SaveAs("toytest_debug.pdf");
            std::cout << "ll method " << fityield.getVal() << '\t' << yieldval << '\t' << sign * sqrt( 2.0 * fabs( nll->getVal() -  truenllval )  ) << '\t' <<  nll->getVal() <<  '\t' <<  truenllval << '\t' << sign << std::endl  ;

        }
        //
        if ( ! isAGoodFit ) { ++failedfits ; continue ; }
        //
        //res = fittotpdf.fitTo( *data 
        //        //, RooFit::Extended(true) 
        //        , RooFit::Save(true) ) ;
        //create pulls
        pullmean.add ( (fitmean.getVal() - true_meanval )  / fitmean.getError() );
        pullsigma1.add (( fitsigma1.getVal() -  true_sigmaval1 )  / fitsigma1.getError() );
        if ( !c.gaus ) {
            pullalpha1.add (( fitalpha1.getVal() -  true_alphaval1 )  / fitalpha1.getError() );
            pullnval1.add (( fitnval1.getVal() -  true_nvalval1 )  / fitnval1.getError() );
            pullsigma2.add (( fitsigma2.getVal() -  true_sigmaval2 )  / fitsigma2.getError() );
            pullalpha2.add (( fitalpha2.getVal() -  true_alphaval2 )  / fitalpha2.getError() );
            pullnval2.add (( fitnval2.getVal() -  true_nvalval2 )  / fitnval2.getError()) ;
        }
        pullyield.add (( fityield.getVal() -  yieldval )  / fityield.getError() );
        pullnll.add ( pullnllval ) ;
        delete data ;
    }
    tmpcan->SaveAs("toytest_debug.pdf]");
    std::cout<< "FAILED: " << failedfits << " FROM " << c.ntoys << std::endl ;
    //histograms
    //
    pullmean.fitPull() ;
    pullsigma1.fitPull() ;
    if ( !c.gaus ) {
        pullalpha1.fitPull() ;
        pullnval1.fitPull() ;
        pullsigma2.fitPull() ;
        pullalpha2.fitPull() ;
        pullnval2.fitPull() ;
    }
    if ( c.ext ) {
        pullyield.fitPull() ;
    }
    pullnll.fitPull() ;
    //
    RooPlot * p = 0 ;
    gStyle->SetOptFit(1111) ;
    std::stringstream outfile ;
    outfile << "toytests_" << c.ntoys << "_" << c.ndata ;
    if ( c.gaus ) outfile << "_gaus" ;
    else outfile << "_doublecb" ;
    if ( c.ext ) outfile << "_extended" ;
    outfile << "_pulls.pdf" ;
    TCanvas * can = new TCanvas("c","",800,600) ;
    can->SaveAs((outfile.str()+"[").c_str()) ;
    pullmean.plotPull();
    can->SaveAs(outfile.str().c_str()) ;
    pullsigma1.plotPull();
    can->SaveAs(outfile.str().c_str()) ;
    if ( !c.gaus ) {
        pullalpha1.plotPull();
        can->SaveAs(outfile.str().c_str()) ;
        pullnval1.plotPull();
        can->SaveAs(outfile.str().c_str()) ;
        pullsigma2.plotPull();
        can->SaveAs(outfile.str().c_str()) ;
        pullalpha2.plotPull();
        can->SaveAs(outfile.str().c_str()) ;
        pullnval2.plotPull();
        can->SaveAs(outfile.str().c_str()) ;
    }
    if ( c.ext ) {
        pullyield.plotPull();
        can->SaveAs(outfile.str().c_str()) ;
    }
    pullnll.plotPull();
    can->SaveAs(outfile.str().c_str()) ;
    can->SaveAs((outfile.str()+"]").c_str()) ;


    dt::ptime endtime  = dt::second_clock::local_time();
    dt::time_duration difftime = endtime - starttime;
    std::cout << "time  " << difftime.total_seconds() << " seconds " << std::endl ;

    return 0;
}
