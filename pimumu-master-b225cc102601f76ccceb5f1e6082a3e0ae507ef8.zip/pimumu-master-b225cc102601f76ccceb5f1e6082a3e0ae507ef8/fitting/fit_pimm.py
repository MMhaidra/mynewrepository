#! usr/bin/env python
"""
fit pimumu

fit jpsipi - save workspace

fit misID - save workspace

fit NR - load workspace

"""

import ROOT,os,time,sys,re,math



def fit_misreco( options ) :

    #construct CB
    mass = ROOT.RooRealVar("kmm_mass","",4900,5700)
    cbshape
    #get dataset
    f = ROOT.TFile( options.filename ) 
    t = f.Get("DecayTree")
    data = ROOT.RooDataSet( "data","", t, 
    f.Close()



if __name__=='__main__':

    print " setting batch mode " 
    ROOT.gROOT.SetBatch(True)
    print " here goes " 

    from lhcbStyle import setLHCbStyle
    setLHCbStyle()
    gStyle.SetOptStat(False)
    gStyle.SetNdivisions(505,"y")
    gStyle.SetNdivisions(505,"x")
    gStyle.SetEndErrorSize(5)
    gStyle.SetPadTopMargin(0.11)

    filename ="" 
    treename =""
    from optparse import OptionParser, OptionGroup

    parser = OptionParser()
    parser.add_option( "-d", "--debug", dest="debug", action="store_true", default=False , help="testing" ) 

    parser.add_option( "-r", "--misreco", dest="misreco", action="store_true", default=False, help="misreco" ) 
    
    
    (options,args) = parser.parse_args()

    if not options.debug :
        RooMsgService.instance().setGlobalKillBelow(RooFit.ERROR)
        RooMsgService.instance().setSilentMode(True)
 

    start = time.time()

    print time.asctime(time.localtime())

    #


    #run fits

    print time.asctime(time.localtime())

    print "time taken", end-start


