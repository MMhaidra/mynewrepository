#include <iostream>


int main(int argc, char *argv[])
{
    std::cout << " fitting pimumu" << std::endl ;

    return 0;
}




