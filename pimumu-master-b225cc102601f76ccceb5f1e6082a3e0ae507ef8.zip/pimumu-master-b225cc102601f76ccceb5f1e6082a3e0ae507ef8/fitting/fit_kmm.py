#! /usr/bin/env python
import ROOT


from ROOT import RooRealVar, RooCBShape, RooAddPdf, RooExponential
from ROOT import RooDataSet, RooArgSet, RooFit, RooArgList
from ROOT import RooFormulaVar

base = "/home/alexshires/data/"
def config_pdf( mass, oppo=False, scale=False ) :
    """configure pdf"""
    mean = RooRealVar('mean' , 'mean', 5279, 5200, 5400 )
    s0 = RooRealVar('s0' ,'s0' , 10 , 0 , 100  )
    a0 = RooRealVar('a0' ,'a0' , 0.30, 0.05 , 10.0 )
    n0 = RooRealVar('n0' ,'n0' , 4 ,0, 100 )
    sc = RooRealVar("sc", "sc", 1, 8 ) 
    s1 = RooRealVar('s1' ,'s1' , 30, 0 , 40 )
    if scale :
        #s1 = RooFormulaVar("s1", "@0*@1", RooArgList(s0, sc) ) 
        s0 = RooFormulaVar("s0", "@0*@1", RooArgList(s1, sc) ) 
    a1 = RooRealVar('a1' ,'a1' , 0.40, 0 , 10 )
    if oppo:
        a1 = RooRealVar('a1' ,'a1' , -0.40, -10 , -0.05 )
    n1 = RooRealVar('n1' , 'n1' , 5 ) #  ,0,100 )
    f0 = RooRealVar('f0' , 'f0' , 0.5, 0.0, 1.0  )
    CBSHP1 = RooCBShape( 'CBSHP1', 'CBSHP1', mass, mean, s0,  a0, n0 )
    CBSHP2 = RooCBShape( 'CBSHP2', 'CBSHP2', mass, mean, s1,  a1, n1 )
    #CBSHP1 = RooGaussian( 'CBSHP1', 'CBSHP1', mass, mean, s0 )
    #CBSHP2 = RooGaussian( 'CBSHP2', 'CBSHP2', mass, mean, s1 )
    SIG  = RooAddPdf('SIG', 'SIG', RooArgList( CBSHP1, CBSHP2 )
            , RooArgList( f0 ) )
    e0   = RooRealVar('e0', 'e0', 0, -0.1, 0.1)
    BKG1  =  RooExponential('BKG', 'BKG', mass, e0) 
    nsig1 = RooRealVar('nsig', 'nsig', 1e6, 0, 1e9)
    nbkg1 = RooRealVar('nbkg', 'nbkg', 1e3, 0, 1e9) 
    PDF1 = RooAddPdf('PDF', 'PDF', RooArgList( SIG, BKG1 )
            , RooArgList( nsig1, nbkg1 ) )
    PDF1 = SIG 
    return (PDF1, nsig1, nbkg1, [CBSHP1, CBSHP2, SIG, BKG1], 
            [mean,s0,a0,n0,s1,a1,n1,f0,e0,sc])

from ROOT import TGraphErrors
def fit_params( tree, binning = [] ) :
    """fit in terms of binning scheme"""
    mass = RooRealVar("B_M", "mass", 5075, 5700)
    qsq = RooRealVar("qsq", "qsq", 0, 0, 25)
    pdf, nsig, nbkg, pdfs, params = config_pdf( mass, True, True )
    #
    defdict = {}
    resdict = {}
    errdict = {}
    pars = []
    for par in params:
        if par.ClassName()!='RooFormulaVar':
            pars.append(par)
            resdict[par.GetName()] = [] 
            errdict[par.GetName()] = [] 
            defdict[par.GetName()] = par.getVal()
    print params
    print pars
    print resdict
    print errdict
    print defdict
    from ROOT import RooGaussian
    fracmean = RooRealVar("fm", "", 0.7)
    fracsigma = RooRealVar("fs", "", 0.1)
    fracgaus = RooGaussian("fg", "", params[7], fracmean, fracsigma)

    #
    data = RooDataSet('data', 'data', tree, RooArgSet(mass, qsq))
    xvals = []
    xerrs = []
    name = "qsqbinfits.pdf"
    can = ROOT.TCanvas("c", "", 800, 600)
    can.SaveAs(name+"[")
    for bins in binning:
        print bins
        qsqmin, qsqmax = bins
        for par in pars:
            #print par, defdict[par.GetName()]
            par.setVal(defdict[par.GetName()] )
        cut = "qsq>%s && qsq<%s" % (qsqmin, qsqmax)
        xvals.append( 0.5*(qsqmin+qsqmax) )
        xerrs.append( 0.5*(qsqmax-qsqmin) )

        print cut
        subdata = data.reduce(cut)
        subdata.Print()
        res = pdf.fitTo( subdata
                , RooFit.NumCPU(6)
                , RooFit.Save(True) 
                , RooFit.ExternalConstraints( RooArgSet ( fracgaus ) ) 
                )

        plot = mass.frame()
        subdata.plotOn( plot )
        pdf.plotOn( plot )
        pdf.plotOn( plot , RooFit.Components("CBSHP1")
            , RooFit.LineStyle( ROOT.kDotted ) 
            , RooFit.LineColor( ROOT.kRed ) 
            )
        pdf.plotOn( plot , RooFit.Components("CBSHP2")
            , RooFit.LineStyle( ROOT.kDotted ) 
            , RooFit.LineColor( ROOT.kRed ) 
            )
        pdf.plotOn( plot , RooFit.Components("BKG") 
            , RooFit.LineStyle( ROOT.kDashed ) 
            , RooFit.LineColor( ROOT.kBlue ) 
            )
        plot.Draw()
        can.SaveAs(name)



        for par in pars :
            resdict[par.GetName()].append( par.getVal() )
            errdict[par.GetName()].append( par.getError() )

        res.Print()
    can.SaveAs(name+"]")
    
    graphs = {}
    import array
    for par in pars :

        graphs[par.GetName()] = \
                TGraphErrors( len(xvals) ,
                              array.array('d',xvals) ,
                              array.array('d',resdict[par.GetName()]) ,
                              array.array('d',xerrs ),
                              array.array('d',errdict[par.GetName()]) 
                                            )
    return graphs
    







if __name__ == '__main__':

    print " setting batch mode " 
    ROOT.gROOT.SetBatch(True)
    print " here goes " 
    from ROOT import gStyle, RooMsgService
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()
    gStyle.SetOptStat(False)
    gStyle.SetNdivisions(505,"y")
    gStyle.SetNdivisions(505,"x")
    gStyle.SetEndErrorSize(5)
    gStyle.SetPadTopMargin(0.11)
    filename = "" 
    treename = ""
    from argparse import ArgumentParser 
    parser = ArgumentParser()
    parser.add_argument( "-r", "--misreco", dest="misreco"
            , action="store_true", default=False, help="misreco" ) 
    parser.add_argument( "-d", "--data", dest="data"
            , type=str, default=None , help="testing" ) 
    parser.add_argument( "-s", "--sim", dest="sim"
            , type=str, default=None , help="testing" ) 
    options = parser.parse_args()

    RooMsgService.instance().setGlobalKillBelow(RooFit.ERROR)
    RooMsgService.instance().setSilentMode(True)

    datagraphs = []
    dataqsqbins = [ (0, 1.1),
                    (1.1, 3),
                    (3, 5),
                    (5, 8),
                    (8, 11),
                    (11, 12.5),
                    (12.5, 15),
                    (15, 17),
                    (17, 19),
                    (19, 22),
                    ]

    simqsqbins = []
    vals = range(0, 25, 4)
    for i in vals:
        simqsqbins.append((i, i+1))

    if options.data :
        f = ROOT.TFile( options.data, "READ")
        t = f.Get("DecayTree")
        datagraphs = fit_params( t, dataqsqbins ) 
        f.Close()
    if options.sim :
        f = ROOT.TFile( options.sim, "READ")
        t = f.Get("DecayTree")
        datagraphs = fit_params( t, simqsqbins ) 
        f.Close()

    c = ROOT.TCanvas("c", "", 800, 600)
    c.SaveAs("paramfits.pdf[")
    for name, graph in datagraphs.iteritems() :
        graph.SetTitle(name)
        graph.GetHistogram().GetXaxis().SetTitle("q^{2}")
        graph.GetHistogram().GetYaxis().SetTitle(name)
        graph.Draw("ap")
        c.SaveAs("paramfits.pdf")  
    c.SaveAs("paramfits.pdf]")


 
    exit()



