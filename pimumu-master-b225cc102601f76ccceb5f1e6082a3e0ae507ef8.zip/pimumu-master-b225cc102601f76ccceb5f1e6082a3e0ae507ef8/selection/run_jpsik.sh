#python select_events.py -f ~/data/Pimm/raw/with_bdt_jpsik_12_mc_isoln_newpid_corr.root -t DecayTree -p -j
#python select_events.py -f ~/data/Pimm/presel/with_bdt_jpsik_12_mc_isoln_newpid_presel.root -t DecayTree -l -s
#python select_events.py -f ~/data/Pimm/presel/with_bdt_jpsik_12_mc_isoln_newpid_corr_presel.root -t DecayTree -l -s

#python select_events.py -f ~/data/Pimm/raw/with_bdt_kmumu_11_isoln.root -t DecayTree -p -j
#python select_events.py -f ~/data/Pimm/raw/with_bdt_kmumu_12_isoln.root -t DecayTree -p -j
#mv ~/data/Pimm/raw/*presel.root ~/data/Pimm/presel/.
#python select_events.py -f ~/data/Pimm/presel/with_bdt_kmumu_11_isoln_presel.root -t DecayTree -l
#python select_events.py -f ~/data/Pimm/presel/with_bdt_kmumu_12_isoln_presel.root -t DecayTree -l
#hadd -f9 ~/data/Pimm/presel/with_bdt_jpsik_tot_isoln_presel_loosepid.root ~/data/Pimm/presel/with_bdt_kmumu_1*_isoln_presel_loosepid.root
#python select_events.py -f ~/data/Pimm/presel/with_bdt_kmumu_11_isoln_presel.root -t DecayTree -o -k -j 
#python select_events.py -f ~/data/Pimm/presel/with_bdt_kmumu_12_isoln_presel.root -t DecayTree -o -k -j
#hadd -f9 ~/data/Pimm/presel/with_bdt_jpsik_tot_isoln_presel_offsel.root ~/data/Pimm/presel/with_bdt_kmumu_1*_isoln_presel_offsel.root

#python select_events.py -f ~/data/Pimm/raw/with_bdt_kmumu_11_isoln.root -t DecayTree -p 
#python select_events.py -f ~/data/Pimm/raw/with_bdt_kmumu_12_isoln.root -t DecayTree -p 
#mv ~/data/Pimm/raw/*presel.root ~/data/Pimm/presel/.
#python select_events.py -f ~/data/Pimm/presel/with_bdt_kmumu_11_isoln_presel.root -t DecayTree -o -k
#python select_events.py -f ~/data/Pimm/presel/with_bdt_kmumu_12_isoln_presel.root -t DecayTree -o -k
#rm ~/data/Pimm/presel/with_bdt_kmumu_tot_isoln_presel_offsel.root
#hadd -f9 ~/data/Pimm/presel/with_bdt_kmumu_tot_isoln_presel_offsel.root ~/data/Pimm/presel/with_bdt_kmumu_1*_isoln_presel_offsel.root
hadd -f9 ~/data/Pimm/presel/with_bdt_kmumu_tot_isoln_presel.root ~/data/Pimm/presel/with_bdt_kmumu_1*_isoln_presel.root


