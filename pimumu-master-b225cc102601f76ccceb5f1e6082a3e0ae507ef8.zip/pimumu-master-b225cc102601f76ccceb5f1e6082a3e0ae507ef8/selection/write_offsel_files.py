
mass_min = 5175.
mass_max = 6000.

jpsimmcut = "B_M>%s && B_M<%s && (qsq>%s && qsq<%s)" % ( mass_min, mass_max, 8.68, 10.09 ) #std 
mmcut = "B_M>%s && B_M<%s && !(qsq>%s && qsq<%s) && !(qsq>%s && qsq<%s)" % ( mass_min, mass_max, 8.0, 11.0, 12.5, 15 ) 


def write_trees( filename, treename ) :
    #pass
    import ROOT
    f = ROOT.TFile( filename , "READ" )
    if not f.IsOpen() :
        f.Close()
        return 1 
    t = f.Get( treename ) 
    if not t:
        f.Close()
        return 2

    nonresfilename = filename[ : filename.find(".root") ] + "_kmm.root"
    resfilename = filename[ : filename.find(".root") ] + "_jpsikmm.root"
    nonressel = mmcut
    ressel = jpsimmcut




    nf = ROOT.TFile ( nonresfilename , "RECREATE" )
    nt = t.CopyTree( nonressel )
    print t.GetEntries(), "to", nt.GetEntries(), "using", nonressel
    nt.Write()
    nf.Close() 
   
    rf = ROOT.TFile ( resfilename , "RECREATE" )
    rt = t.CopyTree( ressel ) 
    print t.GetEntries(), "to", rt.GetEntries(), "using", ressel
    rt.Write()
    rf.Close() 


    f.Close()

    pass



if __name__=='__main__' :


    import ROOT, os
    ROOT.gROOT.SetBatch(True)

    from optparse import OptionParser

    parser = OptionParser()
    parser.add_option( "-d", "--dir", dest="dir", default=None, type='string', help="testing" ) 
    parser.add_option( "-f", "--file", dest="file", default="" , type="string", help="filename" ) 
    parser.add_option( "-t", "--tree", dest="tree", default="DecayTree" , type="string", help="treename" ) 
 
    (options,args) = parser.parse_args()



    if options.dir :


        files = os.listdir( options.dir )

        files.sort()

        print files

        for f in files :

               write_trees( os.path.join( options.dir, f  ) , options.tree ) 

    else :
           
            write_trees( options.file , options.tree ) 

