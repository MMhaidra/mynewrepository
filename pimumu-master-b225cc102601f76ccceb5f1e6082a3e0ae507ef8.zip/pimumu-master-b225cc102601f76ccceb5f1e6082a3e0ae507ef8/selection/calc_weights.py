#!/usr/bin/env python
# calculate weights interatively
import os, sys, re, ROOT, time, math
ROOT.gROOT.SetBatch(True)
from tree import TTree

class config:
    base_file = "~/data/Pimm/test/weight_"
    def __init__(self,_name,_min,_max,_nbins
                ,_name2=None,_label=None, _weight=None
                 , logx=False,_logy=False):
        self.name =_name
        self.max =_max
        self.min =_min
        self.nbins =_nbins
        self.save = False
        self.label =_label
        self.name2 =_name2
        if not self.label:
            self.label = self.name
        if not self.name2:
            self.name2 = self.name
            if "PID" in self.name2:
                self.name2 = self.name.replace("PID", "DataPID")
        print self.label, self.name. self.name2
        self.filename = self.base_file+self.label+".root"
        self.logx =_logx
        self.logy =_logy
        self.weight =_weight
        if not _weight:
            self.weight = self.label + "_weight"
    def __repr__(self):
        return self.label

bpt_config  = config ("B_PT", 0.0, 30000.0, 40, "", "bpt")
spd_config = config ("nSPDHits", 0, 600, 40, "", "spd")
ntr_config = config ("nTracks", 0, 600, 40, "", "ntr")
vtx_config = config ("B_ENDVERTEX_CHI2", 0, 25, 40, "", "vtx")
k_pconfig  = config ("hadron_P", 0.0, 1E5, 40)
k_ptconfig  = config ("hadron_PT", 0.0, 1E4, 40)
k_etaconfig  = config ("hadron_ETA", 0.0, 1E4, 40)
k_pidkconfig  = config ("hadron_PIDK", -20.0, 120.0, 40, "hadron_DataPIDK")
mm_pconfig  = config ("muminus_P", 0.0, 1E5, 40)
mm_ptconfig  = config ("muminus_PT", 0.0, 1E4, 40)
mp_pconfig = config ("muplus_P", 0.0, 1E5, 40)
mp_ptconfig  = config ("muplus_PT", 0.0, 1E4, 40) 
mup_pidmuconfig  = config ("muplus_PIDmu", -5.0, 15.0, 40
       , "muplus_DataPIDmu")
mum_pidmuconfig  = config ("muminus_PIDmu", -5.0, 15.0, 40
      , "muminus_DataPIDmu")
dpt_config  = config ("abs(muplus_P-muminus_P)", 0.0, 1E5 
                     , 40, "", "dpt")
isoh_config  = config ("B_ISOLATION_BDT_Hard", -1, 1, 40)
isos_config  = config ("B_ISOLATION_BDT_Soft", -1, 1, 40)
pvdof_config1  = config ("B_OWNPV_NDOF", 0.0, 250.0, 250, "", "pvdof")
pvdof_config2  = config ("B_OWNPV_NDOF", 0.0, 250.0, 100, "", "pvdof")
pvdof_config3  = config ("B_OWNPV_NDOF", 0.0, 250.0, 50, "", "pvdof")

bdt0_config  = config ("BDT_0", -1.0, 1.0, 40, "", "BDT (unweighted)")
bdt1_config  = config ("BDT_1", -1.0, 1.0, 40, "", "BDT (weighted)")
bdt2_config  = config ("BDT_2", -1.0, 1.0, 40, "", "BDT (no mu PT)")
bdt3_config  = config ("BDT_3", -1.0, 1.0, 40, "", "BDT (no pvndof)")
bdt4_config  = config ("BDT_4", -1.0, 1.0, 40, "", "BDT (2D wgt)")
bdt5_config  = config ("BDT_5", -1.0, 1.0, 40, "", "BDT (2D wgt, no iso, npv)")

mmconfigs = [ bdt0_config, bdt1_config, bdt2_config, bdt3_config, bdt4_config, bdt5_config
       , spd_config, ntr_config, vtx_config
       , bpt_config, k_pconfig, k_ptconfig
       , mp_pconfig, mp_ptconfig, mm_pconfig, mm_ptconfig 
       , isoh_config, isos_config
       , pvdof_config1#, pvdof_config2, pvdof_config3
       , k_pidkconfig, mum_pidmuconfig, mup_pidmuconfig
        ]

list_of_branches = [ c.name for c in mmconfigs ]

list_of_branches += [ c.name2 for c in mmconfigs ]

cols = [ 1, 2, 3, ROOT.kMagenta+2 ] 

def drawLegend(names, colours):
    from ROOT import TLine, TMarker, TLatex
    cache_legend = [] 
    yoff = 0.95
    xoff = 0.05
    idel = 0.24
    iexp = 0
    drawMarker = True
    for name, colour in zip(names, colours):
        line = TLine()
        line.SetLineColor(colour)
        #line.SetLineStyle(exp.istyle)
        line.DrawLineNDC(xoff + iexp*idel, yoff- 0.01, 
                          xoff + 0.05 + iexp*idel, yoff - 0.01)

        marker = TMarker(xoff + 0.025 + iexp*idel, yoff - 0.01, 20)
        marker.SetMarkerColor(colour)
        marker.SetMarkerSize(2)
        marker.SetNDC()
        if (drawMarker): 
            marker.Draw()
        tag = TLatex()
        tag.SetTextAlign(12)
        tag.SetTextSize(0.05)
        tag.DrawTextNDC(xoff + 0.055 + iexp*idel, yoff, name)

        iexp += 1
        cache_legend += [ line, marker, tag ]

    return cache_legend 




def set_branches (ttree):
    ttree.SetBranchStatus("*", 0)
    print "setting", list_of_branches
    for b in list_of_branches :
        ttree.SetBranchStatus(b, 1)
    ttree.SetBranchStatus("B_M", 1)
    ttree.SetBranchStatus("dimuon_M", 1)

mmconfigs += [ dpt_config ]
mmbdtcut = "1.0"#datafiles

def add_datamc_weights(t):
    print "adding datamc weights"
    rf2 = ROOT.TFile("ratio2012S20.root", "READ")
    if not rf2.IsOpen():
        print "no tracking file open"
        rf2.Close()
        return
    h2 = rf2.Get("Ratio")
    #brem for the eplus
    rf3 = ROOT.TFile("PerfHists_Mu_Strip20_MCTuneV2_MagDown_2D.root", "READ")
    if not rf3.IsOpen():
        print "no ismuon file open"
        rf3.Close()
        return
    h3 = rf3.Get("Mu_IsMuon==1_All")
    res_tuple = {}
    n = t.GetEntries()
    t.SetBranchStatus("*", 0)
    t.SetBranchStatus("muplus_P", 1)
    t.SetBranchStatus("muplus_PT", 1)
    t.SetBranchStatus("muminus_P", 1)
    t.SetBranchStatus("muminus_PT", 1)
    t.SetBranchStatus("hadron_P", 1)
    t.SetBranchStatus("hadron_PT", 1)
    sw = 1.0
    from math import sqrt
    from math import log
    print "running"
    for i in range(n):
        if n > 10 :
            if (i % (n/10))== 0        :
                print "processed %g"% i, \
                        "last weight %f"%(sw)
        sw = 1.0
        t.GetEntry(i)
        hadron_PZ = sqrt(t.hadron_P**2 - t.hadron_PT**2)
        keta = 0.5*log((t.hadron_P+hadron_PZ)/ (t.hadron_P-hadron_PZ))
        kmom = t.hadron_P / 1E3
        sw *= h2.GetBinContent(h2.FindBin(kmom, keta))
        if True :
            muplus_PZ = sqrt(t.muplus_P**2 - t.muplus_PT**2)
            muminus_PZ = sqrt(t.muminus_P**2 - t.muminus_PT**2)
            mpeta = 0.5*log((t.muplus_P+muplus_PZ)/(t.muplus_P-muplus_PZ))
            mmeta = 0.5*log((t.muminus_P+muminus_PZ)/(t.muminus_P-muminus_PZ))
            mpmom = t.muplus_P / 1E3
            mmmom = t.muminus_P / 1E3
            #tracking
            sw *= h2.GetBinContent(h2.FindBin(mpmom, mpeta)) 
            sw *= h2.GetBinContent(h2.FindBin(mmmom, mmeta))
            #ismuon
            #sw *= h3.GetBinContent(h3.FindBin(t.muplus_P, mpeta))
            #sw *= h3.GetBinContent(h3.FindBin(t.muminus_P, mmeta))
        t.AddVar( sw , "datamc_weight", res_tuple)
        t.FillVars(res_tuple)
    rf2.Close()
    rf3.Close()
    t.SetBranchStatus("*", 1)

#simulation filesi

def getChisq(hist, cfg):
    return 0 
    func = ROOT.TH1D("test", "", cfg.nbins, cfg.min, cfg.max)
    func.Sumw2()
    for i in range(cfg.nbins+2):
        func.SetBinContent(i, 0.00001)
    chisq = hist.Chi2Test(func, "WW")
    ndof = cfg.nbins
    return (chisq / float(ndof))

def add_weight_from_hist(t, cfg, h1, test = False, ext=None, cfg2 = None):
    print "adding weight from histogram", h1.GetName()
    res_tuple = {}
    n = t.GetEntries()
    sw = 1.0
    print "running"
    h3 = ROOT.TH1D("h1", "", cfg.nbins, cfg.min, cfg.max)
    h3.Sumw2()
    h4 = ROOT.TH1D("h2", "", cfg.nbins, cfg.min, cfg.max)
    h4.Sumw2()
    #t.SetBranchStatus("*", 0)
    #t.SetBranchStatus(cfg.name, 1)
    weightstr = "weight_"+ext
    for i in range(n):
        if n > 10 :
            if (i % (n/10))== 0        :
                print "processed %g" % i \
                   , "last weight %f" % (sw)
        sw = 1.0
        t.GetEntry(i)
        #SPD
        if not cfg2 :
            sw *= h1.GetBinContent(h1.FindBin(
                getattr(t, cfg.name)))
        else :
            sw *= h1.GetBinContent(h1.FindBin(
                getattr(t, cfg.name), getattr(t, cfg2.name)))
        if (test):
            h3.Fill(getattr(t, cfg.name), sw)
            h4.Fill(getattr(t, cfg.name))
        t.AddVar( sw , weightstr, res_tuple)
        t.FillVars(res_tuple)
    #t.SetBranchStatus("*", 1)
    if (test):
        h3.GetXaxis().SetTitle(cfg.name)
        h4.GetXaxis().SetTitle(cfg.name)
        can = ROOT.TCanvas("c", "", 800, 600)
        can.SaveAs("add_weight_"+cfg.name+".pdf[")
        if not cfg2 :
            h4.SetLineColor(2)
            h4.SetMarkerColor(2)
            h3.DrawNormalized("e")
            h4.DrawNormalized("esame")
            can.SaveAs("add_weight_"+cfg.name+".pdf")
            t.Draw(cfg.name+">>h1", "", "goff")
            t.Draw(cfg.name+">>h2", weightstr, "goff")
            can.SaveAs("add_weight_"+cfg.name+".pdf")
            h3.DrawNormalized("e")
            h4.DrawNormalized("esame")
        else :
            h3.Draw("colz")
            can.SaveAs("add_weight_"+cfg.name+".pdf")
            h4.Draw("colz")
            can.SaveAs("add_weight_"+cfg.name+".pdf")
        can.SaveAs("add_weight_"+cfg.name+".pdf]")
    del h3
    del h4
    return


def weight_dists(simtree, sel1, sel2, cfgslist, weights="1.0", fileext=""):
    print "twod validate"
    setLHCbStyle()
    ROOT.gStyle.SetPadRightMargin(0.15)
    c = ROOT.TCanvas("cv", "", 800, 600)
    filename = "weight_dists_"+fileext+".pdf"
    c.SaveAs(filename+"[")
    print "weight cmd", weights + "*" + sel2
    i = 0
    factor = 1
    for cfg in cfgslist:
        #print cfg.name
        h1 = ROOT.TH2D("h1", "", cfg.nbins / factor, cfg.min, cfg.max, 
                       40, 0, 5)
        h1.Sumw2()
        simtree.Draw(weights+":"+cfg.name+">>h1", sel2 , "goff")
        h1.GetYaxis().SetTitle("weight")
        h1.GetXaxis().SetTitle(cfg.label)
        h1.Draw("colz")
        c.SaveAs(filename)
        del h1
    c.SaveAs(filename+"]")


def validate(t1, t2, sel1, sel2, cfgslist
       , weights="1.0", fileext="", pions=False):
    print "validating", t1, t2
    #plot validation and masses
    setLHCbStyle()
    ROOT.gStyle.SetPadTopMargin(0.11)
    ROOT.gStyle.SetPadRightMargin(0.08)
    c = ROOT.TCanvas("cv", "", 800, 600)
    filename = "validate_"+fileext+".pdf"
    c.SaveAs(filename+"[")
    print "weight cmd", sel2+"*"+weights
    basesel = sel1.split("*")[0]
    print basesel
    
    chisqhist1 = ROOT.TH1D("chisq1", "", len(cfgslist), 0, len(cfgslist))
    chisqhist2 = ROOT.TH1D("chisq2", "", len(cfgslist), 0, len(cfgslist))
    chisqhist3 = ROOT.TH1D("chisq3", "", len(cfgslist), 0, len(cfgslist))
    chisqhist1.Sumw2()
    chisqhist2.Sumw2()
    chisqhist3.Sumw2()
    i = 0
    for cfg in cfgslist:
        #print cfg.name
        h1 = ROOT.TH1D("h1", "", cfg.nbins, cfg.min, cfg.max)
        h2 = ROOT.TH1D("h2", "", cfg.nbins, cfg.min, cfg.max)
        h3 = ROOT.TH1D("h3", "", cfg.nbins, cfg.min, cfg.max)
        h4 = ROOT.TH1D("h4", "", cfg.nbins, cfg.min, cfg.max)
        h1.GetXaxis().SetTitle(cfg.label)
        h2.SetLineColor(4)
        h2.SetMarkerColor(4)
        h3.SetLineColor(2)
        h3.SetMarkerColor(2)
        h4.SetLineColor(ROOT.kMagenta+2)
        h4.SetMarkerColor(ROOT.kMagenta+2)
        h1.Sumw2()
        h2.Sumw2()
        h3.Sumw2()
        h4.Sumw2()
        t1.Draw(cfg.name+">>h1", sel1, "goff")
        t2.Draw(cfg.name2+">>h2", sel2+"*"+weights, "goff")
        t2.Draw(cfg.name+">>h3", sel2, "goff")
        t2.Draw(cfg.name+">>h4", basesel, "goff")
        h1.Scale(1.0/h1.Integral("width"))#data
        h2.Scale(1.0/h2.Integral("width"))#corr sim
        h3.Scale(1.0/h3.Integral("width"))#prev sim
        h4.Scale(1.0/h4.Integral("width"))#sim
        h1.GetYaxis().SetRangeUser(0
               , 1.5*h1.GetBinContent(h1.GetMaximumBin()))
        h2.GetYaxis().SetRangeUser(0
               , 1.5*h1.GetBinContent(h1.GetMaximumBin()))
        h3.GetYaxis().SetRangeUser(0
                , 1.5*h1.GetBinContent(h1.GetMaximumBin()))
        h4.GetYaxis().SetRangeUser(0
                , 1.5*h1.GetBinContent(h1.GetMaximumBin()))
        h1.Draw("e")
        h4.Draw("esame")
        h3.Draw("esame")
        h2.Draw("esame")
        vs = drawLegend(["data", "sim", "prev corr sim", "all corr sim"]
                        , [1, ROOT.kMagenta+2, 2, 4]
                       )
        c.SaveAs(filename)
        #chisq1 = h1.Chi2Test(h2, "WWCHI2/NDF")
        #chisq2 = h1.Chi2Test(h3, "WWCHI2/NDF")
        chisq1 = h1.Chi2Test(h2, "WWCHI2/NDF")#v.s. corrsim
        chisq2 = h1.Chi2Test(h3, "WWCHI2/NDF")#v.s. prev sim
        chisq3 = h1.Chi2Test(h4, "WWCHI2/NDF")#v.s. sim
        chisqhist1.GetXaxis().SetBinLabel(i+1, cfg.name)
        chisqhist2.GetXaxis().SetBinLabel(i+1, cfg.name)
        chisqhist3.GetXaxis().SetBinLabel(i+1, cfg.name)
        chisqhist1.SetBinContent(i+1, chisq1)
        chisqhist2.SetBinContent(i+1, chisq2)
        chisqhist3.SetBinContent(i+1, chisq3)
        del h1
        del h2
        del h3
        i += 1
    c.SetLogy(True)
    chisqhist1.GetYaxis().SetRangeUser(0.1, 1E4)
    chisqhist1.GetYaxis().SetTitle("#chi^{2} / n.d.o.f.")
    chisqhist2.GetYaxis().SetRangeUser(0.1, 1E4)
    chisqhist2.GetYaxis().SetTitle("#chi^{2} / n.d.o.f.")
    chisqhist3.GetYaxis().SetRangeUser(0.1, 1E4)
    chisqhist3.GetYaxis().SetTitle("#chi^{2} / n.d.o.f.")
    chisqhist1.SetMarkerColor(1)
    chisqhist1.SetLineColor(1)
    chisqhist2.SetMarkerColor(4)
    chisqhist2.SetLineColor(4)
    chisqhist3.SetMarkerColor(ROOT.kMagenta+2)
    chisqhist3.SetLineColor(ROOT.kMagenta+2)
    chisqhist3.Draw("e")# data v.s. plain sim
    chisqhist1.Draw("esame")   # data v.s. prev sim
    chisqhist2.Draw("esame")# data v.s. new sim
    vs = drawLegend(["v.s. sim", "v.s. prev sim", "v.s. corr sim" , ] 
                     , [ROOT.kMagenta+2, 4, 1]
                     )

    c.SaveAs(filename)
    c.SaveAs(filename+"]")
    #weight distribution
    c2 = ROOT.TCanvas("c2", "c2", 800, 600)
    hw = ROOT.TH1D("hw", "", 100, 0, 10)
    t2.Draw(weights+">>hw", sel2, "goff")
    hw.GetXaxis().SetTitle("#omega")
    hw.Draw("e")
    c2.SaveAs("weight_dist_" + fileext + ".pdf")
    #c.Delete()
    #del c



def calc_histogram_twod(treeone, treetwo, c1, c2, sel1, sel2, plot=False, ext=None): 
    print "calculating 2D histogram", c1.name, c2.name
    factor = 1
    h1 = ROOT.TH2D("h1"+c1.name+c2.name, "", c1.nbins/factor, c1.min, c1.max
           , c2.nbins/factor, c2.min, c2.max)
    h2 = ROOT.TH2D("h2"+c1.name+c2.name, "", c1.nbins/factor, c1.min, c1.max
           , c2.nbins/factor, c2.min, c2.max)
    h7 = ROOT.TH2D("ratio_"+ext, "ratio_"+ext, 
            c1.nbins/factor, c1.min, c1.max, c2.nbins/factor, c2.min, c2.max)
    #get correct branches
    h1.Sumw2()
    h2.Sumw2()
    treeone.Draw((c2.name+":"+c1.name+">>h1"+c1.name+c2.name)
           , sel1, "goff")
    treetwo.Draw((c2.name2+":"+c1.name2+">>h2"+c1.name+c2.name)
           , sel2, "goff")
    can = ROOT.TCanvas("c"+c1.name+c2.name, "", 800, 600)
    if plot :
        can.SaveAs("ratio_hist_"+ext+".pdf[")
        h1.Draw("colz")
        can.SaveAs("ratio_hist_"+ext+".pdf")
        h2.Draw("colz")
        can.SaveAs("ratio_hist_"+ext+".pdf")
    h1.Scale(1.0 / h1.Integral("width")) 
    h2.Scale(1.0 / h2.Integral("width"))
    h7.Divide(h1, h2, 1.0, 1.0)
    if plot :
        h7.Draw("colz")
        can.SaveAs("ratio_hist_"+ext+".pdf")
        can.SaveAs("ratio_hist_"+ext+".pdf]")
    del can
    del h1
    del h2
    h7.SaveAs("ratio_hist_"+ext+".root")
    return h7


def calc_histogram(treeone, treetwo, c, sel1, sel2, plot=False, ext=None): 
    print "calculating 1D histogram", c.name, c.min, c.max, c.label
    h1 = ROOT.TH1D("h1"+c.label, "", c.nbins, c.min, c.max)
    h2 = ROOT.TH1D("h2"+c.label, "", c.nbins, c.min, c.max)
    h7 = ROOT.TH1D("ratio_"+ext, "ratio_"+ext, c.nbins, c.min, c.max)
    #get correct branches
    h1.Sumw2()
    h2.Sumw2()
    #print "sel1 %s, sel2 %s, treeone %g, treetwo %g " \
    #        % (sel1, sel2, treeone, treetwo)
    treeone.Draw((c.name+">>h1"+c.label), sel1, "goff")
    treetwo.Draw((c.name2+">>h2"+c.label), sel2, "goff")
    h1.Scale(1.0 / h1.Integral("width")) 
    h2.Scale(1.0 / h2.Integral("width"))
    h7.Divide(h1, h2, 1.0, 1.0)
    if plot :
        h1.GetXaxis().SetTitle(c.label)
        h2.GetXaxis().SetTitle(c.label)
        h7.GetXaxis().SetTitle(c.label)
        h7.GetYaxis().SetTitle("ratio")
        can = ROOT.TCanvas("c"+c.name, "", 800, 600)
        can.SaveAs("ratio_hist_"+ext+".pdf[")
        h1.GetYaxis().SetRangeUser(0, 
                1.5*h1.GetBinContent(h1.GetMaximumBin()))
        h1.Draw("e")
        h2.SetLineColor(2)
        h2.SetMarkerColor(2)
        h2.Draw("esame")
        can.SaveAs("ratio_hist_"+ext+".pdf")
        h7.Draw("e")
        can.SaveAs("ratio_hist_"+ext+".pdf")
        can.SaveAs("ratio_hist_"+ext+".pdf]")
        del can
    #print "chisq of ratio hist", getChisq(hist, c)
    del h1
    del h2
    h7.SaveAs("ratio_hist_"+ext+".root")
    return h7






def calc_weight_config(filename1, filename2, cfg
       , options, sel="1.0", baseweights="(1.0)", cfg2=None):
    print " comparing", filename1, filename2
    f1 = ROOT.TFile(filename1, "READ")
    if not f1.IsOpen():
        print "file not found"
        return
    t1 = f1.Get("DecayTree")
    if not t1 :
        print " no tree 1 "
        return
   
    labels = baseweights.split("*")
    labels = labels[1:]
    print "labels", labels
    ext = ""
    for label in labels :
        if label :
            label = label.replace("weight_", "")
            print label
            ext += label + "_"
    ext += cfg.label
    if cfg2 :
        ext += cfg2.label

    print "baseweights", baseweights, "extentsion", ext

    f2 = ROOT.TFile(filename2, "UPDATE")
    if not f2.IsOpen():
        print "file not found"
        return
    t2 = f2.Get("DecayTree")
    if not t2:
        print " no tree 2 "
        return
    #configure selections
    sel1 = sel 
    sel2 = sel
    if options.sweight:
        sel1 = sel1+"*"+"sweight"
    if baseweights:
        sel2 = sel2+"*"+baseweights
    print "sel1", sel1, "sel2", sel2
    if cfg2 :
        hist = calc_histogram_twod(t1, t2, cfg, cfg2, sel1, sel2
               , options.test, ext)
    else:
        hist = calc_histogram(t1, t2, cfg, sel1, sel2
               , options.test, ext)


    if options.add :
        f4 = ROOT.TFile("ratio_histograms.root", "UPDATE")
        hist.Write()
        f4.Close()

    f2.cd()
    #config weight string
    #
    add_weight_from_hist(t2, cfg, hist, options.test, ext, cfg2)
    #
    t2.Write("", ROOT.TObject.kOverwrite)
    f2.Close()
    #open old file
    f3 = ROOT.TFile(filename2, "READ")
    nt = f3.Get("DecayTree")
    print "reopen new file, get tree", f3, nt
    cfglist = mmconfigs
    print "config list", cfglist
    validate(t1, nt, sel1, sel2, cfglist, "weight_"+ext
           , ext, options.pions)
    weight_dists(nt, sel1, sel2, cfglist, "weight_"+ext
           , ext)
    print "hist before f3", hist
    f3.Close()
    #f1.Close()
    print "hist before return", hist
    return hist




base = "/home/alexshires/data/Pimm/presel/"
kmmdatafile = os.path.join(base
       , "with_bdt_kmumu_11_isoln_presel_loosepid_sweight.root")
kmmsimfile = os.path.join(base
        , "with_bdt_jpsik_12_mc_isoln_newpid_corr_presel_loosepid.root")


if __name__ == '__main__':

    ROOT.gErrorIgnoreLevel = 3000
    ROOT.gROOT.SetBatch(True)
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()
    ROOT.gStyle.SetOptStat(False)
    ROOT.gStyle.SetNdivisions(505, "y")
    ROOT.gStyle.SetNdivisions(505, "x")
    ROOT.gStyle.SetEndErrorSize(5)
    ROOT.gStyle.SetPadTopMargin(0.11)
    ROOT.gStyle.SetPadRightMargin(0.1)

    start = time.time()
    print time.asctime(time.localtime())



    filename = "" 
    treename = "DecayTree"

    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument("-d", "--debug", dest="test", action="store_true"
           , default=False, help="testing")
    parser.add_argument("-e", "--pions", dest="pions", action="store_true"
           , default=False, help="eee")
    parser.add_argument("-r", "--res", dest="res", action="store_true"
           , default=False, help="resonant ocmparison")
    parser.add_argument("-n", "--non", dest="non", action="store_true"
           , default=False, help="non resonant ocmparison")
    parser.add_argument("-v", "--val", dest="val", action="store_true"
           , default=False, help="validate ocmparison")
    parser.add_argument("-a", "--add", dest="add", action="store_true"
           , default=False, help="add something ")
    parser.add_argument("-b", "--bdt", dest="bdt", action="store_true"
           , default=False, help="add something ")
    parser.add_argument("-c", "--cdt", dest="cdt", action="store_true"
           , default=False, help="add something ")
    parser.add_argument("-w", "--sweight", dest="sweight", action="store_true"
           , default=False, help="sweight")
   

    options = parser.parse_args()
    


    resdatafile = kmmdatafile
    ressimfile = kmmsimfile
    ressel = "(1.0)"
    datamcfilename = "~/data/Pimm/test/test_weight_datamc.root"
    if options.res:
        f = ROOT.TFile(ressimfile, "READ")
        t = f.Get("DecayTree")
        nf = ROOT.TFile(datamcfilename, "RECREATE")
        set_branches(t)
        nt = t.CloneTree(-1, "fast")
        add_datamc_weights(nt)
        nf.cd()
        nt.Write()
        nf.Close()
        f.Close()
        filename = datamcfilename
        outfilename = "~/data/Pimm/test/test_weights.root"
        f = ROOT.TFile(datamcfilename, "READ")
        t = f.Get("DecayTree")
        nf = ROOT.TFile(outfilename, "RECREATE")
        nt = t.CloneTree(-1, "fast")
        nf.cd()
        nt.Write()
        nf.Close()
        f.Close()
        exit()

    if options.add :
        #file_spd = ROOT.TFile("ratio_hist_spd.root")
        #hist_spd = file_spd.Get("ratio_spd")
        #file_ntr = ROOT.TFile("ratio_hist_ntr.root")
        #hist_ntr = file_ntr.Get("ratio_ntr")
        file_spdntr = ROOT.TFile("ratio_hist_spdntr.root")
        hist_spdntr = file_spdntr.Get("ratio_spdntr")
        #file_spd_bpt = ROOT.TFile("ratio_hist_spd_bpt.root")
        #hist_spd_bpt = file_spd_bpt.Get("ratio_spd_bpt")
        #file_ntr_bpt = ROOT.TFile("ratio_hist_ntr_bpt.root")
        #hist_ntr_bpt = file_ntr_bpt.Get("ratio_ntr_bpt")
        file_spdntr_bpt = ROOT.TFile("ratio_hist_spdntr_bpt.root")
        hist_spdntr_bpt = file_spdntr_bpt.Get("ratio_spdntr_bpt")
        histfilename = "ratio_histograms.root"
        f7 = ROOT.TFile(histfilename, "RECREATE")
        #hist_spd.Write()
        #hist_ntr.Write()
        hist_spdntr.Write()
        #hist_spd_bpt.Write()
        #hist_ntr_bpt.Write()
        hist_spdntr_bpt.Write()
        f7.Close()
        #file_spd.Close()
        #file_ntr.Close()
        file_spdntr.Close()
        #file_spd_bpt.Close()
        #file_ntr_bpt.Close()
        file_spdntr_bpt.Close()
        exit()

    
    base_weight = "datamc_weight"
    base_sel = "(B_M>5200 && B_M<5360 && dimuon_M>8.68 && dimuon_M<10.08)"
    base_weight = "(1.0)"
    
    if options.bdt :
        base_sel = "(B_M>5200 && B_M<5360 && dimuon_M>3000. && dimuon_M<3200. && BDT_1>-0.1)"
    if options.cdt :
        base_sel = "(B_M>5200 && B_M<5360 && dimuon_M>3000. && dimuon_M<3200. && BDT_1<-0.1)"

    filename = "~/data/Pimm/test/test_weights.root"

    #calc_weight_config(resdatafile, filename, spd_config 
    #      , options, base_sel, base_weight)
    calc_weight_config(resdatafile, filename, spd_config
          , options, base_sel, base_weight, ntr_config)
    #calc_weight_config(resdatafile, filename, ntr_config
    #       , options, base_sel, "datamc_weight")
    #weights = base_weight+"*weight_spd"
    #calc_weight_config(resdatafile, filename, bpt_config
    #       , options, base_sel, weights)
    #weights = base_weight+"*weight_ntr"
    #calc_weight_config(resdatafile, filename, bpt_config
    #       , options, base_sel, weights)
    weights = base_weight+"*weight_spdntr"
    calc_weight_config(resdatafile, filename, bpt_config
           , options, base_sel, weights)


    #pvdofhist = calc_weight_config(resdatafile, filename, pvdof_config
    #       , ressel
    #       , ressel, options, weightstr)

        #dpthist = calc_weight_config(resdatafile, datamcfilename, dpt_config
    #       , ressel, ressel, options
    #       , "datamc_weight")
    #*"+spd_config.weight+"*"+bpt_config.weight)



    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start

