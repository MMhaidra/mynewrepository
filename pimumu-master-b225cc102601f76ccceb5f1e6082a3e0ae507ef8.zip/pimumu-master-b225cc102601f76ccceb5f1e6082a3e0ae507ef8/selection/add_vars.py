#! /usr/bin/env python
import ROOT
from math import log, fabs
import time

m_e = 0.51
m_mu = 105
m_pi = 139.6
m_k = 493.7

from tree import TTree
import math
from math import sqrt

def calc_inv_mass(MA, PA, PXA, PYA, PZA, MB, PB, PXB, PYB, PZB):
    #
    EA = math.sqrt(PA*PA + MA*MA)
    #print EA, MA, PA
    EB = math.sqrt(PB*PB + MB*MB)
    aPdot = PXA*PXB + PYA*PYB+ PZA*PZB
    AA = 2*((EA*EB)-aPdot)
    msq = ((MA*MA) + (MB*MB) + AA)
    #print MA, MB, EA, EB, AA, aPdot, msq
    massInv = 0.0
    if msq > 0.0:
        massInv = math.sqrt(msq)
    return massInv

if __name__ == '__main__':

    start = time.time()
    print time.asctime(time.localtime())
    print " setting batch mode " 
    ROOT.gROOT.SetBatch(True)
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument("-d", "--dir", dest="dir", default=None, type=str, help="testing")
    parser.add_argument("-f", "--file", dest="file", default=None, type=str, help="filename")
    parser.add_argument("-t", "--tree", dest="tree", default="DecayTree", type=str, help="treename")
    parser.add_argument("-q", "--qsq", dest="qsq", default=False, action='store_true', help="treename")
    parser.add_argument("-k", "--kmumu", dest="kmumu", default=False, action='store_true', help="kmumu mass")
    options = parser.parse_args()

    from ROOT import TFile
    f = TFile(options.file, "READ")
    tt = f.Get(options.tree)
    n = tt.GetEntries()
    res_tuple = {}

    newfilename = options.file[:options.file.find(".root")] + "_vars.root"
    print newfilename
    newfile = TFile(newfilename, "RECREATE")
    t = tt.CloneTree(-1, "fast")
    t.SetBranchStatus("*", 0)
    list_of_branches = ["_PY", "_PX", "_PZ", "_PT", "_PE", "_M", "_P"]
    for b in t.GetListOfBranches():
        for l in list_of_branches:
            if l in b.GetName():
                t.SetBranchStatus(b.GetName(), 1)
    for i in range(n):
        if n > 10:
            if (i % (n/10)) == 0:
                print "processed %g" % i
        t.GetEntry(i)
        if options.qsq:
            qsq = t.dimuon_M ** 2 / 1E6
            t.AddVar(qsq, "qsq", res_tuple)
            t.FillVars(res_tuple)
        elif options.kmumu:
            kmumu_mass = calc_inv_mass(m_k, t.hadron_P, t.hadron_PX, t.hadron_PY, t.hadron_PZ,
                                       t.dimuon_M, t.dimuon_P, t.dimuon_PX, t.dimuon_PY, t.dimuon_PZ)
            pimumu_mass = calc_inv_mass(m_pi, t.hadron_P, t.hadron_PX, t.hadron_PY, t.hadron_PZ,
                                       t.dimuon_M, t.dimuon_P, t.dimuon_PX, t.dimuon_PY, t.dimuon_PZ)
            t.AddVar(kmumu_mass, "kmumu_M", res_tuple)
            t.AddVar(pimumu_mass, "pimumu_M", res_tuple)
            t.FillVars(res_tuple)
        else:
            try:
                beta = 0.5*log((t.B_P+t.B_PZ)/(t.B_P-t.B_PZ))
                keta = 0.5*log((t.hadron_P+t.hadron_PZ)/(t.hadron_P-t.hadron_PZ))
                mpeta = 0.5*log((t.muplus_P+t.muplus_PZ)/(t.muplus_P-t.muplus_PZ))
                mmeta = 0.5*log((t.muminus_P+t.muminus_PZ)/(t.muminus_P-t.muminus_PZ))
            except ValueError:
                beta = 0
                keta = 0
                mpeta = 0
                mmeta = 0
            t.AddVar(beta, "B_ETA", res_tuple)
            t.AddVar(keta, "hadron_ETA", res_tuple)
            t.AddVar(mpeta, "muplus_ETA", res_tuple)
            t.AddVar(mmeta, "muminus_ETA", res_tuple)
            dpt = fabs(t.muplus_PT - t.muminus_PT)
            t.AddVar(dpt, "muon_dpt", res_tuple)
            t.FillVars(res_tuple)

    t.SetBranchStatus("*", 1)
    t.OptimizeBaskets()
    t.Write("", ROOT.TObject.kOverwrite)
    newfile.Close()


    f.Close()
    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start

