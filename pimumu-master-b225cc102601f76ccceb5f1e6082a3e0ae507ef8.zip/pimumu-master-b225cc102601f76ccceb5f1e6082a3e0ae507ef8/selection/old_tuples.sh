
python select_events.py -f ~/data/Pimm/greg/OldJpsiK.root -t DecayTree -p -j -g
python select_events.py -f ~/data/Pimm/greg/OldJpsiPi.root -t DecayTree -p -j -g
python select_events.py -f ~/data/Pimm/greg/OldJpsiK_presel.root -t DecayTree -l -g
python select_events.py -f ~/data/Pimm/greg/OldJpsiPi_presel.root -t DecayTree -l -g
