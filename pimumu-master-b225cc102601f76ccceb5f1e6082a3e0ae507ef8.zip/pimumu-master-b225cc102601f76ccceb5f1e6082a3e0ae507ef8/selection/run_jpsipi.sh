#python select_events.py -f ~/data/Pimm/raw/with_bdt_pimumu_11_isoln.root -t DecayTree -p -j
#python select_events.py -f ~/data/Pimm/raw/with_bdt_pimumu_12_isoln.root -t DecayTree -p -j
#mv ~/data/Pimm/raw/*presel.root ~/data/Pimm/presel/.
#python select_events.py -f ~/data/Pimm/presel/with_bdt_pimumu_11_isoln_presel.root -t DecayTree -l -j
#python select_events.py -f ~/data/Pimm/presel/with_bdt_pimumu_12_isoln_presel.root -t DecayTree -l -j
#hadd -f ~/data/Pimm/presel/with_bdt_jpsipi_tot_isoln_presel_loosepid.root ~/data/Pimm/presel/with_bdt_pimumu_1*_isoln_presel_loosepid.root
#python select_events.py -f ~/data/Pimm/presel/with_bdt_pimumu_11_isoln_presel.root -t DecayTree -o -j
#python select_events.py -f ~/data/Pimm/presel/with_bdt_pimumu_12_isoln_presel.root -t DecayTree -o -j
#hadd -f ~/data/Pimm/presel/with_bdt_jpsipi_tot_isoln_presel_offsel.root ~/data/Pimm/presel/with_bdt_pimumu_1*_isoln_presel_offsel.root

python select_events.py -f ~/data/Pimm/raw/with_bdt_pimumu_11_isoln.root -t DecayTree -p 
python select_events.py -f ~/data/Pimm/raw/with_bdt_pimumu_12_isoln.root -t DecayTree -p 
mv ~/data/Pimm/raw/*presel.root ~/data/Pimm/presel/.
#python select_events.py -f ~/data/Pimm/presel/with_bdt_pimumu_11_isoln_presel.root -t DecayTree -o 
#python select_events.py -f ~/data/Pimm/presel/with_bdt_pimumu_12_isoln_presel.root -t DecayTree -o 
#rm ~/data/Pimm/presel/with_bdt_pimumu_tot_isoln_presel_offsel.root
#hadd -f ~/data/Pimm/presel/with_bdt_pimumu_tot_isoln_presel_offsel.root ~/data/Pimm/presel/with_bdt_pimumu_1*_isoln_presel_offsel.root
hadd -f ~/data/Pimm/presel/with_bdt_pimumu_tot_isoln_presel.root ~/data/Pimm/presel/with_bdt_pimumu_1*_isoln_presel.root



