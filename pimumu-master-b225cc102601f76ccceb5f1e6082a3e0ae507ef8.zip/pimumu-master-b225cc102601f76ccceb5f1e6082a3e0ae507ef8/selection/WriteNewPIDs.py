
# python std
import sys
import os
import time
from math import isnan

# root
from ROOT import TFile, TRandom, TRandom3, TMath, gROOT
from tree import TTree # custom TTree 

# global debug
debug = False

# global dictionary of pid numbers
particles = {
    211  : "Pion",
    321  : "Kaon",
    2212 : "Proton",
    13   : "Muon"  
}

# global dictionaries which will hold all of the DLLclass objects
Pions = {}
Kaons = {}
Muons = {}
Protons = {}



def CopyTree(tree, newtree, res_tuple ):

    if debug:
        print "Entered WriteNewPIDs.CopyTree"
    branches = tree.GetListOfBranches()
    var_list = []
    for b in branches:
        #    var_list.append(b.GetName())
        #for n in var_list:
            n = b.GetName()
            if type(tree.__getattr__(n))==type(float()):
                res_tuple = newtree.AddVar(tree.__getattr__(n), n, res_tuple )
            elif  type(tree.__getattr__(n))==type(int()):
                res_tuple = newtree.AddVarInt(tree.__getattr__(n), n, res_tuple)




def findRange(i, nentries, tot = 10):
    num = int(nentries/tot)
    minimum = i*num
    maximum = minimum + num
    #why the hell is this here? shouldn't been needed
    if i == tot-1:
        maximum = nentries

    return [minimum, maximum]



def ResampleCorrectDLL(which_dll, true_pid, p, eta, numTracks, muons=False):
    """Returns a resampled DLL for the true ID of the particle"""

    # see if we've got a particle we care about
    try:
        name = particles[abs(true_pid)]

        # get the correct distribution (global scope dictionaries)
        if name == "Pion":
            histo = Pions[which_dll].GetDLLhisto(p, eta, numTracks)
    
        elif name == "Kaon":
            histo = Kaons[which_dll].GetDLLhisto(p, eta, numTracks)
    
        elif name == "Muon":
            if which_dll.count("Down") or which_dll.count("Up"): 
                    # muons are a special case and can't have "down" in the dll name
                dll_for_muons = which_dll.replace("Down", "").replace("Up", "")
               # additionally, the old naming convention specifies isMuon
                histo = Muons[dll_for_muons].GetDLLhisto(p, eta, numTracks)
            else:
                histo = Muons[which_dll].GetDLLhisto(p, eta, numTracks)

        elif name == "Proton":
            histo = Protons[which_dll].GetDLLhisto(p, eta, numTracks)

    # sample the DLL histogram
        DLL = histo.GetRandom()
        DLL = 0 if isnan( DLL ) else DLL # DLL zero if resamples nan
    except KeyError:
        DLL = -2000 # for true photons, electrons or whatever
    return DLL


def turn_on_branches( t ) :
    t.SetBranchStatus("*",0)
    t.SetBranchStatus("hadron_P",1)
    t.SetBranchStatus("hadron_PT",1)
    t.SetBranchStatus("hadron_TRUEID",1)
    t.SetBranchStatus("muplus_P",1)
    t.SetBranchStatus("muplus_PT",1)
    t.SetBranchStatus("muplus_TRUEID",1)
    t.SetBranchStatus("muminus_P",1)
    t.SetBranchStatus("muminus_PT",1)
    t.SetBranchStatus("muminus_TRUEID",1)



def AddBranch(t, Range, num, dll=False, probnn=False):
    """TODO Fill in this docstring"""
    if debug:
        print "Entered WriteNewPIDs.AddBranch"

    # prepare to loop over tree
    nentries = t.GetEntries()   # entries in the tree
    print nentries
    res_tuple = {}              # empty tuple for values
    r,m,s = status("Starting loop over %d events"%(nentries)) # monitor memory

    turn_on_branches( t ) 

    # loop over entries in this batch
    for i in xrange(Range[0], Range[1]):
        t.GetEntry(i) # (tree now has python data members for all branches)

        # report change in memory
        if (i%  (nentries/10)  )==0:
            m = change(m,"Processing event %s out of %s"%(i, nentries))

        # get number of tracks in this event... default is 100
        numTracks = 100 
        if t.FindBranch("nBestTracks") : 
            numTracks = t.nBestTracks 
        elif t.FindBranch("BestTracks") :
            numTracks = t.BestTracks 
        elif t.FindBranch("nTracks") :
            numTracks = t.nTracks 

        #----------------------------------------------------------------------
        # kaon

        # compute PL and ETA for the Kaon
        hadron_PL = TMath.sqrt(t.hadron_P*t.hadron_P-t.hadron_PT*t.hadron_PT)
        hadron_ETA = (1.0/2.0)*TMath.Log((t.hadron_P+t.hadron_PZ)/(t.hadron_P-t.hadron_PZ))

        # add PL and ETA to the tree
        #t.AddVar(hadron_PL, "hadron_PL", res_tuple)
        #t.AddVar(hadron_ETA, "hadron_ETA", res_tuple)

        if dll :
            # attribute the correct DLLK to the true identity of the 'Kaon'
            hadron_DLLK = ResampleCorrectDLL("DLLKDown", t.hadron_TRUEID, 
                                     t.hadron_P, hadron_ETA, numTracks)
            # add the new DLL to the tree
            t.AddVar(hadron_DLLK, "hadron_DataPIDK", res_tuple)
            # attribute the correct DLLK to the true identity of the 'Kaon'
            hadron_DLLK = ResampleCorrectDLL("DLLmuDown", t.hadron_TRUEID, 
                                     t.hadron_P, hadron_ETA, numTracks)
            # add the new DLL to the tree
            t.AddVar(hadron_DLLK, "hadron_DataPIDmu", res_tuple)

        if probnn:
            # attribute the correct DLLK to the true identity of the 'Kaon'
            hadron_DLLK = ResampleCorrectDLL("DLLKDown", t.hadron_TRUEID, 
                                     t.hadron_P, hadron_ETA, numTracks)
            # add the new DLL to the tree
            t.AddVar(hadron_DLLK, "hadron_DataProbNNk", res_tuple)
            # attribute the correct DLLK to the true identity of the 'Kaon'
            hadron_DLLK = ResampleCorrectDLL("DLLmuDown", t.hadron_TRUEID, 
                                     t.hadron_P, hadron_ETA, numTracks)
            # add the new DLL to the tree
            t.AddVar(hadron_DLLK, "hadron_DataProbNNmu", res_tuple)

        if i < 10 :
            print i, "hadron_DLLK %g hadron_P %g hadron_PL  %g hadron_ETA %g numTracks %g"%(hadron_DLLK, t.hadron_P, hadron_PL, hadron_ETA, numTracks)

        #----------------------------------------------------------------------

        ##### Computing the PL and the ETA for the Muons (plus and minus together)
        muminus_PL = TMath.sqrt(t.muminus_P*t.muminus_P-t.muminus_PT*t.muminus_PT)
        muminus_ETA = (1.0/2.0)*TMath.Log((t.muminus_P+muminus_PL)/(t.muminus_P-muminus_PL))    
        muplus_PL = TMath.sqrt(t.muplus_P*t.muplus_P-t.muplus_PT*t.muplus_PT)
        muplus_ETA = (1.0/2.0)*TMath.Log((t.muplus_P+muplus_PL)/(t.muplus_P-muplus_PL))

        #t.AddVar(muminus_PL, "muminus_PL", res_tuple)
        #t.AddVar(muminus_ETA, "muminus_ETA", res_tuple)
        #t.AddVar(muplus_PL, "muplus_PL", res_tuple)
        #t.AddVar(muplus_ETA, "muplus_ETA", res_tuple)

        if dll :
            ##### Attributing the DLLmu to Mu plus and Mu minus
            muminus_DLLmu = ResampleCorrectDLL("DLLmuDown", t.muminus_TRUEID,
                                           t.muminus_P, muminus_ETA, numTracks)
            t.AddVar(muminus_DLLmu, "muminus_DataPIDmu", res_tuple)
            muplus_DLLmu = ResampleCorrectDLL("DLLmuDown", t.muplus_TRUEID,
                                          t.muplus_P, muplus_ETA, numTracks)
            t.AddVar(muplus_DLLmu, "muplus_DataPIDmu", res_tuple)
            muminus_DLLK = ResampleCorrectDLL("DLLKDown", t.muminus_TRUEID,
                                              t.muminus_P, muminus_ETA, numTracks)
            t.AddVar(muminus_DLLK, "muminus_DataPIDK", res_tuple)     
            muplus_DLLK = ResampleCorrectDLL("DLLKDown", t.muplus_TRUEID,
                                               t.muplus_P, muplus_ETA, numTracks)
            t.AddVar(muplus_DLLK, "muplus_DataPIDK", res_tuple)

        if probnn :
            ##### Attributing the DLLmu to Mu plus and Mu minus
            muminus_DLLmu = ResampleCorrectDLL("DLLmuDown", t.muminus_TRUEID,
                                           t.muminus_P, muminus_ETA, numTracks)
            t.AddVar(muminus_DLLmu, "muminus_DataProbNNmu", res_tuple)
            muplus_DLLmu = ResampleCorrectDLL("DLLmuDown", t.muplus_TRUEID,
                                          t.muplus_P, muplus_ETA, numTracks)
            t.AddVar(muplus_DLLmu, "muplus_DataProbNNmu", res_tuple)
            muminus_DLLK = ResampleCorrectDLL("DLLKDown", t.muminus_TRUEID,
                                              t.muminus_P, muminus_ETA, numTracks)
            t.AddVar(muminus_DLLK, "muminus_DataProbNNk", res_tuple)     
            muplus_DLLK = ResampleCorrectDLL("DLLKDown", t.muplus_TRUEID,
                                               t.muplus_P, muplus_ETA, numTracks)
            t.AddVar(muplus_DLLK, "muplus_DataProbNNk", res_tuple)



        #

        # not sure I understand this... why do I have to fill the variables 
        # if I've already added them
        t.FillVars(res_tuple)

    #--------------------------------------------------------------------------
    # ends loop over events
    #--------------------------------------------------------------------------

    #from ROOT import gROOT # don't think i need groot here

    # figure out new file name
    head, tail = os.path.split ( options.file ) 
    print head, tail, tail[ : tail.find(".root") ] 
    if options.dll:
        extra = "_pid" # labeled as containing new pid variables
    if options.probnn:
        extra = "_probnn" # labeled as containing new pid variables
    newfilename = os.path.join( head, tail[ : tail.find(".root") ] + extra + ".root" )

    
    t.SetBranchStatus("*",1)

    # save resampled tree
    print "writing to ", newfilename
    fKstmumu = TFile(newfilename , "RECREATE")
    status("pre tree copy")
    #newTree = t.CopyTree("","",Range[1]) # copy tree upto the range of the previous batch job 
    newTree = t.CopyTree("","",Range[1]) # copy tree upto the range of the previous batch job 
    newTree.SetName("DecayTree")
    status("after tree copy")
    fKstmumu.WriteTObject(newTree)
    fKstmumu.Close()



def parse_options():
    """parse all options for this script"""
    from optparse import OptionParser
    parser = OptionParser()

    # set up options
    parser.add_option("-t", "--tree", dest="tree", action="store",
            default="DecayTree", help="tree" ) 
    parser.add_option("-j", "--job", dest="job", action="store", type="int", 
                      default=-1, help="job number")
    parser.add_option("-s", "--subjob", dest="subjob", action="store", 
                      type="int", default=-1, help="number of subjob")
    parser.add_option("-f", "--file", dest="file", action="store", 
                      type="string", default=None, help="directory")
    parser.add_option("-n", "--nevts", dest="nevts", action="store", 
                      type="int", default=-1, help="number of events")
    parser.add_option("-v", "--version", dest="version", action="store", 
                      default="20r1", help="stripping/PIDEffTables version")
    parser.add_option("-m", "--muons", dest="muons", action="store_true")
    parser.add_option("-p", "--prob", dest="probnn", action="store_true")
    parser.add_option("-d", "--dll", dest="dll", action="store_true")

    # do the parsing
    (options,args) = parser.parse_args()
    return options




def run_file( filename, treename ) :


    status("opening file %s"%(filename))
    from ROOT import TFile
    f = TFile(filename, "READ")
    f.Print()
    if not f.IsOpen(): 
        print "no file! ", filename
        return

    print "getting tree", options.tree
    t = f.Get(options.tree)
    if not t: 
        print "no tree! ", options.tree
        return

    if debug: 
        print "file and tree pointers:"
        print f
        print t

    status("opened files")




    tot = 1
    nentries = t.GetEntries()

    if options.nevts > 0 :
        nentries = options.nevts 

    SmearingSeed = 10000
    iRun = 0
    ## ##### Fluctuating the PID 
    gRandom.SetSeed(SmearingSeed)


    # Number of jobs in which you want to split up your ntuple 

    #for iRun in xrange(1, 2)
    gRandom.SetSeed(iRun+SmearingSeed)
    Range = findRange(iRun, nentries, tot)

    print "total jobs", tot
    print "nentries", nentries
    print "iRun", iRun
    print "SmearingSeed", SmearingSeed
    print "Range", Range

    #sys.exit()

    AddBranch(t, Range, iRun, options.dll, options.probnn ) # was "Muons" (dictionary)



    f.Close()





if __name__ == "__main__":
    import ROOT
    ROOT.gROOT.SetBatch(True)
    ROOT.gErrorIgnoreLevel = 5000
    # start the stopwatch
    t1 = time.localtime() 
    print time.asctime(t1)

    # get script options
    options = parse_options()

    # unpack options
    useDouble = True
    jobnumber = str(options.job)
    subjobnumber = str(options.subjob)
    debug = False
    # append path to PID tables and the class DLLClass
    BASEDIR = "~/data/"
    #BASEDIR = "/vols/lhcbdisk04/scunliffe/Kstmm/"
    #BASEDIR = "/scratch/scunliffe/Kstmm/"
    if options.probnn:
        PIDTABLEPATH = os.path.join(BASEDIR,"PIDEffTables_v20r1/forProbNN/" )
    else :
        PIDTABLEPATH = os.path.join(BASEDIR,"PIDEffTables_v20r1/forDLL/" )

    from reader.memtest import stacksize, status, change #####* #stacksize
    from reader.ReadEffTables import DLLclass

    # to seed random numbers
    gRandom = TRandom(TRandom3())


    status("opening tables")
    #--------------------------------------------------------------------------
    # initialize the DLLclass objects putting them into global scope dictionary
    
    if debug:
        print "WriteNewPIDs.__main__: About to instantiate DLLclass objects"

    #### Kaons
    print "ProbNNk"

    g1 = DLLclass(Particle="Kaon", whichDLL="DLLK", Mag="Up", 
                  options="normal,both", tablepath=PIDTABLEPATH)
    g1.Initialize()
    Kaons[g1.whichDLL+g1.Mag] = g1

    g2 = DLLclass(Particle="Kaon", whichDLL="DLLK", Mag="Down", 
                  options="normal,both", tablepath=PIDTABLEPATH)
    g2.Initialize()
    Kaons[g2.whichDLL+g2.Mag] = g2


    m1 = DLLclass(Particle="Muon", whichDLL="DLLK", Mag=None, 
                      options="normal,both", tablepath=PIDTABLEPATH)
    m1.Initialize()
    Muons[m1.whichDLL] = m1

    p1 = DLLclass(Particle="Pion", whichDLL="DLLK", Mag="Up", 
                      options="normal,both", tablepath=PIDTABLEPATH)
    p1.Initialize()
    Pions[p1.whichDLL+p1.Mag] = p1

    p2 = DLLclass(Particle="Pion", whichDLL="DLLK", Mag="Down", 
                      options="normal,both", tablepath=PIDTABLEPATH)
    p2.Initialize()
    Pions[p2.whichDLL+p2.Mag] = p2

    print "ProbNNmu"

    g3 = DLLclass(Particle="Kaon", whichDLL="DLLmu", Mag="Up", 
                  options="normal,both", tablepath=PIDTABLEPATH)
    g3.Initialize()
    Kaons[g3.whichDLL+g3.Mag] = g3

    g4 = DLLclass(Particle="Kaon", whichDLL="DLLmu", Mag="Down", 
                  options="normal,both", tablepath=PIDTABLEPATH)
    g4.Initialize()
    Kaons[g4.whichDLL+g4.Mag] = g4


    m2 = DLLclass(Particle="Muon", whichDLL="DLLmu", Mag=None, 
                      options="normal,both", tablepath=PIDTABLEPATH)
    m2.Initialize()
    Muons[m2.whichDLL] = m2

    p3 = DLLclass(Particle="Pion", whichDLL="DLLmu", Mag="Up", 
                      options="normal,both", tablepath=PIDTABLEPATH)
    p3.Initialize()
    Pions[p3.whichDLL+p3.Mag] = p3

    p4 = DLLclass(Particle="Pion", whichDLL="DLLmu", Mag="Down", 
                      options="normal,both", tablepath=PIDTABLEPATH)
    p4.Initialize()
    Pions[p4.whichDLL+p4.Mag] = p4



    #assert(False)
    status("loaded all DLL classes")

    tuplename = "BdKstmm.root" # default 

    if options.file :
        
        run_file( options.file, options.tree ) 



    status("end")

    #print "read ", t.GetBytesRead(), "in ", t.GetReadCalls(), "transactions"

    #os.system("rm -rf PIDEffTables/")

    t2 = time.localtime() 

    print "end", time.asctime(t2)
    #print "time taken", time.asctime(t2-t1)
