
#python select_events.py -f ~/data/Pimm/partreco/with_bdt_bujpsix_mc12_newpid_updated.root -t DecayTree -p -s -j
#python select_events.py -f ~/data/Pimm/partreco/with_bdt_bsjpsix_mc12_newpid_updated.root  -t DecayTree -p -s -j
#python select_events.py -f ~/data/Pimm/partreco/with_bdt_bujpsix_mc12_newpid_updated_presel.root -t DecayTree -o -s -j
#python select_events.py -f ~/data/Pimm/partreco/with_bdt_bsjpsix_mc12_newpid_updated_presel.root -t DecayTree -o -s -j

python select_events.py -f ~/data/Pimm/partreco/with_bdt_bdjpsix_mc12_newpid_updated.root  -t DecayTree -p -s -j
python select_events.py -f ~/data/Pimm/partreco/with_bdt_bdjpsix_mc12_newpid_updated_presel.root -t DecayTree -o -s -j
