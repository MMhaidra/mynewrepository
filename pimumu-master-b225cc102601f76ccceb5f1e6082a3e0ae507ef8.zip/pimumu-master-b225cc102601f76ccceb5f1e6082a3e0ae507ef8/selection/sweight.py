#! /usr/bin/env python

import ROOT, os, sys, time, math
from lhcbStyle import setLHCbStyle
from ROOT import RooDataSet, RooRealVar, RooArgSet, RooArgList
from ROOT import RooExponential, RooCBShape, RooAddPdf 
from ROOT import RooGaussian
from tree import TTree

def config_pdf(mass, oppo=False):
    mean = RooRealVar('mean', 'mean', 5279, 5200, 5400)
    s0 = RooRealVar('s0', 's0', 10, 5, 100)
    a0 = RooRealVar('a0', 'a0', 0.30, 0.05, 10.0)
    n0 = RooRealVar('n0', 'n0', 30)#,0,1000)
    s1 = RooRealVar('s1', 's1', 30, 0, 40)
    a1 = RooRealVar('a1', 'a1', 0.40, 0, 10)
    if oppo:
        a1 = RooRealVar('a1', 'a1', -0.40, -10, -0.05)
    n1 = RooRealVar('n1', 'n1', 30)#,0,1000)
    f0 = RooRealVar('f0', 'f0', 0.9, 0.0, 1.0)
    CBSHP1 = RooCBShape('CBSHP1', 'CBSHP1', mass, mean, s0, a0, n0)
    CBSHP2 = RooCBShape('CBSHP2', 'CBSHP2', mass, mean, s1, a1, n1)
    #CBSHP1 = RooGaussian('CBSHP1', 'CBSHP1', mass, mean, s0)
    #CBSHP2 = RooGaussian('CBSHP2', 'CBSHP2', mass, mean, s1)
    SIG  = RooAddPdf('SIG', 'SIG', RooArgList(CBSHP1, CBSHP2)
          , RooArgList(f0))
    e0   = RooRealVar('e0', 'e0', 0, -0.1, 0.1)
    BKG1  =  RooExponential('BKG', 'BKG', mass, e0) 
    nsig1 = RooRealVar('nsig', 'nsig', 1e6, 0, 1e9)
    nbkg1 = RooRealVar('nbkg', 'nbkg', 1e3, 0, 1e9) 
    PDF1 = RooAddPdf('PDF', 'PDF', RooArgList(SIG, BKG1)
          , RooArgList(nsig1, nbkg1))
    #PDF = SIG 
    return (PDF1, nsig1, nbkg1, [CBSHP1, CBSHP2, SIG, BKG1], 
            [mean,s0,a0,n0,s1,a1,n1,f0,e0])


if __name__ == '__main__':

    start = time.time()
    print time.asctime(time.localtime())
    print " setting batch mode " 
    from ROOT import gStyle, RooMsgService, RooFit
    RooMsgService.instance().setGlobalKillBelow(RooFit.ERROR)
    RooMsgService.instance().setSilentMode(True)
    ROOT.gROOT.SetBatch(True)
    setLHCbStyle()
    from optparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument("-d", "--dir", dest="dir", default=None
          , type='string', help="testing")
    parser.add_argument("-f", "--file", dest="file", default=None 
          , type="string", help="filename")
    parser.add_argument("-t", "--tree", dest="tree", default="DecayTree" 
          , type="string", help="treename")
    parser.add_argument("-n", "--nevts", dest="nevts", default=-1 
          , type="int", help="num events")

    options = parser.parse_args()

    print "splotting", options.file
    from ROOT import TFile
    f = TFile(options.file, "READ")
    tree = f.Get(options.tree)
    tree.SetBranchStatus("*", 0)
    tree.SetBranchStatus("B_M_real", 1)
    #dataset

    massmin = 5200
    massmax = 5500
    from ROOT import RooDataSet, RooRealVar, RooArgSet, RooFit
    mass = RooRealVar('B_M_real', 'm(h#mu#mu)', massmin, massmax)
    PDF, nsig, nbkg, pdfs, variables = config_pdf(mass, True)

    from ROOT import gROOT
    gROOT.cd()
    data = RooDataSet('data', 'data', tree, RooArgSet(mass))

    name = "splottest.pdf"
    c = ROOT.TCanvas("c", "", 800, 600)
    c.SaveAs(name+"[")
    res = PDF.fitTo(data, ROOT.RooFit.NumCPU(6), RooFit.Save(True))
    res.Print()
    plot = mass.frame()
    data.plotOn(plot)
    PDF.plotOn(plot)
    PDF.plotOn(plot, RooFit.Components("CBSHP1")
          , RooFit.LineStyle(ROOT.kDotted)
          , RooFit.LineColor(ROOT.kRed)
          )
    PDF.plotOn(plot, RooFit.Components("CBSHP2")
          , RooFit.LineStyle(ROOT.kDotted)
          , RooFit.LineColor(ROOT.kRed)
          )
    PDF.plotOn(plot, RooFit.Components("BKG") 
          , RooFit.LineStyle(ROOT.kDashed)
          , RooFit.LineColor(ROOT.kBlue)
          )
    plot.SetMinimum(1)
    plot.Draw()
    c.SaveAs(name)
    c.SetLogy()
    plot.Draw()
    c.SaveAs(name)

    c.SaveAs(name+"]")
    #c.SaveAs(name+"]")



    for v in variables:
        v.setConstant(True)

    from ROOT import RooStats, RooArgList
    # based on our model and our yield variables
    sData = RooStats.SPlot("sData", "An SPlot", data
          , PDF, RooArgList(nsig, nbkg))

    sData.Print("V")

    data.Print("V")
    

    nf = TFile(options.file[:options.file.find(".root")]\
            +"_sweight.root", "RECREATE")
    print "copying tree"
    tree.SetBranchStatus("*", 1)
    nt = tree.CopyTree("")
    n  = nt.GetEntries() 
    res_tuple = {}
    j = 0
    print n, data.numEntries()
    for i in range(0, n): 
        sw = 0.0 
        nt.GetEntry(i)
        vmass = tree.B_M_real
        if n > 10:
            if (i%(n/10)) == 0:
                print "processed %g"% j, "last weight %f,%f"% (j, sw)
        if (vmass > massmin and vmass < massmax):
            args = data.get(j)
            if j < 10:
                print vmass, args.getRealValue("B_M_real")
            sw = args.getRealValue("nsig_sw")
            j += 1
        nt.AddVar(sw, "sweight", res_tuple)
        nt.FillVars(res_tuple)
        
    nt.OptimizeBaskets()
    nt.Write("", ROOT.TObject.kOverwrite)

    print "closing", nf, f
    nf.Close() 
    f.Close()

    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start
    sys.exit(0)


