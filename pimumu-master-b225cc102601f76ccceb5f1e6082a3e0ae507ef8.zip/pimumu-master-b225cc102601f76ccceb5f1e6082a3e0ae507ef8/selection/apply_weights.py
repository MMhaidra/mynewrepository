#! /usr/bin/env python

import ROOT,os,sys,time,math

from ROOT import TTree
from array import array

def __AddVar__(self, var, name, res, use_double=True):
    """Add variable branch to the tree"""
    has_branche = res.has_key(name)
            
    if has_branche:
        res[name][0] = float(var)
    else :
        if use_double :
            print "branch ", name, " as Double "
            comp = array('d', [0])
            self.Branch(name, comp, name+'/D')
            comp[0] = ROOT.Double(var)
            aux = {name: comp}
            res.update(aux)
    return res
TTree.AddVar = __AddVar__ # dynamically add to TTree class

def __FillVars__(self, res_tuple):
    """fill the branches in the dictionary"""
    for name, val in res_tuple.iteritems() : 
        b = self.GetBranch(name) 
        b.Fill()

TTree.FillVars = __FillVars__

from ROOT import TFile

#from lhcbStyle import setLHCbStyle

if __name__ == '__main__' :

    start = time.time()
    print time.asctime(time.localtime())
    print " setting batch mode " 

    ROOT.gROOT.SetBatch(True)
    
    #setLHCbStyle()
    
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument( "-d", "--dir", dest="dir", default=None
            , type=str, help="testing" ) 
    parser.add_argument( "-f", "--file", dest="file", default=None 
            , type=str, help="filename" ) 
    parser.add_argument( "-t", "--tree", dest="tree", default="DecayTree" 
            , type=str, help="treename" ) 
    parser.add_argument( "-n", "--nevts", dest="nevts", default=-1 
            , type=int, help="num events" )
    parser.add_argument( "-b", "--branch", dest="branch", default="total_weight"
            , type=str, help="branchname" )

    options = parser.parse_args()
    
    f = TFile( options.file , "READ" )
    tree = f.Get( options.tree )

    #weights file
    #brem for the eminus
    rf2 = ROOT.TFile("ratio2012S20.root","READ")
    if not rf2.IsOpen() :
        print "no tracking file open"
        rf2.Close()
        exit()
    h2 = rf2.Get("Ratio")
    #brem for the eplus
    rf3 = ROOT.TFile("PerfHists_Mu_Strip20_MCTuneV2_MagDown_2D.root","READ")
    if not rf3.IsOpen() :
        print "no ismuon file open"
        rf3.Close()
        exit()
    h3 = rf3.Get("Mu_IsMuon==1_All")
    rf4 = ROOT.TFile("ratio_histograms.root", "READ")
    if not rf4.IsOpen() :
        print "no ratio file open"
        rf4.Close()
        exit()
    h1 = rf4.Get("ratio_spd")
    #h1 = rf4.Get("ratio_ntr")
    h4 = rf4.Get("ratio_bpt")

    #new file
    nf = TFile( options.file[:options.file.find(".root")]+"_corr.root"
            , "RECREATE")
    print "copying tree"
    tree.SetBranchStatus("*", 1)
    nval = tree.GetEntries()
    if options.nevts > 0 : 
        nval = options.nevts
    nt = tree.CloneTree(-1, "fast")
    n  = nt.GetEntries() 
    res_tuple = {}
    j = 0
    print n
    nt.SetBranchStatus("*", 0)
    #interesting branches
    list_of_branches = [ "nSPDHits", "hadron_P", "hadron_PZ"
            , "muplus_P", "muplus_PZ", "muminus_P", "muminus_PZ"
            , "hadron_ETA", "muplus_ETA", "muminus_ETA"
            , "B_PT" ]
    for b in list_of_branches :
        if nt.GetBranch( b ): 
            nt.SetBranchStatus(b, 1)

    haseta = False
    muplus_ETA = 0.0
    muminus_ETA = 0.0
    hadron_ETA = 0.0
    from math import log
    for i in range(0, n): 
        sw = 1.0 
        nt.GetEntry(i)
        bpt = tree.B_PT
        if n > 10 :
            if (i % (n/10)  )== 0 :
                print "processed %g" % i  , \
                    "last weight %f" % (sw)

        #calcualte eta if it doesn't exist
        if nt.GetBranch("hadron_ETA") :
            haseta = True
            hadron_ETA = nt.hadron_ETA 
            muplus_ETA = nt.muplus_ETA
            muminus_ETA = nt.muminus_ETA
        else :
            hadron_ETA =  0.5*log( (nt.hadron_P+nt.hadron_PZ) \
                    / (nt.hadron_P-nt.hadron_PZ) )
            muplus_ETA =  0.5*log( (nt.muplus_P+nt.muplus_PZ) \
                    / (nt.muplus_P-nt.muplus_PZ) )
            muminus_ETA =  0.5*log( (nt.muminus_P+nt.muminus_PZ) \
                    / (nt.muminus_P-nt.muminus_PZ) )
        #print hadron_ETA, muplus_ETA, muminus_ETA
        spdw = h1.GetBinContent( h1.FindBin( nt.nSPDHits ) )
        #spdw = h1.GetBinContent( h1.FindBin( nt.nTracks ) )
        bptw = h4.GetBinContent( h4.FindBin( nt.B_PT ) )
        keta = hadron_ETA 
        #0.5*log( (t.hadron_P+t.hadron_PZ) / (t.hadron_P-t.hadron_PZ) )
        kmom = nt.hadron_P / 1E3
        ktrw = h2.GetBinContent( h2.FindBin( kmom, keta ) ) 
        if True:
            mpeta = muplus_ETA 
            # 0.5*log( (t.muplus_P+t.muplus_PZ) / (t.muplus_P-t.muplus_PZ) )
            mmeta = muminus_ETA 
            #0.5*log( (t.muminus_P+t.muminus_PZ) / (t.muminus_P-t.muminus_PZ) )
            mpmom = nt.muplus_P / 1E3
            mmmom = nt.muminus_P / 1E3
            #tracking
            mptw = h2.GetBinContent( h2.FindBin( mpmom, mpeta ) )  
            mmtw = h2.GetBinContent( h2.FindBin( mmmom, mmeta ) ) 
            #ismuon
            mpiw = h3.GetBinContent( h3.FindBin( nt.muplus_P , mpeta ) )
            mmiw = h3.GetBinContent( h3.FindBin( nt.muminus_P , mmeta ) )

        
        for wv in [spdw, bptw, ktrw, mptw, mmtw, mpiw, mmiw]:
            if wv < 1E-5:
                wv = 1.0
            sw  *= wv
        #    sw = spdw * bptw * ktrw * mptw * mmtw * mpiw * mmiw
        #check if max bin?
        #print h1.GetNbinsX()
        #out of bounds checking?
        #if sw < 1E-5 :
        # print h2.FindBin( mpmom, mpeta ), h3.FindBin( nt.muplus_P , mpeta )
        # print ktrw, mptw, mmtw, mpiw, mmiw
        #print sw
        #sw = 1.0 
        nt.AddVar(sw, "datamc_weight", res_tuple)
        
        nt.FillVars(res_tuple)
    nt.SetBranchStatus("*", 1)
    nt.OptimizeBaskets()
    nt.Write("", ROOT.TObject.kOverwrite)

    print "closing", nf, f
    nf.Close() 
    f.Close()

    #c.SaveAs(name+"]")
    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start
 
