#! /usr/bin/env python
import ROOT, os, sys, time, math



psiveto = "!((8<qsq && qsq<11)||(12.5<qsq<15))" 

mc_truth = "(B_BKGCAT<11)"

presel = "("
presel += "(hadron_isMuonLoose<1)"
presel += "&&(hadron_InAccMuon>0)"
presel += "&&(B_PT > 300)"
presel += "&&(hadron_PT > 300)"
presel += "&&(muplus_PT > 300)"
presel += "&&(muminus_PT > 300)"
presel += "&&(muplus_isMuon == 1)"
presel += "&&(muminus_isMuon == 1))"
trigger = ""
trigger += "((B_L0MuonDecision_TOS==1)"
trigger += "&&(B_Hlt1TrackMuonDecision_TOS==1||B_Hlt1TrackAllL0Decision_TOS==1)"
trigger += "&&(B_Hlt2Topo2BodyBBDTDecision_TOS==1"
trigger += "||B_Hlt2Topo3BodyBBDTDecision_TOS==1"
trigger += "||B_Hlt2TopoMu2BodyBBDTDecision_TOS==1"
trigger += "||B_Hlt2TopoMu3BodyBBDTDecision_TOS==1"
trigger += "||B_Hlt2DiMuonDetachedDecision_TOS==1))"

jpsi = "&&(dimuon_M>3046 && dimuon_M<3146"

offsel = "BDT_4>0.0 && hadron_PIDK<-3 && muplus_ProbNNmu>0.2 && muminus_ProbNNmu>0.2"
kaonsel = "BDT_4>0.0 && hadron_PIDK>3 && muplus_ProbNNmu>0.2 && muminus_ProbNNmu>0.2"


if __name__ == '__main__':

    start = time.time()
    print time.asctime(time.localtime())
    print " setting batch mode "
    #from ROOT import gStyle, RooMsgService, RooFit
    #RooMsgService.instance().setGlobalKillBelow(RooFit.ERROR)
    #RooMsgService.instance().setSilentMode(True)
    ROOT.gROOT.SetBatch(True)
    #from lhcbStyle import setLHCbStyle
    #setLHCbStyle()
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument("-d", "--dir", dest="dir"
                        , default=None, type=str, help="testing")
    parser.add_argument("-f", "--file", dest="file"
                        , default=None, type=str, help="filename")
    parser.add_argument("-t", "--tree", dest="tree"
                        , default="DecayTree", type=str, help="treename")
    #parser.add_argument("-n", "--nevts", dest="nevts"
    #, default=-1, type=int, help="num events")
    parser.add_argument("-s", "--sim", dest="sim"
                        , action="store_true", default=False, help="siulated data")
    parser.add_argument("-p", "--presel", dest="presel"
                        , action="store_true", default=False, help="presel")
    parser.add_argument("-o", "--offsel", dest="offsel"
                        , action="store_true", default=False, help="offsel")
    #parser.add_argument("-b", "--bdt", dest="bdt"
    #, action="store_true", default=False, help="siulated data")
    parser.add_argument("-l", "--loose", dest="loose"
                        , action="store_true", default=False, help="loose pid")
    parser.add_argument("-m", "--dll", dest="dll"
                        , action="store_true", default=False, help="siulated data")
    parser.add_argument("-j", "--jpsi", dest="jpsi"
                        , action="store_true", default=False, help="jpsicut")
    parser.add_argument("-v", "--veto", dest="psi"
                        , action="store_true", default=False, help="psi veto")
    parser.add_argument("-g", "--old", dest="old"
                        , action="store_true", default=False, help="older config")
    parser.add_argument("-k", "-kaon", dest="kaon"
                        , action="store_true", default=False, help="older config")

    options = parser.parse_args()

    from ROOT import TFile
    f = TFile(options.file, "READ")
    print f
    if not f.IsOpen():
        print "file not open"
        f.Close()
        exit()
    tree = f.Get(options.tree)
    print tree
    if not tree:
        print "no tree"
        f.Close()
        exit()


    #cuts

    #totcut = trig +" && " +  veto +" && " +  ptcuts +" && " +  pidcuts
    #if options.notrig:
    #    totcut = veto +" && " +  ptcuts + " && " + pidcuts
    #    ext = "_notrig" + ext
    #if options.pion:
    #    totcut += " && " + pioncut
    #else:
    #    totcut += " && " + kaoncut
    #
    totcut = ""
    if options.presel:
        totcut = presel + " && " + trigger
        ext = "_presel.root"
    if options.offsel:
        totcut = offsel
        if options.kaon:
            totcut = kaonsel
        ext = "_offsel.root"

    if options.sim:
        #ext = "_sim" + ext
        #totcut += " && " + mc_truth
        if not options.dll:
            totcut = totcut.replace("PID", "DataPID")
            totcut = totcut.replace("ProbNN", "DataProbNN")
        else:
            totcut = totcut.replace("PID", "DLL")
            totcut = totcut.replace("ProbNN", "DLL")

    if options.psi:
        totcut += " && " + psiveto
    #else:
    #    totcut += " && !" + jpsicut


    if options.old:
        #trigger replacements
        totcut = totcut.replace("B", "Bplus")
        totcut = totcut.replace("hadron", "Kplus")
        totcut = totcut.replace("Bplus_Hlt", "BplusHlt")
        totcut = totcut.replace("Bplus_L0", "BplusL0")
        totcut = totcut.replace("dimuon", "Jpsi")
        #totcut = totcut.replace("isMuonLoose", "MUON_IsMuonLoose")
        totcut = totcut.replace("InAccMuon", "MUON_InAcceptance")
        totcut = totcut.replace("IsMuon", "MUON_IsMuon")
        totcut = totcut.replace("isMuon", "MUON_IsMuon")
    #if options.bdt:
    #    totcut += " && " + bdtcut
    #    ext = "_bdt" + ext


    print totcut

    newfilename = options.file[:options.file.find(".root")] + ext

    newfile = TFile(newfilename, "RECREATE")

    nt = tree.CopyTree(totcut)

    nt.Write()

    newfile.Close()
    f.Close()
    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start
    sys.exit(0)

