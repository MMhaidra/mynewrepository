import sys
import resource



import os

_proc_status = '/proc/%d/status' % os.getpid()

_scale = {'kB': 1024.0, 'mB': 1024.0*1024.0,
          'KB': 1024.0, 'MB': 1024.0*1024.0}

#global memory status
prev_mem = 0.0

def _VmB(VmKey):
    '''Private.
    '''
    global _proc_status, _scale
    # get pseudo file  /proc/<pid>/status
    try:
        t = open(_proc_status)
        v = t.read()
        t.close()
    except:
        return 0.0  # non-Linux?
    #print _proc_status
    # get VmKey line e.g. 'VmRSS:  9999  kB\n ...'
    i = v.index(VmKey)
    #print i, v
    v = v[i:].split(None, 3)  # whitespace
    #print v
    if len(v) < 3:
        return 0.0  # invalid format?
        # convert Vm value to megabytes
    return float(v[1]) / _scale[v[2]]


def memory(since=0.0):
    '''Return memory usage in bytes.
    '''
    return  _VmB('VmSize:') - since

def resident(since=0.0):
    '''Return resident memory usage in bytes.
    '''
    return _VmB('VmRSS:') - since

def stacksize(since=0.0):
    '''Return stack size in bytes.
    '''
    return _VmB('VmStk:')  - since

def status(msg = None):
    if msg: print msg
    #r = resource.getrusage(resource.RUSAGE_SELF)
    print "resident set  %g MB, memory %g MB"%(resident(),memory()) #, stack memory %g MB,stacksize(
    return (resident(),memory(),stacksize())

def change(prev_mem=0.0, msg=None):
    m = memory()
    if msg: print msg
    print "memory change = %g MB "%(m-prev_mem)
    return m
