#include "ReadEffTables.h"

#include <string>
#include <vector>
#include <map>
#include <sstream>
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include <TRandom3.h>
#include <TH1F.h>
#include <TH3F.h>
#include <TH3D.h>
#include <TAxis.h>
#include <TFile.h>
#include <TKey.h>

using namespace std;

DLLclass::DLLclass(const std::string &Mag,
         const std::string &Particle,
         const std::string &whichDLL, 
         const std::string &options,
         const std::string &tablepath):
fOptions(options), fRandom(0)
{
  cout << "************************************************" << endl
       << "This is an interface for computing the PID efficiencies and DLLs" << endl
       << "The binning used is :" << endl
       << "************************************************" << endl
       << "Possible options are:" << endl
       << "PID: It simulate the PID distributions for each phase space bin" << endl
       << "Efficiency: It computes the efficiency for a particular PID cut" << endl
       << "Both: You can do both things but it uses more RAM" << endl
       << "The default is None, to initialize it chooce the option and the do initialize()" << endl
       << "************************************************" << endl;

  // Setting if I want PiDLL or MuonDLL 
  fWhichDLL = whichDLL;
  fMag = Mag;
  fParticle = Particle;
  fErrorType = "poisson";
  for (size_t n = 0; n < fOptions.size(); ++n)
    if (fOptions[n] >= 'A' && fOptions <= 'Z')
      fOptions[n] += ('a'-'A');

  if (!fMag.empty())
  {
    fFileName1D = tablepath+fParticle+fWhichDLL+"Mag"+fMag+"TH1s.root";
    fFileName3D = tablepath+fParticle+fWhichDLL+"Mag"+fMag+".root";
  }
  else
  {
    fFileName1D = tablepath+fParticle+fWhichDLL+"TH1s.root";
    fFileName3D = tablepath+fParticle+fWhichDLL+".root";
  }

  fFile1D = NULL;
  fFile3D = NULL;

  fSys_n = false;
  fSys_p = false;
  fSys_e = false;
  fSys_level = 0.1;
}

DLLclass::~DLLclass()
{
  delete fFile1D;
  delete fFile3D;
  //There was some issue with the garbage collector, should fix
  cout << "Warning, There is a potential memory leak here" << endl;
  return;
  for (map<int,TH1*>::iterator it = fTH1histos.begin(); it != fTH1histos.end(); ++it)
    delete it->second;
  for (map<float,TH3*>::iterator it = fTH3histos.begin(); it != fTH3histos.end(); ++it)
    delete it->second;
  delete fTH1histoAux;
}


void DLLclass::setSystematic(bool _sys_ntracks, bool _sys_p, bool _sys_e, double _syslevel)
{
  fSys_n = _sys_ntracks;
  fSys_p = _sys_p;
  fSys_e = _sys_e;
  fSys_level = _syslevel;
}

void DLLclass::FillHistos1D()
{
//        """Gets the relevant 1D histograms from the file"""
  if (!fFile1D) return;
  TIter keys(fFile1D->GetListOfKeys());
  TKey *key = NULL;
  while ((key = (TKey *)keys()))
  {
    if (string("TH1F").compare(key->GetClassName()) == 0)
    {
      int num = atoi((key->GetName()[0]=='h')?key->GetName()+1:key->GetName());
      fTH1histos[num] = (TH1*)fFile1D->Get(key->GetName());
    }
    else if (string("TH3F").compare(key->GetClassName()) == 0 || string("TH3D").compare(key->GetClassName()) == 0)
      fTH1histoAux = (TH3*)fFile1D->Get(key->GetName());
  }
}

void DLLclass::FillHistos3D()
{
//        """Gets the relevant 3D histograms from the file"""
  if (!fFile3D) return;
  TIter keys(fFile3D->GetListOfKeys());
  TKey *key = NULL;
  while ((key = (TKey *)keys()))
    if (string("TH3F").compare(key->GetClassName()) == 0 || string("TH3D").compare(key->GetClassName()) == 0)
    {
      string name(key->GetName());
      size_t pos = name.find("HistoCut");
      if (pos == string::npos)
        pos = 0;
      else
        pos += 8; // length of histocut
      if (name.find("<", pos) != string::npos)
      {
        cerr << "The histograms in input are suppose to imply always > sign" << endl;
        return; //original asserted here
      }
      size_t gt = name.find(">");
      pos = (gt != string::npos)?gt+1:pos;
      float num = atof(name.c_str()+pos);
      fTH3histos[num] = (TH3*)fFile3D->Get(key->GetName());
    }
}


void DLLclass::Initialize()
{
//        """Opens the files and gets the histograms for this instance"""

  if (fOptions.find("efficiency") != string::npos || fOptions.find("both") != string::npos)
  {
    if (fOptions.find("verbose") != string::npos)
      cout << "Initializing 3D hstos to compute Efficiency" << endl;

    // open and check 3D histogram file    
    fFile3D = new TFile(fFileName3D.c_str());
    if (!fFile3D || !fFile3D->IsOpen())
    {
      cerr << "DLLclass::Initialize ERROR! problem with the file: " << fFileName3D << endl;
      return;
    }
    FillHistos3D();
  }
  if (fOptions.find("pid") != string::npos || fOptions.find("both") != string::npos)
  {
    if (fOptions.find("verbose") != string::npos)
      cout << "Initializing 1D hstos to compute PIDs" << endl;

    // open and check 1D histogram file
    fFile1D = new TFile(fFileName1D.c_str());
    if (!fFile1D || !fFile1D->IsOpen())
    {
      cerr << "DLLclass::Initialize ERROR! problem with the file: " << fFileName1D << endl;
      return;
    }
    FillHistos1D();
  }
}

double DLLclass::CalcN(double sigma, double epsilon)
{
  if (sigma == 0)
    return 0;
  return epsilon*(1-epsilon)/(sigma*sigma);
}


void DLLclass::PrintInstructions()
{
  cout << "************************************************" << endl;
  cout << "Possible options are:" << endl;
  cout << "PID: It simulate the PID distributions for each phase space bin" << endl;
  cout << "Efficiency: It computes the efficiency for a particular PID cut" << endl;
  cout << "Both: You can do both things but it uses more RAM" << endl;
  cout << "The default is None, to initialize it chooce the option and the do initialize()" << endl;
  cout << "************************************************" << endl;
}

int DLLclass::FindBin3D(TH3 *h, double x, double y, double z)
{
  int ix = h->GetXaxis()->FindBin(x),
      iy = h->GetYaxis()->FindBin(y),
      iz = h->GetZaxis()->FindBin(z);

  // If I am outside the range I set the range extreme
  if (ix == 0) ix = 1;
  if (ix > h->GetXaxis()->GetNbins()) ix = h->GetXaxis()->GetNbins();
  if (iy == 0) iy = 1;
  if (iy > h->GetYaxis()->GetNbins()) iy = h->GetYaxis()->GetNbins();
  if (iz == 0) iz = 1;
  if (iz > h->GetZaxis()->GetNbins()) iz = h->GetZaxis()->GetNbins();

  return h->GetBin(ix, iy, iz);
}

vector<double> DLLclass::GetOrderXYZ(TH3 *h, double p, double eta, double ntrack)
{
//        """Gets (p, eta, ntrack) variables in the correct (x, y, z) axis order
//        for sampling the histogram"""

  //I'm sorry. This is really ugly, but works
  TAxis *axis[3] = {h->GetXaxis(),h->GetYaxis(),h->GetZaxis()};
  vector<double> ret(3);
  for (size_t n = 0; n < ret.size(); ++n)
    switch (axis[n]->GetTitle()[0])
    {
      case 'p': case 'P':
        ret[n] = p;
        break;
      case 'e': case 'E':
        ret[n] = eta;
        break;
      case 'n': case 'N':
        ret[n] = ntrack;
        break;
    }
  return ret;
}



vector<double> DLLclass::ComputeEff(double DLLK, double P, double ETA, double nTrack, bool eff)
{
  bool verbose = (fOptions.find("verbose") != string::npos);
  if (verbose)
    cout << "The default cut is DLL>value" << endl
         << "To have the cut DLL<value, specify the option eff = false " << endl;

  if (!fTH3histos.size())
  {
    cout << "Please initialize efficiency histograms!" << endl;
    PrintInstructions();
    return vector<double>();
  }

  map<float, TH3*>::iterator next(fTH3histos.begin()), last(fTH3histos.begin());
  for (map<float, TH3*>::iterator it(fTH3histos.begin()); it != fTH3histos.end(); ++it)
  {
    next = it;
    if (DLLK <= it->first)
      break;
    last = it;
  }


  //try to extrapolate to the region outside the covered histograms
  if (next == fTH3histos.begin() && DLLK != next->first && fTH3histos.size() > 1)
    ++next;
  if (last == next && last != fTH3histos.begin())
    --last;

  vector<double> xyz(GetOrderXYZ(next->second, P, ETA, nTrack));

  if (verbose)
    cout << "This is the ordered coordinate" << endl
         << xyz[0] << " " << xyz[1] << " " << xyz[2] << endl;

  int ibin = FindBin3D(next->second, xyz[0], xyz[1], xyz[2]);
  double highval = next->second->GetBinContent(ibin),
         higherr = next->second->GetBinError(ibin);

  if (verbose)
    cout << "Bin Number " << ibin << endl;

  vector<double> ret(2);
  if (next->first == DLLK)
  {
    ret[0] = (eff)?highval:(1-highval);
    ret[1] = higherr;
    return ret;
  }

  ibin = FindBin3D(last->second, xyz[0], xyz[1], xyz[2]);
  double lowval = last->second->GetBinContent(ibin),
         lowerr = last->second->GetBinError(ibin);

  double ddx = (DLLK - last->first)/(next->first - last->first),
         val = lowval + (highval - lowval)*ddx,
         err = lowerr + (higherr - lowerr)*ddx;

  ret[0] = (eff)?val:(1-val);
  ret[1] = err;
  return ret;
}


TH1F *DLLclass::GetDLLhisto(double P, double ETA, double nTrack)
{
  if (!fTH1histos.size() || !fTH1histoAux)
  {
    cout << "Please initialize efficiency histograms!" << endl;
    PrintInstructions();
    return NULL;
  }
  vector<double> xyz(GetOrderXYZ(fTH1histoAux, P, ETA, nTrack));
  int ibin = FindBin3D(fTH1histoAux, xyz[0], xyz[1], xyz[2]);

  vector<double> adjxyz(GetOrderXYZ(fTH1histoAux, fSys_p, fSys_e, fSys_n));
  ibin = AdjustBin3D(fTH1histoAux, ibin, xyz, adjxyz);
  return (TH1F*)fTH1histos[ibin];
}


int DLLclass::AdjustBin3D(TH3 *h, int ibin, const vector<double> &xyz, const vector<double> &adjxyz)
{
  int newbin = ibin;
  if (adjxyz[0] || adjxyz[1] || adjxyz[2])
  {
    vector<int> ivals(3);
    h->GetBinXYZ(ibin, ivals[0], ivals[1], ivals[2]);
    TAxis *axis[3] = {h->GetXaxis(),h->GetYaxis(),h->GetZaxis()};
    //adjust for systematic studies
    for (size_t i = 0; i < adjxyz.size() && i < 3; ++i)
    {
      if (adjxyz[i])
      {
        //gettop and low edges
        double lowedge = axis[i]->GetBinLowEdge(ivals[i]),
               highedge = axis[i]->GetBinLowEdge(ivals[i] + 1);

        //following directly copied from python, I don't think it is correct
        //calc min / max 10 per cent hard coded
        double lval = lowedge + (1.0*(highedge - lowedge)),
               hval = highedge - (1.0 *(highedge - lowedge));

        if (fSys_level < 0  && xyz[i] < lval)
          ivals[i] -= 1;
        else if (fSys_level > 0 && xyz[i] > hval)
          ivals[i] += 1;
        //set minumum
        if (ivals[i] < 1)
          ivals[i] = 1;
      }
    }
    //If I am above the range I set the range extreme
    if (ivals[0] > h->GetXaxis()->GetNbins())
      ivals[0] = h->GetXaxis()->GetNbins();
    if (ivals[1] > h->GetYaxis()->GetNbins())
      ivals[1] = h->GetYaxis()->GetNbins();
    if (ivals[2] > h->GetZaxis()->GetNbins())
      ivals[2] = h->GetZaxis()->GetNbins();
    newbin = h->GetBin(ivals[0], ivals[1], ivals[2]);
  }
  return newbin;
}


void DLLclass::ProduceTH1histos(bool poisson_error)
{
  map<float, TH3*> histos3D;
  vector<float> binning;
  TFile *f = new TFile(fFileName3D.c_str());
  TIter keys(f->GetListOfKeys());
  TKey *key = NULL;
  while ((key = (TKey *)keys()))
    if (string("TH3F").compare(key->GetClassName()) == 0 || string("TH3D").compare(key->GetClassName()) == 0)
    {
      string name(key->GetName());
      size_t pos = name.find("HistoCut");
      if (pos == string::npos)
        pos = 0;
      else
        pos += 8; // length of histocut
      if (name.find("<", pos) != string::npos)
      {
        cerr << "The histograms in input are suppose to imply always > sign" << endl;
        return; //original asserted here
      }
      size_t gt = name.find(">");
      pos = (gt != string::npos)?gt+1:pos;
      float num = atof(name.c_str()+pos);
      histos3D[num] = (TH3 *)f->Get(key->GetName());
      binning.push_back(num);
    }
  sort(binning.begin(), binning.end());
  if (fOptions.find("verbose") != string::npos)
  {
    for (size_t n = 0; n < binning.size(); ++n)
      cout << binning[n] << " ";
    cout << endl;
  }

  TH3 *hist = histos3D.begin()->second;
  string nameX(hist->GetXaxis()->GetTitle()),
         nameY(hist->GetYaxis()->GetTitle()),
         nameZ(hist->GetZaxis()->GetTitle());


  //###########################################################
  //##### I save in TH1 Format!!! 
  //###########################################################
  size_t pos = fFileName3D.find(".root");
  string filename(fFileName3D, 0, pos);
  filename += "TH1s.root";
  TFile *output = new TFile(filename.c_str(), "RECREATE");

  hist->SetName("h3D_example");
  hist->Write();

  for (int ix = 1; ix < hist->GetXaxis()->GetNbins()+1; ++ix)
    for (int iy = 1; iy <  hist->GetYaxis()->GetNbins()+1; ++iy)
      for (int iz = 1; iz < hist->GetZaxis()->GetNbins()+1; ++iz)
      {
        double lowX  = hist->GetXaxis()->GetBinLowEdge(ix),
               lowY  = hist->GetYaxis()->GetBinLowEdge(iy),
               lowZ  = hist->GetZaxis()->GetBinLowEdge(iz),
               highX = hist->GetXaxis()->GetBinUpEdge(ix),
               highY = hist->GetYaxis()->GetBinUpEdge(iy),
               highZ = hist->GetZaxis()->GetBinUpEdge(iz);

        stringstream titleHist, nameHist;
        titleHist.setf(ios::fixed, ios::floatfield);
        titleHist.precision(1);
        titleHist << lowX << "< " << nameX << " < " << highX << ", "
                  << lowY << "< " << nameY << " < " << highY << ", "
                  << lowZ << "< " << nameZ << " < " << highZ;

        nameHist << "h" << hist->GetBin(ix, iy, iz);
        TH1F *h1 = new TH1F(nameHist.str().c_str(), titleHist.str().c_str(), binning.size(), &binning.front());

        for (size_t ibin = 0; ibin < binning.size(); ++ibin)
        {
          double prob = 0, err = 0;
          if (ibin+1 < binning.size())
          {
            TH3 *hthis = histos3D[binning[ibin]],
                *hnext = histos3D[binning[ibin+1]];
            //could in principle speed this up as we're getting each hist twice

            float val1 = hthis->GetBinContent(ix, iy, iz),
                  val2 = hnext->GetBinContent(ix, iy, iz),
                  err1 = hthis->GetBinError(ix, iy, iz),
                  err2 = hnext->GetBinError(ix, iy, iz);
            prob = abs(val2-val1);

            if (poisson_error)
            {
              double N = CalcN(err1, val1);
              err = N?sqrt(prob*(1-prob)/N):0;
            }
            else
              err = sqrt(err1*err1+err2*err2);
          }
          else
          {
            TH3 *hthis = histos3D[binning[ibin]];
            float val1 = hthis->GetBinContent(ix, iy, iz),
                  val2 = 0.0;
            prob = fabs(val2-val1);
            err  = hthis->GetBinError(ix, iy, iz);
            if (poisson_error)
            {
              double N = CalcN(err, val1);
              err = N?sqrt(prob*(1-prob)/N):0;
            }                            
          }
          h1->SetBinContent(ibin+1, prob);
          h1->SetBinError(ibin+1, err);
        }
        h1->Write();
        delete h1;
      }
  delete output;
  for (map<float,TH3*>::iterator it = histos3D.begin(); it != histos3D.end(); ++it)
    delete it->second;
  delete f;
}
