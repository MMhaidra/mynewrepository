#ifndef READ_EFF_TABLES_H
#define READ_EFF_TABLES_H

#include <string>
#include <vector>
#include <map>
#include <TRandom3.h>

class TH1;
class TH1F;
class TH3;
class TFile;

class DLLclass
{
  protected:
    std::string fWhichDLL,
                fMag,
                fParticle,
                fErrorType,
                fOptions,
                fFileName1D,
                fFileName3D,
                fhFluctuation;
    bool fSys_n,
         fSys_p,
         fSys_e;
    double fSys_level;
    TRandom3 fRandom;
    TFile *fFile1D,
          *fFile3D;
    std::map<int, TH1*> fTH1histos;
    std::map<float, TH3*> fTH3histos;
    TH3 *fTH1histoAux;
  public:
    DLLclass(const std::string &Mag="Up",
             const std::string &Particle="Pion",
             const std::string &whichDLL="DLLK", 
             const std::string &options = "",
             const std::string &tablepath="/vols/lhcbdisk03/ashires/EvtEffData/PIDEffTables_v17/");
    ~DLLclass();
    void setSystematic(bool _sys_ntracks, bool _sys_p, bool _sys_e, double _syslevel = 0);
    void FillHistos1D();
    void FillHistos3D();
    void Initialize();
    double CalcN(double sigma, double epsilon);
    void PrintInstructions();
    int FindBin3D(TH3 *h, double x, double y, double z);
    std::vector<double> GetOrderXYZ(TH3 *h, double p, double eta, double ntrack);
    std::vector<double> ComputeEff(double DLLK, double P, double ETA, double nTrack, bool eff = true);
    TH1F *GetDLLhisto(double P, double ETA, double nTrack);
    int AdjustBin3D(TH3 *h, int ibin, const std::vector<double> &xyz, const std::vector<double> &adjxyz);
    void ProduceTH1histos(bool poisson_error);

};

#endif
