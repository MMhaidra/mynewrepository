#! /usr/bin/env python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

btopiff = pd.read_hdf("btopi-ff.hdf5", '/main run/chain' )
print btopiff
