eos-scan-mc \
    --kinematics s_min 1 --kinematics s_max 6 \
    --observable "B->Pill::BR@LargeRecoil,l=mu" 1.E-9 4.5E-9 8.0E-9 \
    --global-option form-factors BCL2008 \
    --scan "B->pi::f_+(0)@BCL2008"     0.0      2.00    --prior flat \
    --seed 1234 \
    --parallel 1\
    --prerun-chains-per-partition 4 \
    --prerun-min 10 \
    --prerun-max 20 \
    --prerun-update 5 \
    --proposal "MultivariateGaussian" \
    --scale-reduction 1 \
    --store-prerun \
    --chunk-size 5 \
    --chunks 2 \
    --output btopi-ff.hdf5

    #--constraint "B->pi::f_+@IKMvD-2014" \
    #--scan "B->pi::f_T(0)@BCL2008"     0.0      2.00    --prior flat \
#    --debug \
#    --scan "B->Pill::BR@BCL2008"    0.0     1.0E-7     --prior flat \
#    --scan "B->pi::b_+^1@BCL2008"    -20.0     +20.0    --prior flat \
#    --scan "B->pi::b_+^2@BCL2008"    -20.0     +20.0    --prior flat \

