
#include <vector> 
#include <cmath>
#include <cassert>
#include <iostream>

#include "Minuit2/FCNBase.h"

#include "Minuit2/FunctionMinimum.h"
#include "Minuit2/MnUserParameterState.h"
#include "Minuit2/MnUserCovariance.h"
#include "Minuit2/MnMigrad.h"
#include "Minuit2/MnMinos.h"

#include "Minuit2/MnPrint.h"

#include "TGraphAsymmErrors.h"
#include "TAxis.h"
#include "TVectorD.h"
#include "TMatrixDSym.h"



class FormFactor  : public ROOT::Minuit2::FCNBase {
    
public:
    
    struct DataPoint {
        
        DataPoint() :
            qsq_( 0. ), val_(0), low_( 1.), upp_( 1. )  {} ;
        
        DataPoint( const DataPoint& other ) :
            qsq_( other.qsq_) , val_( other.val_ ), low_( other.low_ ), upp_( other.upp_ ) {} ;
        
        DataPoint( const double qsq, const double val, const double err ) :
            qsq_( qsq ), val_( val ) , low_( err ), upp_( err ) {} ;
        
        DataPoint( const double qsq, const double val, const double low, const double upp ) :
        qsq_( qsq ), val_( val ) , low_( low ), upp_( upp ) {} ;
        
        
        double qsq_;
        double val_;
        double low_;
        double upp_;
    };
    
    FormFactor() ;
    
    virtual ~FormFactor();
    
    void add( const double qsq, const double val, const double err ) ;
    
    void add( const double qsq, const double val, const double low, const double upp  ) ;
    
    double operator()( const std::vector<double>& par ) const ;
    
    virtual double Up() const{ return def_; }
    
    void setErrDef( const double def ) { def_ = def; }
    
    void plot() const ;
    
    void plot( const ROOT::Minuit2::FunctionMinimum& min ) const ;
    
private:
    double function( const double qsq,  const std::vector<double>& par  ) const ;
    
    std::vector<DataPoint> data_;
    
    double def_ ;
};

FormFactor::FormFactor() : def_( 1. ) {} ;

FormFactor::~FormFactor() {
    data_.clear();
}

void FormFactor::plot() const  {
    TGraphAsymmErrors* graph = new TGraphAsymmErrors();
    
    std::vector< DataPoint >::const_iterator it;
    
    for ( it = data_.begin(); it != data_.end(); ++it ){
        int ipoint = graph->GetN();
        
        graph->SetPoint( ipoint, it->qsq_ , it->val_ );
        graph->SetPointError( ipoint, 0, 0, it->low_, it->upp_ );
    }
    
    graph->GetXaxis()->SetTitle( "f_{+}(#it{q}^{2})");
    graph->Draw("AP");
    
    return;
}


void FormFactor::plot( const ROOT::Minuit2::FunctionMinimum& min ) const  {
    TGraphAsymmErrors* graph_data = new TGraphAsymmErrors();
    
    std::vector< DataPoint >::const_iterator it;
    
    for ( it = data_.begin(); it != data_.end(); ++it ){
        int ipoint = graph_data->GetN();
        
        graph_data->SetPoint( ipoint, it->qsq_ , it->val_ );
        graph_data->SetPointError( ipoint, 0, 0, it->low_, it->upp_ );
    }
    
    graph_data->GetXaxis()->SetTitle( "f_{+}(#it{q}^{2})");
    graph_data->Draw("AP");

    TGraphAsymmErrors* graph_model = new TGraphAsymmErrors() ;
    double qsq = 0;

    std::vector<double> val = min.UserParameters().Params();
    const unsigned int npar = val.size();
    
    std::vector<double> tmp(npar,0);
    
    const ROOT::Minuit2::MnUserCovariance& cov = min.UserCovariance();
    
    TVectorD    fvec( npar );
    TMatrixDSym cmtx( npar );
    
    for ( unsigned int i =0 ; i < npar; ++i ){
        for ( unsigned int j =0 ; j < npar; ++j ){
            cmtx(i,j) = cov(i,j);
        }
    }
    
    while ( qsq < 25 ){
        int ipoint = graph_model->GetN();
        
        double fnval = function( qsq, val );
        
        for ( unsigned int i = 0; i < npar; ++i ){
            for ( unsigned int j = 0; j < npar; ++j ){
                tmp[j] = val[j];
            }
            tmp[i] = val[i] + std::sqrt( cov(i,i) );
            double fupp = function( qsq, tmp );
            
            tmp[i] = val[i] - std::sqrt( cov(i,i) );
            double flow = function( qsq, tmp );
            
            fvec(i) = (fupp - flow)/(2.*std::sqrt( cov(i,i) ) );
        }
        
        double fnerr = std::sqrt(fvec*(cmtx*fvec));
        
        graph_model->SetPoint( ipoint, qsq, fnval );
        
        graph_model->SetPointError( ipoint, 0.05, 0.05, fnerr, fnerr );
        
        qsq += 0.1;
    }
    
    graph_model->SetLineColor( kGreen-9 );
    graph_model->SetFillColor( kGreen-9 );
    graph_model->SetLineColor( kGreen+2 );
    
    graph_model->Draw("3");
    graph_model->Draw("L");
    
    graph_data->Draw("P+");
    
    return;
}



void FormFactor::add( const double qsq, const double val, const double err ){
    data_.push_back( DataPoint( qsq, val, err ) );
}

void FormFactor::add( const double qsq, const double val, const double low, const double upp ){
    data_.push_back( DataPoint( qsq, val, low, upp ) );
}

double FormFactor::operator()(const std::vector<double>& par) const {
    std::vector< DataPoint >::const_iterator it;
    
    double fn = 0;
    
    for ( it = data_.begin(); it != data_.end(); ++it ){
        
        double fval = function( it->qsq_, par );
        
        if ( fval < it->val_ ){
            fn += std::pow( (it->val_ - fval )/it->low_ , 2 );
        }
        else {
            fn += std::pow( (it->val_ - fval )/it->upp_ , 2 );

        }
    }
    
    return fn;
}


double FormFactor::function( const double qsq,
                             const std::vector<double>& par ) const {
    static const double mBstar = 5.366;
    static const double mB     = 5.279;
    static const double mK     = 0.494;
    
    assert( par.size() == 2 );
    
    double tp = std::pow( mB + mK , 2 );
    double tm = std::pow( mB - mK , 2 );
    double tz = tp - std::sqrt( tp*(tp - tm) );

    double zv = (std::sqrt(tp - qsq) - std::sqrt(tp - tz))/(std::sqrt(tp - qsq) + std::sqrt(tp - tz));
    double zz = (std::sqrt(tp) - std::sqrt(tp - tz))/(std::sqrt(tp) + std::sqrt(tp - tz));
    
    double shape = 1. + par[1]*( zv - zz + 0.5*( zv*zv - zz*zz ) );
    
    return par[0]*shape/( 1. - qsq/std::pow(mBstar,2) );
}


void fitFormFactors() {
    ROOT::Minuit2::MnUserParameters par;
    
    par.Add ( "f0" ,  0.2 , 0.1,   0.0,  1.0 );
    par.Add ( "b1" , -1.0 , 0.1, -10.0, 10.0 );
    
    FormFactor ff;
    
    ff.add( 13.0, 0.90, 0.09 ) ;
    ff.add( 14.5, 1.04, 0.09 ) ;
    ff.add( 15.9, 1.21, 0.11 ) ;
    ff.add( 17.4, 1.45, 0.13 ) ;
    ff.add( 18.8, 1.75, 0.18 ) ;
    ff.add( 20.3, 2.19, 0.22 ) ;
    
    ff.add( 0., 0.34, 0.02, 0.05 );
    
    ROOT::Minuit2::MnMigrad migrad( ff, par );
    ROOT::Minuit2::MnPrint::SetLevel(3);
    
    const ROOT::Minuit2::FunctionMinimum min = migrad();
    
    std::vector<double> val = min.UserParameters().Params();
    std::vector<double> err = min.UserParameters().Errors();
    
    std::vector< std::pair<double,double> > minoserr;
    
    ROOT::Minuit2::MnMinos minos( ff, min );

    
    for ( unsigned int i = 0 ; i < val.size(); ++i ){
        minoserr.push_back( std::make_pair<double,double>( minos.Lower( i ), minos.Upper( i ) ) );
    }
    
    std::cout << std::endl;
    
    for ( unsigned int i = 0 ; i < val.size(); ++i ){
        std::cout << " --- Observable " << par.Parameter(i).Name() << " : Value = " << val[i] << " +- " << err[i] << std::endl;
        std::cout << "     Minos errors [ " << minoserr[i].first  << " , " << minoserr[i].second << " ] " << std::endl;
    }
    std::cout << std::endl;

    
    
    ff.plot( min );
    
    return ;
}

