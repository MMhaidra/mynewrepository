import ROOT
import math

from ROOT import TFile, TTree, TH1F, TLine, TCanvas

from lhcbStyle import setLHCbStyle
setLHCbStyle()

from ROOT import gStyle
gStyle.SetOptStat(0)

decoration= [] 

def printCanvases( typespecifier = '.pdf' ):
    '''
    Print all canvases
    '''
   
    from ROOT import gROOT
    for canvas in gROOT.GetListOfCanvases():
        canname = canvas.GetName()
        canname = canname.replace('can_','')
        canvas.SaveAs( canname + typespecifier )
    return

def interval( hist, level = 0.68 ):
    '''
    Get interval
    '''
    mid = hist.GetMaximumBin()
    low = mid
    upp = mid
    
    integral = hist.Integral()
    sum      = hist.Integral() - hist.GetBinContent(mid)

    while ( sum > ( 1. - level )*integral ):
        lowval = -1
        uppval = -1

        if ( low > 1 ):
            lowval = hist.GetBinContent( low - 1 )
        if ( upp < hist.GetNbinsX()  ):
            uppval = hist.GetBinContent( upp + 1 )

        if ( lowval < 0 and uppval < 0 ):
            break

        if ( uppval > lowval ):
            upp += 1
            sum -= uppval
        else:
            low -= 1
            sum -= lowval

    return ( low, mid, upp )

def Vtd( ttree, data ):
    '''
    Sample data to get Vtd
    '''
    from ROOT import TRandom3
    rndm = TRandom3(1001)

    global decoration 

    hist_Vtd_low = TH1F('hist_Vtd_low','',100,0,0.01)
    hist_Vtd_upp = TH1F('hist_Vtd_upp','',100,0,0.01)
    hist_Vtd_com = TH1F('hist_Vtd_com','',100,0,0.01)
    
    for i in range( 0, ttree.GetEntries() ):
        ttree.GetEntry( i )

        data_low = rndm.Gaus( data[0][0], data[0][1] )
        data_upp = rndm.Gaus( data[1][0], data[1][1] )

        data_sys = rndm.Gaus( 0, 1. )

        data_low = (data_low + data[0][2]*data_sys)*(data[0][4] - data[0][3])
        data_upp = (data_upp + data[1][2]*data_sys)*(data[1][4] - data[1][3])
        
        low = 1e8*ttree.BFLPI/(ttree.Vtd*ttree.Vtd)
        upp = 1e8*ttree.BFHPI/(ttree.Vtd*ttree.Vtd)
        
        hist_Vtd_upp.Fill( math.sqrt(data_upp/upp ) )
        hist_Vtd_low.Fill( math.sqrt(data_low/low ) )
        hist_Vtd_com.Fill( math.sqrt((data_low+data_upp)/(low+upp)) )
        
    can_Vtd = TCanvas('can_Vtd','',1200,400)
    can_Vtd.Divide(3)

    can_Vtd.cd(1)
    hist_Vtd_low.Draw()
    hist_Vtd_low.SetXTitle('|V_{td}| low #it{q}^{2}')
    
    can_Vtd.cd(2)
    hist_Vtd_upp.Draw()
    hist_Vtd_upp.SetXTitle('|V_{td}| high #it{q}^{2}')

    can_Vtd.cd(3)
    hist_Vtd_com.Draw()
    hist_Vtd_com.SetXTitle('|V_{td}| combined')

    (lowbin, midbin, uppbin) =  interval(hist_Vtd_com)

    val = hist_Vtd_com.GetBinCenter( midbin )
    
    print '|Vtd| = %.4f^{+%.4f}_{%.4f}' % ( val , hist_Vtd_com.GetXaxis().GetBinUpEdge(uppbin) - val, hist_Vtd_com.GetXaxis().GetBinLowEdge(lowbin) - val )
    
    decoration += [ can_Vtd, hist_Vtd_low,  hist_Vtd_upp,  hist_Vtd_com ]
    return 



def draw( hist, data = None ):
    global decoration

    histfill = hist.Clone( hist.GetName() + '_fill' )

    (low, mid, upp) = interval( hist )

    for i in range(1 , hist.GetNbinsX() + 1 ):
        if ( i < low or i > upp ):
            histfill.SetBinContent(i,0)

    max = 1.2*hist.GetBinContent( mid )
    hist.SetMaximum( max )
    hist.SetMinimum( 0 ) 
    
    hist.Draw() 
    histfill.SetFillColor( ROOT.kBlue - 10 )
    histfill.Draw("SAME")

    if data:
        err = math.sqrt( data[1]*data[1] + data[2]*data[2] )

        scale = 1.;
        
        if len(data) == 5:
            scale = (data[4] - data[3])
        
        line_low = TLine( scale*(data[0] - err), 0,
                          scale*(data[0] - err), max )
        line_upp = TLine( scale*(data[0] + err), 0,
                          scale*(data[0] + err), max )
        line_low.Draw()
        line_upp.Draw()
        decoration += [ line_low, line_upp ] 
    
    decoration += [ histfill ] 
    return 

data_pimumu_diffbranching = [
    [ 0.0884, 0.0203, 0.0021, 1. , 6.  ],
    [ 0.0483, 0.0109, 0.0011, 15., 22. ]  
    ]


data_kmumu_diffbranching = [
    [ 2.3546, 0.0826, 0.0453, 1. , 6.  ],
    [ 1.3171, 0.0487, 0.0253, 15., 22. ]  
    ]

data_ratio = [
    [ 0.038, 0.009, 0.001 ],
    [ 0.037, 0.008, 0.001 ]
    ]

tfile = TFile.Open('outfile.root')
ttree = tfile.Get('Scan')

from ROOT import gROOT

gROOT.cd()

can_branching = TCanvas('can_branching','',800,800)
can_branching.Divide(2,2)

can_branching.cd(1)

hist_pimumu_low = TH1F('hist_pimumu_low','',100,0,2)
hist_pimumu_upp = TH1F('hist_pimumu_upp','',100,0,2)
hist_pimumu_low.SetXTitle('#it{B}(#pi^{+}#mu^{+}#mu^{-}) low #it{q}^{2} [x10^{-8}]')
hist_pimumu_upp.SetXTitle('#it{B}(#pi^{+}#mu^{+}#mu^{-}) high #it{q}^{2}[x10^{-8}]')

hist_kmumu_low = TH1F('hist_kmumu_low','',100,0,40)
hist_kmumu_upp = TH1F('hist_kmumu_upp','',100,0,40)
hist_kmumu_low.SetXTitle('#it{B}(#it{K}^{+}#mu^{+}#mu^{-}) low #it{q}^{2} [x10^{-8}]')
hist_kmumu_upp.SetXTitle('#it{B}(#it{K}^{+}#mu^{+}#mu^{-}) high #it{q}^{2} [x10^{-8}]')


ttree.Draw('BFLPI*1e8 >> ' +  hist_pimumu_low.GetName() )
ttree.Draw('BFHPI*1e8 >> ' +  hist_pimumu_upp.GetName() )

ttree.Draw('BFLK*1e8 >> ' +  hist_kmumu_low.GetName() )
ttree.Draw('BFHK*1e8 >> ' +  hist_kmumu_upp.GetName() )

hist_ratio_low = TH1F('hist_ratio_low','',100,0,0.1)
hist_ratio_upp = TH1F('hist_ratio_upp','',100,0,0.1)

hist_ratio_low.SetXTitle('#it{B}(#it{K}^{+}#mu^{+}#mu^{-})/#it{B}(#pi^{+}#mu^{+}#mu^{-})')
hist_ratio_upp.SetXTitle('#it{B}(#it{K}^{+}#mu^{+}#mu^{-})/#it{B}(#pi^{+}#mu^{+}#mu^{-})')

ttree.Draw('BFLPI/BFLK >>' + hist_ratio_low.GetName())
ttree.Draw('BFHPI/BFHK >>' + hist_ratio_upp.GetName())

can_branching.cd(1)
draw( hist_pimumu_low, data_pimumu_diffbranching[0] )

can_branching.cd(2)
draw( hist_pimumu_upp, data_pimumu_diffbranching[1] ) 

can_branching.cd(3)
draw( hist_kmumu_low, data_kmumu_diffbranching[0] )

can_branching.cd(4)
draw( hist_kmumu_upp, data_kmumu_diffbranching[1] )

can_ratio = TCanvas('can_ratio','',800,400)
can_ratio.Divide(2)

can_ratio.cd(1)
draw( hist_ratio_low, data_ratio[0] )

can_ratio.cd(2)
draw( hist_ratio_upp, data_ratio[1] ) 


Vtd( ttree, data_pimumu_diffbranching )

printCanvases('.pdf')
