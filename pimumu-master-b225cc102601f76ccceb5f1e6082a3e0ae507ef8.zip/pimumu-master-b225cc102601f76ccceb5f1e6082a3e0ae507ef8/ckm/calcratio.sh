eos-evaluate --kinematics s_min 1 --kinematics s_max 6 \
   --budget FF --vary "B->pi::f_+(0)@BCL2008" --vary "B->pi::f_T(0)@BCL2008"\
    --budget CKM --vary CKM::lambda --vary CKM::A --vary CKM::rhobar --vary CKM::etabar \
    --observable "B->Pill::BR@LargeRecoil,l=mu"

eos-evaluate --kinematics s_min 1 --kinematics s_max 6 \
    --budget FF --vary "B->K::F^p(0)@KMPW2010" --vary "B->K::F^t(0)@KMPW2010"\
    --budget CKM --vary CKM::lambda --vary CKM::A --vary CKM::rhobar --vary CKM::etabar \
    --observable "B->Kll::BR@LargeRecoil,l=mu"\
    | tee kmumu.low.value.data

eos-evaluate --kinematics s_min 1 --kinematics s_max 6 \
   --budget FF --vary "B->pi::f_+(0)@BCL2008" --vary "B->pi::f_T(0)@BCL2008"\
    --vary "B->K::F^p(0)@KMPW2010" --vary "B->K::F^t(0)@KMPW2010"\
    --budget CKM --vary CKM::lambda --vary CKM::A --vary CKM::rhobar --vary CKM::etabar \
    --observable "RPiK::BR@LargeRecoil,l=mu"

eos-evaluate --kinematics s_min 15 --kinematics s_max 20 \
    --budget FF --vary "B->pi::f_+(0)@BCL2008" --vary "B->pi::f_T(0)@BCL2008"\
    --budget CKM --vary CKM::lambda --vary CKM::A --vary CKM::rhobar --vary CKM::etabar \
    --observable "B->Pill::BR@LowRecoil,l=mu"

eos-evaluate --kinematics s_min 15 --kinematics s_max 20 \
    --budget FF --vary "B->K::F^p(0)@KMPW2010" --vary "B->K::F^t(0)@KMPW2010"\
    --budget CKM --vary CKM::lambda --vary CKM::A --vary CKM::rhobar --vary CKM::etabar\
    --observable "B->Kll::BR@LowRecoil,l=mu"\
    | tee kmumu.low.value.data

eos-evaluate --kinematics s_min 15 --kinematics s_max 20 \
   --budget FF  \
    --vary "B->pi::f_+(0)@BCL2008" --vary "B->pi::f_T(0)@BCL2008"\
    --vary "B->K::F^p(0)@KMPW2010" --vary "B->K::F^t(0)@KMPW2010"\
    --budget CKM --vary CKM::lambda --vary CKM::A --vary CKM::rhobar --vary CKM::etabar\
    --observable "RPiK::BR@LowRecoil,l=mu"
