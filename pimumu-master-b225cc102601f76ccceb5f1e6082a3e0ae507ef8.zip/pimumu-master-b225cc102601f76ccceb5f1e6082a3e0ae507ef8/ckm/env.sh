lhcbSetup
setuproot
export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/usr/local/pmclib-1.01/lib:$LD_LIBRARY_PATH
