#! /usr/bin/env python

#import ROOT
#ROT.gROOT.SetBatch(True)
#from ROOT import RooRealVar, RooFormulaVar

"""
pilow = ufloat("pimumu_low", "pimumu_low", 4.1377E-9)
pilow.setAsymError(1.17E-9, 1.365E-9)
pihigh = ufloat("pimumu_high", "pimumu_high", 1.5569E-9)
pihigh.setAsymError(4.422E-10, 5.159E-10)

klow = ufloat("kmumu_low", "kmumu_low", 1.67169E-7)
klow.setAsymError(1.905E-8, 5.267E-8)
khigh = ufloat("kmumu_high", "kmumu_high", 7.265E-8)
khigh.setAsymError(8.296E-9, 2.293E-9)

rbrlow = ufloat("rbrlow", "rbrlow", 0.02617)
rbrlow.setAsymError(0.00973, 0.00930)
rbrhigh = ufloat("rbrhigh", "rbrhigh", 0.02143)
rbrhigh.setAsymError(0.00796, 0.00761)



vtdvts = ufloat("vtdvts", "vtdvts", 0.216)
vtdvts.setError(0.012)
vtd = ufloat("vtd", "vtd", 8.4E-3)
vtd.setError(0.6E-3)
vts = ufloat("vts", "vts", 40.0E-3)
vts.setError(2.7E-3)
"""

#from value import ufloat
import uncertainties
from uncertainties import ufloat
pilow = ufloat(4.1377E-9, (1.17E-9+ 1.365E-9)*0.5, "theo")
pihigh = ufloat(1.95689E-9, (5.6618E-10+ 6.57739E-10)*0.5, "theo")

klow = ufloat(1.67169E-7, (1.905E-8+ 5.267E-8)*0.5, "theo")
khigh = ufloat(7.265E-8, (9.87255E-9 * 2)*0.5, "theo")

rbrlow = ufloat(0.02617, (0.00973 + 0.00930)*0.5, "theo")
rbrhigh = ufloat(0.0235697, (0.008826+ 0.0088492)*0.5, "theo")

vtdvts = ufloat(0.216, 0.00)
vtd = ufloat(8.4E-3, 0.0E-3)
vts = ufloat(40.0E-3, 0.0E-3)


if __name__ == '__main__':
    #pimumu
    """
    from ROOT import RooArgList, RooFormulaVar
    rflow  = RooFormulaVar("rflow", "@0/(@1^2)", RooArgList(rbrlow, vtdvts))
    rfhigh  = RooFormulaVar("rfhigh", "@0/(@1^2)", RooArgList(rbrhigh, vtdvts))
    fpilow  = RooFormulaVar("fpilow", "@0/(@1^2)", RooArgList(pilow, vtd))
    fpihigh  = RooFormulaVar("fpihigh", "@0/(@1^2)", RooArgList(pihigh, vtd))
    fklow  = RooFormulaVar("fklow", "@0/(@1^2)", RooArgList(klow, vts))
    fkhigh  = RooFormulaVar("fkhigh", "@0/(@1^2)", RooArgList(khigh, vts))
    print "ratio"
    rflow.Print()
    rfhigh.Print()
    print "pimumu"
    fpilow.Print()
    fpihigh.Print()
    print "kmumu"
    fklow.Print()
    fkhigh.Print()
    """
    rflow = rbrlow / vtdvts / vtdvts
    rfhigh = rbrhigh / vtdvts / vtdvts
    fpilow = pilow / vtd / vtd
    fpihigh = pihigh / vtd / vtd
    fklow = klow / vts / vts
    fkhigh = khigh / vts / vts
    print rflow #, rflow.f()
    print rfhigh# , rfhigh.f()
    print fpilow #, fpilow.f()
    print fpihigh #, fpihigh.f()
    print fklow #, fklow.f()
    print fkhigh #, fkhigh.f()

    #get results!!
    from pandas import read_csv

    #print cendf
    #bins 10 and 11 are low and high

    scale = 1E-8

    from numpy import sqrt

    def ckmval(value, factor, scale=1):
        #print value, factor
        resval = (value / factor)**0.5 * scale
        #print resval.error
        statval = 0
        systval = 0
        theoval = 0
        cenval = resval.n
        for errname, errval in resval.error_components().iteritems():
            if errname.tag == 'stat':
                statval = errval
            if errname.tag == 'syst':
                systval = errval
            if errname.tag == 'theo':
                theoval = errval

        print "%.3g \\pm %.3g (\\stat) \\pm %.3g (\\syst) %.3g (\\texttt{theo})" \
                % (cenval, statval, systval, theoval)
        val = { "cen":cenval, "stat":statval, "syst":systval, "theo":theoval } 
        return val

    #closure
    #print reslow, reshigh
    #print "pion results"
    #ckmval(pilow, 0, fpilow)
    #ckmval(pihigh, 0, fpihigh)
    #print "kaon results"
    #ckmval(klow, 0, fklow)
    #ckmval(khigh, 0, fkhigh)
    #print "ratio results"
    ckmval(rbrlow, rflow)
    ckmval(rbrhigh, rfhigh)
    #exit() 


    cendf = read_csv("../python/results_with_sys_tot.data", sep='\t', index_col=0)

    #print reslow, reshigh
    print "pion results"
    pival = ufloat(cendf['piv'][10] , cendf['pie'][10] , "stat") * scale
    pival += ufloat(0, cendf['pisysup'][10], "syst") * scale
    pival = ufloat(cendf['piv'][11], cendf['pie'][11] , "stat") * scale
    pival += ufloat(0, cendf['pisysup'][11] , "syst") * scale

    vtdvallow = ckmval(pival, fpilow, 1E3)
    vtdvalhigh = ckmval(pival, fpihigh, 1E3)

    print "kaon results"
    kval = ufloat(cendf['kv'][10] , cendf['ke'][10] , "stat") * scale
    kval += ufloat(0, cendf['ksysup'][10], "syst") * scale
    kval = ufloat(cendf['kv'][11], cendf['ke'][11] , "stat") * scale
    kval += ufloat(0, cendf['ksysup'][11] , "syst") * scale

    vtsvallow = ckmval(kval, fklow, 1E3)
    vtsvalhigh = ckmval(kval, fkhigh, 1E3)

    print "ratio results"

    cenvallow = ufloat(cendf['rv'][10], cendf['re'][10], "stat")
    cenvalhigh = ufloat(cendf['rv'][11], cendf['re'][11], "stat")
    cenvallow += ufloat(0.0, cendf['rsysup'][10], "syst")
    cenvalhigh += ufloat(0.0, cendf['rsysup'][11], "syst")

    rvallow = ckmval(cenvallow, rflow)
    rvalhigh = ckmval(cenvalhigh, rfhigh)


    #write tex files
    line1 = "$|\\Vtd/\\Vts|$ & $"
    line1 += "%.3f \\pm %.3f \\pm %.3f \\pm %.3f $&$ " % (rvallow["cen"], rvallow["stat"], \
                                          rvallow["syst"], rvallow["theo"])
    line1 += "%.3f \\pm %.3f \\pm %.3f \\pm %.3f $\\\\\n" % (rvalhigh["cen"], rvalhigh["stat"], \
                                          rvalhigh["syst"], rvalhigh["theo"])

    line2 = "$|\\Vtd|$ & $"
    line2 += "%.3f \\pm %.3f \\pm %.3f \\pm %.3f $&$ " % (vtdvallow["cen"], vtdvallow["stat"], \
                                          vtdvallow["syst"], vtdvallow["theo"])
    line2 += "%.3f \\pm %.3f \\pm %.3f \\pm %.3f $\\\\\n" % (vtdvalhigh["cen"], vtdvalhigh["stat"], \
                                          vtdvalhigh["syst"], vtdvalhigh["theo"])

    line3 = "$|\\Vts|$ & $"
    line3 += "%.3f \\pm %.3f \\pm %.3f \\pm %.3f $&$ " % (vtsvallow["cen"], vtsvallow["stat"], \
                                          vtsvallow["syst"], vtsvallow["theo"])
    line3 += "%.3f \\pm %.3f \\pm %.3f \\pm %.3f $\\\\\n" % (vtsvalhigh["cen"], vtsvalhigh["stat"], \
                                          vtsvalhigh["syst"], vtsvalhigh["theo"])

    cf = open("ckmresults.tex", "w")
    cf.write(line1)
    cf.write(line2)
    cf.write(line3)
    cf.close()
