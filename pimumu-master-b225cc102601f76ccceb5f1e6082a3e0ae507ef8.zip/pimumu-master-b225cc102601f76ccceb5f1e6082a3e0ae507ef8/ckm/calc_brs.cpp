#include <iostream>
#include "boost/program_options.hpp"
namespace po = boost::program_options ;
#include "boost/date_time/posix_time/posix_time.hpp"
namespace dt = boost::posix_time ;

#include <eos/observable.hh>
#include "eos/rare-b-decays/exclusive-b-to-s-dilepton-large-recoil.hh"
#include "eos/rare-b-decays/exclusive-b-to-s-dilepton-low-recoil.hh"
#include "eos/rare-b-decays/exclusive-B-to-K-dilepton.hh"
#include "eos/rare-b-decays/exclusive-b-to-d-dilepton-large-recoil.hh"
#include "eos/rare-b-decays/exclusive-b-to-d-dilepton-low-recoil.hh"

//root ufnctions
#include "TF1.h"
#include "RooDataSet.h"
#include "RooArgSet.h"
#include "RooRealVar.h"
#include "RooGaussian.h"
#include "RooMsgService.h"
#include "TCanvas.h"
#include "RooPlot.h"
#include "lhcbStyle.h"

struct config {
    bool debug ;
} ; 

using namespace eos; 

int main(int argc, char *argv[])
{
    dt::ptime starttime = dt::second_clock::local_time();
    std::cout << "calculating BRs" << std::endl ;
    RooMsgService::instance().setGlobalKillBelow(RooFit::ERROR);
    RooMsgService::instance().setSilentMode(true);
    lhcb::lhcbStyle() ;
    //
    config c ; 
    //
    po::options_description desc("Allowed options") ;
    desc.add_options()
        ("help","help!")
        ("debug,d",po::value<bool>(&c.debug)->default_value(false)->zero_tokens(),"debug case")
        ;

    // actually do the parsing
    po::variables_map vm ;
    po::store(po::parse_command_line( argc, argv, desc) , vm ) ;
    po::notify(  vm ) ;

    // show help and exit
    if ( (vm.count("help"))) {
        std::cout << desc << "\n";
        return 1;
    }

    //setup up parameiters
    //
    //

    Parameters p = Parameters::Defaults();
    p["life_time::B_d"] = 1.530e-12;
    p["c1"] = -0.32300000;
    p["c2"] = +1.00931000;
    p["c3"] = -0.00522869;
    p["c4"] = -0.08794730;
    p["c5"] = +0.00037476;
    p["c6"] = +0.00105859;
    p["Abs{c7}"] = 0.331;
    p["Arg{c7}"] = M_PI;
    p["c8"] = -0.181;
    p["Abs{c9}"] = +4.27;
    p["Arg{c9}"] = 0.0;
    p["Abs{c10}"] = +4.173;
    p["Arg{c10}"] = M_PI;
    //PDG 2008 CKM parameters
    p["CKM::A"] = 0.814;
    p["CKM::lambda"] = 0.2257;
    p["CKM::rhobar"] = 0.135;
    p["CKM::etabar"] = 0.349;
    // BHvD2010 parameters
    p["decay-constant::B_d"] = 0.200;
    // Kaon mass
    p["mass::K^*_d"] = 0.896;
    // B mass
    p["mass::B_d"] = 5.2795;
    // b quark mass
    p["mass::b(MSbar)"] = 4.2;
    p["mass::W"] = 80.398;
    p["mass::tau"] = 1.77684;
    //lepton masses??
    p["mass::mu"] = 0.105;
    p["mass::e"] = 0.000531;

    Options oo;
    oo.set("model", "WilsonScan");
    oo.set("form-factors", "KMPW2010");
    oo.set("q", "u");
    Options op;
    op.set("model", "WilsonScan");
    op.set("form-factors", "BCL2008");
    op.set("q", "u");

    //muon
    BToKDilepton<LargeRecoil> bukmmlarge( p, oo ) ;
    BToKDilepton<LowRecoil> bukmmlow( p, oo ) ;
    BToPiDilepton<LargeRecoil> bupimmlarge( p, op ) ;
    BToPiDilepton<LowRecoil> bupimmlow( p, op ) ;
    //electron

    double factor = 1E7 ;
    //scan
    //
    double kmm_lowbr = bukmmlarge.integrated_branching_ratio(1.0,6.0) * factor ; 
    double kmm_highbr = bukmmlow.integrated_branching_ratio(15.0,20.0) * factor ; 
    double pimm_lowbr = bupimmlarge.integrated_branching_ratio(1.0,6.0) * factor ; 
    double pimm_highbr = bupimmlow.integrated_branching_ratio(15.0,20.0) * factor ; 

    std::cout << "Kmumu: " << kmm_lowbr << '\t' << kmm_highbr << std::endl ;
    std::cout << "Pimumu: " << pimm_lowbr << '\t' << pimm_highbr << std::endl ;


    //vary??
    TF1 * fwc7 = new TF1("wc7", "gaus", -3, 3);
    fwc7->SetParameter(0,1) ;
    fwc7->SetParameter(1, 0.331); //mean
    TF1 * fwc9 = new TF1("wc9", "gaus", 0, 8.);
    fwc9->SetParameter(0,1) ;
    fwc9->SetParameter(1, 4.27); //mean
    TF1 * fwc10 = new TF1("wc10", "gaus", -8, 0);
    fwc10->SetParameter(0,1) ;
    fwc10->SetParameter(1, -4.173); //mean

    //errors
    fwc7->SetParameter(2, 0.3);
    fwc9->SetParameter(2, 0.5);
    fwc10->SetParameter(2, 0.5);

    //dataset
    RooRealVar pimumu("pimumu", "pimumu", 0.0, 0.1);
    RooRealVar kmumu("kmumu", "kmumu", 0.0, 10.0);
    RooRealVar ratio("ratio", "ratio", 0.02, 0.03);
    RooDataSet samples_low("samples_low", "", RooArgSet(ratio) ) ; 
    RooDataSet samples_high("samples_high", "", RooArgSet(ratio) ) ; 
    RooDataSet pimumu_low("pimumu_low", "", RooArgSet(pimumu) ) ; 
    RooDataSet pimumu_high("pimumu_high", "", RooArgSet(pimumu) ) ; 
    RooDataSet kmumu_low("kmumu_low", "", RooArgSet(kmumu) ) ; 
    RooDataSet kmumu_high("kmumu_high", "", RooArgSet(kmumu) ) ; 
    //sample population space
    const int nsamples = 10 ;
    double kl(0), pl(0), kh(0), ph(0) ; 
    for ( int i=0 ; i < nsamples; ++i )
    {
        //p["Abs{c7}"] = fwc7->GetRandom() ;
        //p["Abs{c9}"] = fwc9->GetRandom() ;
        //p["Abs{c10}"] = fwc10->GetRandom() ;
        //std::cout << p["Abs{c7}"] << '\t' << p["Abs{c9}"] << '\t' << p["Abs{c10}"] << std::endl ;
        kl = bukmmlarge.integrated_branching_ratio(1.0,6.0) * factor ; 
        kh = bukmmlow.integrated_branching_ratio(15.0,20.0) * factor ; 
        pl = bupimmlarge.integrated_branching_ratio(1.0,6.0) * factor ; 
        ph = bupimmlow.integrated_branching_ratio(15.0,20.0) * factor ;
        if (i < 10) {
            std::cout << pl  << '\t' << ph << std::endl ;
            std::cout << kl << '\t' << kh << std::endl ;
            std::cout << pl / kl << '\t' << ph / kh << std::endl ;
        }
        //get ratios
        ratio.setVal( pl / kl ) ;
        samples_low.add( RooArgSet(ratio) ) ;
        ratio.setVal( ph / kh ) ;
        samples_high.add( RooArgSet(ratio) ) ;
        pimumu.setVal( pl ) ;
        pimumu_low.add( RooArgSet(pimumu) ) ;
        pimumu.setVal( ph ) ;
        pimumu_high.add( RooArgSet(pimumu) ) ;
        kmumu.setVal( kl ) ;
        kmumu_low.add( RooArgSet(kmumu) ) ;
        kmumu.setVal( kh ) ;
        kmumu_high.add( RooArgSet(kmumu) ) ;
    }

    //Gaussian function
    RooRealVar mean("rmean","", 0.02, 0.01, 0.04) ;
    RooRealVar sigma("rsigma", "", 0, 1) ;
    RooGaussian rgaus("rgaus", "", ratio, mean, sigma) ;
    RooRealVar pmean("pmean","", 0.05, 0.0, 0.1) ;
    RooRealVar psigma("psigma", "", 0, 5) ;
    RooGaussian pgaus("pgaus", "", pimumu, pmean, psigma) ;
    RooRealVar kmean("kmean","", 0.5, 0, 10) ;
    RooRealVar ksigma("ksigma", "", 0, 5) ;
    RooGaussian kgaus("kgaus", "", kmumu, kmean, ksigma) ;
    //
    rgaus.fitTo( samples_low ) ;
    std::cout << mean.getVal() << '\t' << sigma.getVal() << std::endl ;

    TCanvas * can = new TCanvas("c", "", 800, 600) ;
    can->SaveAs("ratio_wcvar.pdf[");
    RooPlot * plot = ratio.frame() ;
    samples_low.plotOn(plot) ;
    rgaus.plotOn(plot) ;
    plot->Draw();
    can->SaveAs("ratio_wcvar.pdf");
    plot = ratio.frame() ;
    rgaus.fitTo( samples_high ) ;
    std::cout << mean.getVal() << '\t' << sigma.getVal() << std::endl ;
    samples_high.plotOn(plot) ;
    rgaus.plotOn(plot) ;
    plot->Draw();
    can->SaveAs("ratio_wcvar.pdf");
    pgaus.fitTo( pimumu_low ) ;
    std::cout << pmean.getVal() << '\t' << psigma.getVal() << std::endl ;
    plot = pimumu.frame();
    pimumu_low.plotOn(plot) ;
    pgaus.plotOn(plot) ;
    plot->Draw();
    can->SaveAs("ratio_wcvar.pdf");
    pgaus.fitTo( pimumu_high ) ;
    std::cout << pmean.getVal() << '\t' << psigma.getVal() << std::endl ;
    plot = pimumu.frame();
    pimumu_high.plotOn(plot) ;
    pgaus.plotOn(plot) ;
    plot->Draw();
    can->SaveAs("ratio_wcvar.pdf");
    kgaus.fitTo( kmumu_low ) ;
    std::cout << kmean.getVal() << '\t' << ksigma.getVal() << std::endl ;
    plot = kmumu.frame();
    kmumu_low.plotOn(plot) ;
    kgaus.plotOn(plot) ;
    plot->Draw();
    can->SaveAs("ratio_wcvar.pdf");
    kgaus.fitTo( kmumu_high ) ;
    plot = kmumu.frame();
    std::cout << kmean.getVal() << '\t' << ksigma.getVal() << std::endl ;
    kmumu_high.plotOn(plot) ;
    kgaus.plotOn(plot) ;
    plot->Draw();
    can->SaveAs("ratio_wcvar.pdf");

    can->SaveAs("ratio_wcvar.pdf]");


    dt::ptime endtime  = dt::second_clock::local_time();
    dt::time_duration difftime = endtime - starttime;
    std::cout << "time  " << difftime.total_seconds() << " seconds " << std::endl ;



    return 0;
}
