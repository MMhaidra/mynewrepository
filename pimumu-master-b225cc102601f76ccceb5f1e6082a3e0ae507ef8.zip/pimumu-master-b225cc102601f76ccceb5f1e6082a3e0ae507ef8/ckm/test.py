import uncertainties
from uncertainties import ufloat

a = ufloat(1,0.1,"a")
b = ufloat(1,0.2,"b")


print (a + b).error_components()
