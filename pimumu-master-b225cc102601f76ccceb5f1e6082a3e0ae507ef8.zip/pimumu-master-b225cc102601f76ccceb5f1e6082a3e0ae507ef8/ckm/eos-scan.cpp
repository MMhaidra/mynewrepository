//  g++ eos-scan.cc --std=c++11 -I. -L./lib -leos `root-config --cflags --libs` -o eos-gen

#include <eos/observable.hh>


#include "boost/program_options.hpp"
namespace po = boost::program_options ;
#include <eos/rare-b-decays/exclusive-b-to-d-dilepton-large-recoil.hh>
#include <eos/rare-b-decays/exclusive-b-to-d-dilepton-low-recoil.hh>

#include <eos/rare-b-decays/exclusive-B-to-K-dilepton.hh>

#include "boost/date_time/posix_time/posix_time.hpp"
namespace dt = boost::posix_time ;


//#include <eos/utils/complex.hh>
//#include <eos/utils/wilson-polynomial.hh>

//#include <eos/utils/save.hh>
//#include <eos/utils/memoise.hh>

#include <array>
#include <cmath>
#include <fstream>
#include <limits>
#include <string>
#include <vector>
#include <string>
#include <iomanip>

#include <iostream>
#include <assert.h>
#include <sstream>
#include <complex>

#include "TTree.h"
#include "TFile.h"
#include "TRandom3.h"

#include "TMatrixDSym.h"
#include "TVectorD.h"
#include "TMath.h"

using namespace eos;

TRandom3* rndm = new TRandom3(4001);


void replaceWith( std::string& str, std::string strold, std::string strnew )
{
    size_t pos = str.find( strold );

    while ( pos != std::string::npos )
    {
        str.replace( pos, strold.length(), strnew );
        pos = str.find( strold );
    }
    return;
}

double bifuricated( const double par, const double low, const double upp )
{
    double val, prob;

    do 
    {
        val  = rndm->Uniform( -5.*low, 5.*upp ); 
        prob = ( val < 0 ? 
                exp( -0.5*val*val/(low*low) ) : 
                exp( -0.5*val*val/(upp*upp) ) );

    } while ( rndm->Rndm() > prob );

    return par + val;
}


void randomBCL( std::vector<double>& par ) 
{ 

    double mean[3]  = { 0.307, -1.310, -0.904 };
    double sigma[3] = { 0.020,  0.420, 0.444  };

    TMatrixDSym cov(3);
    TVectorD    vec(3);

    cov(0,0) =  1.000;  cov(0,1) =  0.503;  cov(0,2) = -0.391;
    cov(1,0) =  0.503;  cov(1,1) =  1.000;  cov(1,2) = -0.824;
    cov(2,0) = -0.391;  cov(2,1) = -0.824;  cov(2,2) =  1.000;

    for ( int i = 0; i < 3; ++i ){
        for ( int j = 0; j< 3; ++j ){
            cov(i,j) = cov(i,j)*sigma[i]*sigma[j];
        }
    }
    cov.Invert();

    do 
    {
        for ( int i = 0; i < 3; ++i ) {
            vec(i) = rndm->Uniform( -3*sigma[i] , 3*sigma[i] );
        }

    } while ( rndm->Rndm() > exp( -0.5*(vec*(cov*vec)) ) );

    for ( int i = 0; i < 3; ++i ) {
        par[i] = mean[i] + vec(i);
    }

    return ;
}

std::complex<double> evaluate_rho_eta( const double A, 
        const double lambda, 
        const double rhobar, 
        const double etabar )
{
    double A2      = std::pow( A, 2 );
    double lambda2 = std::pow( lambda, 2 ); 
    double lambda4 = std::pow( lambda, 4 ); 

    return ( std::complex<double>(rhobar, etabar)*std::sqrt( 1.0 - A2 * lambda4 ) / 
            std::sqrt( 1.0 - lambda2 ) / (1.0 - A2 * lambda4 * std::complex<double>(rhobar, etabar) ) );
}


std::complex<double> Vtd( Parameters& param )
{
    const double A      = param["CKM::A"];
    const double lambda = param["CKM::lambda"];
    const double rhobar = param["CKM::rhobar"];
    const double etabar = param["CKM::etabar"];

    std::complex<double> rho_eta = evaluate_rho_eta( A, lambda, rhobar, etabar );

    double A2 = std::pow(A,2);
    double lambda2 = std::pow(lambda,2);
    double lambda3 = std::pow(lambda,3);
    double lambda4 = std::pow(lambda,4);

    return A*lambda3*((1.0 - rho_eta) + lambda2 * rho_eta / 2.0 + lambda4 * (1.0 + 4.0 * A2) * rho_eta / 8.0);
}

std::complex<double> Vts( Parameters& param )
{
    const double A      = param["CKM::A"];
    const double lambda = param["CKM::lambda"];
    const double rhobar = param["CKM::rhobar"];
    const double etabar = param["CKM::etabar"];

    std::complex<double> rho_eta = evaluate_rho_eta( A, lambda, rhobar, etabar );

    double A2      = std::pow(A,2);
    double lambda2 = std::pow(lambda,2);
    double lambda4 = std::pow(lambda,4);
    double lambda6 = std::pow(lambda,6);

    return ( -1.0 * A * lambda2 *(1.0 - lambda2 * (1.0 - 2.0 * rho_eta) / 2.0 - 
                lambda4 / 8.0 - lambda6 * (1.0 + 8.0 * A2 * rho_eta) / 16.0) );
}

std::complex<double> Vtb( Parameters& param )
{
    const double A      = param["CKM::A"];
    const double lambda = param["CKM::lambda"];
    const double rhobar = param["CKM::rhobar"];
    const double etabar = param["CKM::etabar"];

    std::complex<double> rho_eta = evaluate_rho_eta( A, lambda, rhobar, etabar );

    double A2      = std::pow(A,2);
    double A4      = std::pow(A,4);
    double lambda4 = std::pow(lambda,4);
    double lambda6 = std::pow(lambda,6);
    double lambda8 = std::pow(lambda,8);

    double result = 1.0 - A2 * lambda4 / 2.0 - A2 * lambda6 * std::norm(rho_eta) / 2.0 - A4 * lambda8 / 8.0;

    return complex<double>(result, 0.0);
}

struct config {
    bool debug ;
    bool masses ;
    bool formfactors ;
    bool ckm ;
    bool scale;
    bool all ;
    bool lambda ;
    bool decay ;
} ; 


int main(int argc, char* argv[] )
{
    dt::ptime starttime = dt::second_clock::local_time();
    config c ;
    po::options_description desc("Allowed options") ;
    desc.add_options()
        ("help","help!")
        ("debug,d",po::value<bool>(&c.debug)->default_value(false)->zero_tokens(),"debug case")
        ("all,a",po::value<bool>(&c.all)->default_value(false)->zero_tokens(),"all variations")
        ("masses,m",po::value<bool>(&c.masses)->default_value(false)->zero_tokens(),"vary masses")
        ("formfactors,f",po::value<bool>(&c.formfactors)->default_value(false)->zero_tokens(),"vary ffs")
        ("ckm,c",po::value<bool>(&c.ckm)->default_value(false)->zero_tokens(),"vary ckms")
        ("scale,s",po::value<bool>(&c.scale)->default_value(false)->zero_tokens(),"vary scale")
        ("lambda,l",po::value<bool>(&c.scale)->default_value(false)->zero_tokens(),"vary lambda")
        ("decay,d",po::value<bool>(&c.scale)->default_value(false)->zero_tokens(),"vary decay")
        ;

    // actually do the parsing
    po::variables_map vm ;
    po::store(po::parse_command_line( argc, argv, desc) , vm ) ;
    po::notify(  vm ) ;

    if (c.all)
    {
        c.scale = true;
        c.masses = true ;
        c.formfactors = true ;
        c.ckm = true ;
    }

    Parameters param = Parameters::Defaults();

    //param["B->pi::f_+(0)@BCL2008"] =  0.304;
    //param["B->pi::b_+^1@BCL2008"]  = -1.31;
    //param["B->pi::b_+^2@BCL2008"]  = -0.904;

    //const double mu = 4.2;

    Options op_pion;
    //op_pion.set("model", "WilsonScan");
    op_pion.set("form-factors", "BCL2008");
    op_pion.set("l","mu");
    op_pion.set("q","u");

    Options  op_kaon;
    //op_kaon.set("model", "WilsonScan");
    op_kaon.set("form-factors", "KMPW2010");
    op_kaon.set("l","mu");
    op_kaon.set("q","u");

    BToPiDilepton<LargeRecoil> pimumu_loq2(param, op_pion);
    BToPiDilepton<LowRecoil>   pimumu_hiq2(param, op_pion);

    BToKDilepton<LargeRecoil>  kmumu_loq2 (param, op_kaon);
    BToKDilepton<LowRecoil>    kmumu_hiq2 (param, op_kaon);

    double BFLPI, BFHPI, BFLK, BFHK;

    TFile* outfile = new TFile("outfile2.root","RECREATE");
    TTree* outtree = new TTree("Scan","Scan");

    outtree->Branch("BFLPI",&BFLPI);
    outtree->Branch("BFHPI",&BFHPI);
    outtree->Branch("BFLK" ,&BFLK );
    outtree->Branch("BFHK" ,&BFHK );

    double magVtb, magVtd, magVts ;

    outtree->Branch("Vtd",&magVtd);
    outtree->Branch("Vts",&magVts);
    outtree->Branch("Vtb",&magVtb);

    //  TRandom3 rndm(4001);
    int nsamples = 100 ;

    std::vector<double> BCL(3,0);

    for ( int i = 0 ; i  < nsamples; ++i )
    {
        if (i%(nsamples/10)==0) { std::cout << "processed " << i << std::endl ;}

        // Vary form-factors for B --> pi
        if ( c.formfactors){
            randomBCL( BCL );
            param["B->pi::f_+(0)@BCL2008"] =  BCL[0];
            param["B->pi::b_+^1@BCL2008"]  =  BCL[1];
            param["B->pi::b_+^2@BCL2008"]  =  BCL[2];


            // Vary form-factors for B --> K 
            param["B->K::F^p(0)@KMPW2010"] = bifuricated( 0.34, 0.02, 0.05 );
            param["B->K::F^t(0)@KMPW2010"] = bifuricated( 0.39, 0.03, 0.05 );
            param["B->K::b^p_1@KMPW2010"]  = bifuricated( -2.1, 1.6 , 0.9 );
            param["B->K::b^0_1@KMPW2010"]  = bifuricated( -4.3, 0.8 , 0.9 ); //???
            param["B->K::b^t_1@KMPW2010"]  = bifuricated( -2.2, 1.0 , 2.0 ); //???
        }
        if ( c.ckm){

            // Vary CKM parameters ? 
            param["CKM::A"]      = rndm->Gaus( 0.827  , 0.013 );
            param["CKM::lambda"] = rndm->Gaus( 0.22535, 0.00065 );
            param["CKM::rhobar"] = rndm->Gaus( 0.132  , 0.021 );
            param["CKM::etabar"] = rndm->Gaus( 0.350  , 0.014 ); 
        }
        if (c.lambda){
            param["B->Pll::Lambda_pseudo@LowRecoil"] = rndm->Gaus( 0.0, 0.15 ) ; 
            param["B->Pll::Lambda_pseudo@LargeRecoil"] = rndm->Gaus( 0.0, 0.50 ) ; 
        }
        // Get Vtb, Vts and Vtd to store in the ntuple
        magVtb = std::abs( Vtb( param ) );
        magVts = std::abs( Vts( param ) );
        magVtd = std::abs( Vtd( param ) );
        /// B decay constant
        if (c.decay){
            param["decay-constant::B_u"] = rndm->Uniform(0.1906, 0.005);
            param["decay-constant::pi"] = rndm->Uniform(0.1288, 0.020);
        }


        // scale dependence is not Gaussian, take a flat prior in range [m_b/2, 2*m_b]
        if (c.scale){
            param["mu"] = rndm->Uniform(2.4, 9.6);
        }
        if (c.masses){
            // MW, mtop etc
            param["mass::t(pole)"] = rndm->Gaus(173.5  ,1.0   );
            param["mass::W"]       = rndm->Gaus(80.385 ,0.015 );
            param["mass::Z"]       = rndm->Gaus(91.1876,0.0021);
        }
        BFLPI = pimumu_loq2.integrated_branching_ratio(  1., 6. );
        BFHPI = pimumu_hiq2.integrated_branching_ratio( 15., 22. );

        BFLK = kmumu_loq2.integrated_branching_ratio(  1., 6. );
        BFHK = kmumu_hiq2.integrated_branching_ratio( 15., 22. );
        if (i<10){
            std::cout << BFLPI << '\t' << BFHPI << '\n' ;
            std::cout << BFLK << '\t' << BFHK << std::endl ;
        }

        outtree->Fill();
    }

    outtree->Write();
    outfile->Close();

    dt::ptime endtime  = dt::second_clock::local_time();
    dt::time_duration difftime = endtime - starttime;
    std::cout << "time  " << difftime.total_seconds() << " seconds " << std::endl ;


    return 0;
}




