from value import Value


from math import pow, pi
GF2 = pow(1.66E-05,2)
ae2 = pow(7.29E-3,2)
t10 = pow(2,10)
pi5 = pow(pi,5)
mB3 = pow(5.279,3)
tB = pow(1.53,1)
Vtb = Value(1.03,0.02)
Vtd = Value(8.4E-3,0.)
Vts = Value(8.4E-3,0.)

a =  Vtb * Vtd 
b = GF2 * ae2 * tB / ( t10 * pi5 * mB3 )  
c =  Vtb * Vts

print a, b

PiBRlow1 = Value(4.1377E-9, 1.1710E-9)
PiBRlow2 = Value(4.1377E-9, 1.3654E-9)
sigmalow1 = PiBRlow1 / a / Value(b)
sigmalow2 = PiBRlow2 / a / Value(b)
print sigmalow1, sigmalow2

PiBRhigh1 = Value(1.5569E-9, 0.4422E-9)
PiBRhigh2 = Value(1.5569E-9, 0.5267E-9)
sigmahigh1 = PiBRhigh1 / a / Value(b)
sigmahigh2 = PiBRhigh2 / a / Value(b)
print sigmahigh1, sigmahigh2

#print PiBRlow1 / (sigmalow1 * Value(b) )

#Kmumu
KBRlow1 = Value(1.6716E-7, 1.9051E-8)
KBRlow2 = Value(1.6716E-7, 5.2671E-8)
sigmalow1 = KBRlow1 / c / Value(b)
sigmalow2 = KBRlow2 / c / Value(b)
print sigmalow1, sigmalow2

KBRhigh1 = Value(7.2653E-8, 0.8296E-9)
KBRhigh2 = Value(7.2653E-8, 2.2939E-8)
sigmahigh1 = KBRhigh1 / c / Value(b)
sigmahigh2 = KBRhigh2 / c / Value(b)
print sigmahigh1, sigmahigh2

#print KBRlow1 / (sigmalow1 * Value(b) )

VtdVts = Value(0.216, 0.011)

BRRatiolow1 = PiBRlow1 / KBRlow1
BRRatiolow2 = PiBRlow2 / KBRlow2
BRRatiohigh1 = PiBRhigh1 / KBRhigh1
BRRatiohigh2 = PiBRhigh2 / KBRhigh2

sigmaratio1 = BRRatiolow1 / VtdVts
sigmaratio2 = BRRatiolow2 / VtdVts
print sigmaratio1, sigmaratio2
sigmaratio3 = BRRatiohigh1 / VtdVts
sigmaratio4 = BRRatiohigh2 / VtdVts
print sigmaratio3, sigmaratio4

