
jpsikfilename = "~/data/Pimm/tobi/jpsik_11_12_selected.root"
jpsipifilename = "~/data/Pimm/tobi/jpsipi_11_12_selected.root"
misidfilename = "~/data/Pimm/tobi/jpsik_11_12_selected_renamed_B_M_to_B_M_real.root"
kmumufilename = "~/data/Pimm/tobi/kmumu_11_12_selected.root"
pimumufilename = "~/data/Pimm/tobi/pimumu_11_12_selected.root"

kmumufilename = "~/data/Pimm/loose/kmumu_11_12_selected.root"
pimumufilename = "~/data/Pimm/loose/pimumu_11_12_selected.root"

mass_min = 5040
mass_mid = 5175
mass_max = 5700


qsqbins = [(0.1, 25), (0.1, 2), (2, 4), (4, 6), (6, 8),
           (11, 12.5), (15, 17), (17, 19), (19, 22), (22, 25),
           (1, 6), (15, 22)
          ]




