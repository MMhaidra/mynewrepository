#! /usr/bin/env python
 
import time, ROOT


bumisrecofile = "/home/alexshires/data/Pimm/partreco/bdjpsipix.root"
bdmisrecofile = "/home/alexshires/data/Pimm/partreco/bujpsipix.root"
bsmisrecofile = "/home/alexshires/data/Pimm/partreco/bsjpsipix.root"

from ROOT import RooRealVar, RooKeysPdf, RooFit, RooDataSet

from ROOT import RooKeysPdf, RooFit

def jpsik():

    fu = ROOT.TFile(bumisrecofile, "READ")
    tu = fu.Get("DecayTree")
    fd = ROOT.TFile(bdmisrecofile, "READ")
    td = fd.Get("DecayTree")
    fs = ROOT.TFile(bsmisrecofile, "READ")
    ts = fs.Get("DecayTree")


    masstitle = "m_{K#mu^{+}#mu^{-}}"
    mass = RooRealVar("B_M", masstitle, 4800, 5300, "MeV/c^{2}")
    bkg = RooRealVar("B_BKGCAT", "", 0, 200, "")
    weight = RooRealVar("weight", "", 0 , 2) 
    args = ROOT.RooArgSet(mass, bkg)

    bujpsik = ROOT.RooDataSet("budata", "", tu, args, "B_M>4600 && B_BKGCAT==50 && B_M<5200")
    bdjpsik = ROOT.RooDataSet("bddata", "", td, args, "B_M>4600 && B_BKGCAT==50 && B_M<5200")
    bsjpsik = ROOT.RooDataSet("bsdata", "", ts, args, "B_M>4600 && B_BKGCAT==50 && B_M<5200")


    weight.setVal(1.0)
    bujpsik.addColumn(weight)
    weight.setVal(1.0)
    bdjpsik.addColumn(weight)
    weight.setVal(0.333333)
    bsjpsik.addColumn(weight)
    
    args.add(weight)

    misrecodata = RooDataSet("totdata", "", bujpsik, args,  "weight")

    misrecodata.append(bdjpsik)
    misrecodata.append(bsjpsik)
    

    totpdf = RooKeysPdf("keyspdf", "", mass, misrecodata, RooKeysPdf.MirrorLeft, 2)

    from ROOT import TCanvas
    c = TCanvas("c", "", 800, 600)
    p = mass.frame()
    misrecodata.plotOn(p, RooFit.Binning(20))
    totpdf.plotOn(p)
    p.Draw()
    c.SaveAs("simulation_partreco.pdf")

    from ROOT import TFile, RooWorkspace
    f = TFile("partreco_workspace.root", "RECREATE")
    w = RooWorkspace("partreco")
    getattr(w, "import")(totpdf, ROOT.RooCmdArg())
    w.Write()
    f.Close()
    fu.Close()
    fd.Close()
    fs.Close()
    #fl.Close()


slfile = "~/data/Pimm/bkgs/with_bdt_kmunumunu_newpid_presel_offsel_weight_vars.root"

qsqbins = [(0, 25), (0.1, 2), (2, 4), (4, 6), (6, 8),
           (11, 12.5), (15, 17), (17, 19), (19, 22), (22, 25),
           (1, 6), (15, 22)
          ]

from fitmodels import expo, expgauss

def semilep():
    fs = ROOT.TFile(slfile, "READ")
    ts = fs.Get("DecayTree")
    wfname = "pimumu_workspace.root"
    wf = ROOT.TFile(wfname, "UPDATE")
    ws = wf.Get("pimumu_workspace")
    mass = ws.var("B_M")
    qsq = ws.var("qsq")
    bdt = ws.var("BDT_4")
    probnnk = ws.var("muplus_ProbNNk")
    bkgcat  = ROOT.RooRealVar("B_BKGCAT", "bkgcat", 0, 100)
    args = ROOT.RooArgSet(mass, qsq, bdt, probnnk, bkgcat)
    args.setName("args")
    mass.Print()
    semilepdata = RooDataSet("semilepdata", "", ts, 
                            args, "B_BKGCAT>49 && B_M<5280", "weight")
    semilepdata.Print()
    pdfs1, vars1 = expo(mass, "semilep")
    pdfs2, vars2 = expgauss(mass, "semilep")
    vars2[0].setVal(5280)
    vars2[0].setConstant(True)
    vars2[1].setMin(8)
    vars2[1].setMax(400)
    vars2[2].setMin(5080)
    vars2[2].setMax(5400)
    vars2[2].setVal(5100)
    vars1[0].setMax(0)
    vars1[0].setMin(-1)
    print "fitting keys"
    totpdf3 = RooKeysPdf("slkeyspdf", "", mass, semilepdata, RooKeysPdf.MirrorLeft, 2)
    totpdf1 = pdfs1[0]
    print "fitting exp"
    res1 = totpdf1.fitTo(semilepdata, RooFit.Save(True), RooFit.SumW2Error(True), RooFit.Strategy(2)) 
    totpdf2 = pdfs2[0]
    print "fitting expgauss"
    res2 = totpdf2.fitTo(semilepdata, RooFit.Save(True), RooFit.SumW2Error(True), RooFit.Strategy(2)) 
    res1.Print()
    res2.Print()
    from ROOT import TCanvas
    c = TCanvas("c", "", 800, 600)
    c.SaveAs("semilep_partreco.pdf[")
    mass.SetTitle("m(#pi^{+}#mu^{+}#mu^{-})")
    p = mass.frame()
    semilepdata.plotOn(p, RooFit.Binning(20))
    totpdf1.plotOn(p)
    c.cd()
    p.Draw()
    c.SaveAs("semilep_partreco.pdf")
    del p
    p = mass.frame()
    semilepdata.plotOn(p, RooFit.Binning(20))
    totpdf2.plotOn(p)
    c.cd()
    p.Draw()
    c.SaveAs("semilep_partreco.pdf")
    del p
    p = mass.frame()
    semilepdata.plotOn(p, RooFit.Binning(20))
    totpdf3.plotOn(p)
    c.cd()
    p.Draw()
    c.SaveAs("semilep_partreco.pdf")
    del p
    vars1[0].setConstant(True)
    vars2[0].setConstant(True)
    vars2[1].setConstant(True)
    vars2[2].setConstant(True)
    getattr(ws, "import")(totpdf1, ROOT.RooFit.RecycleConflictNodes())
    getattr(ws, "import")(totpdf2, ROOT.RooFit.RecycleConflictNodes())
    getattr(ws, "import")(totpdf3, ROOT.RooFit.RecycleConflictNodes())
    """
    for i, qsqbin in enumerate(qsqbins):
        qsqmin, qsqmax = qsqbin
        cut = "%s<qsq&&qsq<%s"%(qsqmin, qsqmax)
        print cut
        semilepdata2 = semilepdata.reduce(cut)
        semilepdata2.Print()
        totpdf2 = RooKeysPdf("slkeyspdf"+str(i), "", mass, semilepdata2, RooKeysPdf.MirrorLeft, 2)
        pdfs, vars = expo(mass, "semilep"+str(i))
        totpdf = pdfs[0]
        res = totpdf.fitTo(semilepdata2, RooFit.Save(True),
                           RooFit.SumW2Error(True),
                           RooFit.Strategy(2)) 
        res.Print()
        p = mass.frame()
        semilepdata2.plotOn(p, RooFit.Binning(20))
        totpdf.plotOn(p)
        c.cd()
        p.Draw()
        c.SaveAs("semilep_partreco.pdf")
        del p
        getattr(w, "import")(totpdf, ROOT.RooCmdArg())
    """
    c.SaveAs("semilep_partreco.pdf]")
    ws.Write()
    wf.cd()
    fs.Close()



from fitmodels import oppoCB, singleCBdown, singleCBup

pifile = "~/data/Pimm/tobi/with_bdt_jpsipi_12_mc_isoln_newpid_corr_qsq_corr_selected_vars.root"
def jpsipi():
    fp = ROOT.TFile(pifile, "READ")
    tp = fp.Get("DecayTree")
    kmasstitle = "m_{K#mu^{+}#mu^{-}}"
    pimasstitle = "m_{#pi#mu^{+}#mu^{-}}"
    kmass = RooRealVar("kmumu_M", kmasstitle, 5000, 5700, "MeV/c^{2}")
    pimass = RooRealVar("pimumu_M", pimasstitle, 5000, 5700, "MeV/c^{2}")
    Bmass = RooRealVar("B_M", kmasstitle, 5000, 5700, "MeV/c^{2}")
    dilepton = RooRealVar("qsq", "qsq", 0, 25, "MeV^2/c^{4}")
    args = ROOT.RooArgSet(Bmass, dilepton, kmass, pimass)
    jpsipidata = RooDataSet("jpsipidata", "", tp, args)
    #construct pdf
    sigpdfs, sigpars = singleCBdown(kmass, "jpsipi")
    totpdf = sigpdfs[0]
    #fittot
    res = totpdf.fitTo(jpsipidata,
                       RooFit.NumCPU(5),
                       RooFit.Save(True),
                      )
    res.Print()
    for par in sigpars:
        par.setConstant(True)

    from ROOT import TCanvas
    c = TCanvas("c", "", 800, 600)
    c.SaveAs("jpsipi_asjpsik.pdf[")
    p = kmass.frame()
    jpsipidata.plotOn(p, RooFit.Binning(20))
    totpdf.plotOn(p)
    p.Draw()
    c.SaveAs("jpsipi_asjpsik.pdf")
    c.SaveAs("jpsipi_asjpsik.pdf]")
    from ROOT import TFile, RooWorkspace
    #create new totpdf
    m = sigpars[0]
    s = sigpars[1]
    a = sigpars[2]
    n = sigpars[3]
    wfname = "pimumu_workspace.root"
    wf = ROOT.TFile(wfname, "UPDATE")
    ws = wf.Get("pimumu_workspace")
    mass = ws.var("B_M")
    sigpdf = ROOT.RooCBShape("jpsipi_as_k", "", mass, m, s, a, n)
    getattr(ws, "import")(sigpdf, RooFit.RecycleConflictNodes())
    ws.Write()
    wf.Close()
    f = TFile("jpsipi_workspace.root", "RECREATE")
    w = RooWorkspace("jpsipi")
    getattr(w, "import")(totpdf, ROOT.RooCmdArg())
    w.Write()
    f.Close()
    fp.Close()


rhofile = "/home/alexshires/data/Pimm/bkgs/with_bdt_rhomumu_12_mc_newpid_presel_offsel.root"
f0file = "/home/alexshires/data/Pimm/bkgs/with_bdt_f0mumu_12_mc_newpid_presel_offsel.root"
ksfile = "/home/alexshires/data/Pimm/bkgs/with_bdt_KSmumu_12_mc_newpid_presel_offsel.root"
slfile = "/home/alexshires/data/Pimm/bkgs/with_bdt_kmunumunu_12_mc_newpid_presel_offsel_weight_vars.root"
d0file = "/home/alexshires/data/Pimm/bkgs/with_bdt_d0munu_12_mc_piasmu_newpid_presel_offsel_weight_vars.root"

bkgfiles = {"rho":rhofile, "f0":f0file, "ks":ksfile, "sl2":slfile}

def rare_bkgs():
    c = ROOT.TCanvas("c", "", 800, 600)

    wfname = "pimumu_workspace.root"
    wf = ROOT.TFile(wfname, "UPDATE")
    ws = wf.Get("pimumu_workspace")
    mass = ws.var("B_M")
    qsq = ws.var("qsq")
    bdt = ws.var("BDT_4")
    probnnk = ws.var("muplus_ProbNNk")
    args = ROOT.RooArgSet(mass, qsq, bdt, probnnk)
    args.setName("args")
    mass.SetTitle("m(#pi^{+}#mu^{+}#mu^{-})")
    mass.Print()

    f = ROOT.TFile("bkgs_workspace.root", "RECREATE")
    w = ROOT.RooWorkspace("bkgs")

    for bkg, bkgfile in bkgfiles.iteritems():
        fb = ROOT.TFile(bkgfile, "READ")
        tb = fb.Get("DecayTree")
        bkgdata = RooDataSet(bkg+"data", "", tb, args, "BDT_4>0.5")
        bkgdata.Print()
        #sigpdfs, sigpars = singleCBup(mass, "bkg_"+bkg)
        #sigpars[0].setMin(5000)
        #sigpars[3].setMin(1)
        #totpdf = sigpdfs[0]
        #res = totpdf.fitTo(bkgdata,# RooFit.NumCPU(5),
        #                   RooFit.Save(True))
        #res.Print()
        #for par in sigpars:
        #    par.Print()
        #    par.setConstant(True)
        pdfs2, vars2 = expgauss(mass, bkg)
        vars2[1].setMax(250)
        res1 = pdfs2[0].fitTo(bkgdata, RooFit.Save(True), RooFit.Strategy(2))
        res1.Print()
        for var in vars2:
            var.setConstant(True)
        totpdf = RooKeysPdf(bkg+"keyspdf", "", mass, bkgdata,
                            RooKeysPdf.MirrorLeft, 2)
        c.cd()
        c.SaveAs(bkg+"_partreco.pdf[")
        p = mass.frame()
        bkgdata.plotOn(p, RooFit.Binning(20))
        totpdf.plotOn(p)
        p.Draw()
        c.SaveAs(bkg+"_partreco.pdf")
        p = mass.frame()
        bkgdata.plotOn(p, RooFit.Binning(20))
        pdfs2[0].plotOn(p)
        p.Draw()
        c.SaveAs(bkg+"_partreco.pdf")
        c.SaveAs(bkg+"_partreco.pdf]")
        f.cd()
        getattr(ws, "import")(totpdf, RooFit.RecycleConflictNodes())
        getattr(w, "import")(totpdf, RooFit.RecycleConflictNodes())
        getattr(ws, "import")(pdfs2[0], RooFit.RecycleConflictNodes())
        getattr(w, "import")(pdfs2[0], RooFit.RecycleConflictNodes())
        fb.Close()
    f.cd()
    w.Write()
    f.Close()
    wf.cd()
    ws.Write()
    wf.Close()



if __name__ == '__main__':
    start = time.time()
    print time.asctime(time.localtime())
    ROOT.gROOT.SetBatch(True)

    ROOT.gROOT.LoadMacro("RooExpAndGauss.cpp+")
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()

    ROOT.RooMsgService.instance().setGlobalKillBelow(RooFit.ERROR)
    ROOT.RooMsgService.instance().setSilentMode(True)
    semilep()
    #jpsipi()
    rare_bkgs()

    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start
    exit(0)

