
import ROOT

#import PyLHCb.Root.RooFitDecorators

# Proxies for RooFit classes
RooFit = ROOT.RooFit
RooRealVar = ROOT.RooRealVar
RooArgList = ROOT.RooArgList
RooArgSet  = ROOT.RooArgSet
RooGaussian = ROOT.RooGaussian
RooDataSet = ROOT.RooDataSet
RooAddPdf = ROOT.RooAddPdf
RooExponential = ROOT.RooExponential


x = RooRealVar("x","x",-30, 30)

mean = RooRealVar("mean","mean of gaussian", 0)
sigma = RooRealVar("sigma","width of gaussian", 2, 0, 5)
gauss = RooGaussian("gauss","gaussian PDF", x, mean, sigma)

mean2 = RooRealVar("mean2","mean of gaussian 2", 0)
sigma2 = RooRealVar("sigma2","width of gaussian 2", 2, 0, 5)
gauss2 = RooGaussian("gauss2","gaussian PDF 2", x, mean2, sigma2)

tau = RooRealVar("tau", "tau", -0.05, -0.5, 0.5)
expo = RooExponential("expo", "expo", x, tau)

tau2 = RooRealVar("tau2", "tau2", -0.05, -0.5, 0.5)
expo2 = RooExponential("expo2", "expo2", x, tau2)

Nsig = RooRealVar("Nsig", "Nsig", 1000, 10, 2000)
Nbkg = RooRealVar("Nbkg", "Nbkg", 1000, 10, 2000)

Nsig2 = RooRealVar("Nsig2", "Nsig2", 1000, 10, 2000)
Nbkg2 = RooRealVar("Nbkg2", "Nbkg2", 1000, 10, 2000)

model1 = RooAddPdf("model1", "model1", RooArgList(gauss, expo), RooArgList(Nsig, Nbkg))
model2 = RooAddPdf("model2", "model2", RooArgList(gauss2, expo2), RooArgList(Nsig2, Nbkg2))

# Generate a toy MC set
data1 = model1.generate(RooArgSet(x), 2000) # RooDataSet
x.setRange(-20, 20)
data2 = model2.generate(RooArgSet(x), 2000) # RooDataSet
x.setRange(-30, 30)

# Build simultaneous fit
decay = ROOT.RooCategory("decay", "decay")
decay.defineType("signal1", 0)
decay.defineType("signal2", 1)
varList = RooArgSet()
varList.add(x)
combData = RooDataSet("combData", "combData", varList,
                      RooFit.Index(decay),
                      RooFit.Import('signal1', data1),
                      RooFit.Import('signal2', data2))

model = ROOT.RooSimultaneous("model", "model", decay)
model.addPdf(model1,  "signal1")
model.addPdf(model2,  "signal2")

# Define different fit ranges
x.setRange("fitRange_signal1", -30, 30)
x.setRange("fitRange_signal2", -20, 20)

fitResults = model.fitTo(combData, RooFit.Save(True), RooFit.Minos(False), RooFit.Range("fitRange"), RooFit.SplitRange(True))
fitResults.Print()

c2 = ROOT.TCanvas()
c2.SaveAs("test.pdf[")
# Plot PDF and toy data overlaid
xframe = x.frame()
combData.plotOn(xframe, RooFit.Cut("decay==decay::signal1"))
param1 = ROOT.RooArgSet(Nsig, Nbkg, sigma, tau)
model.paramOn(xframe, RooFit.Layout(.55, .95, .93), RooFit.Parameters(param1))
model.plotOn(xframe, RooFit.Slice(decay, "signal1"), RooFit.ProjWData(ROOT.RooArgSet(decay), combData))
model.plotOn(xframe, RooFit.Slice(decay, "signal1"), RooFit.ProjWData(ROOT.RooArgSet(decay), combData), RooFit.Components("gauss"), RooFit.LineColor(3))
model.plotOn(xframe, RooFit.Slice(decay, "signal1"), RooFit.ProjWData(ROOT.RooArgSet(decay), combData), RooFit.Components("expo"), RooFit.LineColor(2))
xframe.Draw()
c2.SaveAs("test.pdf")

#x.setRange(-20, 20)

xframe2 = x.frame(RooFit.Range("fitRange_signal2"))
combData.plotOn(xframe2, RooFit.Cut("decay==decay::signal2"))
param2 = ROOT.RooArgSet(Nsig2, Nbkg2, sigma2, tau2)
model.paramOn(xframe2, RooFit.Layout(.55, .95, .93), RooFit.Parameters(param2))
model.plotOn(xframe2, RooFit.Slice(decay, "signal2"), RooFit.ProjWData(ROOT.RooArgSet(decay), combData), RooFit.Range("fitRange_signal2"))
model.plotOn(xframe2, RooFit.Slice(decay, "signal2"), RooFit.ProjWData(ROOT.RooArgSet(decay), combData), RooFit.Range("fitRange_signal2"), RooFit.Components("gauss2"), RooFit.LineColor(3))
model.plotOn(xframe2, RooFit.Slice(decay, "signal2"), RooFit.ProjWData(ROOT.RooArgSet(decay), combData), RooFit.Range("fitRange_signal2"), RooFit.Components("expo2"), RooFit.LineColor(2))
xframe2.Draw()
c2.SaveAs("test.pdf")
c2.SaveAs("test.pdf]")

#EOF
