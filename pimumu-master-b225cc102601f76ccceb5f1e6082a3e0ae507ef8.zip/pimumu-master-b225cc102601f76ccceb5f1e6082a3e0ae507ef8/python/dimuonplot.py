#! /usr/bin/env python

qsqbins = [(0, 25)   , (0.1, 2), (2, 4), (4, 6), (6, 8),
           (11, 12.5), (15, 17), (17, 19), (19, 22), (22, 25),
           (1, 6), (15, 22)
          ]

import time, ROOT

if __name__ == "__main__":
    start = time.time()
    print time.asctime(time.localtime())
    ROOT.gROOT.SetBatch(True)

    piname = "/home/alexshires/data/Pimm/tobi/pimumu_11_12_selected.root"
    kname = "/home/alexshires/data/Pimm/tobi/kmumu_11_12_selected.root"
    fp = ROOT.TFile(piname)
    tp = fp.Get("DecayTree")
    fk = ROOT.TFile(kname)
    tk = fk.Get("DecayTree")
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()
    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start


    cut = "B_M>5200 && B_M<5360"
    andstr = " && "
    c = ROOT.TCanvas("c1", "", 800, 600)
    c.SaveAs("pimumu_dimuonplots.pdf[")
    c2 = ROOT.TCanvas("c2", "", 800, 600)
    c2.SaveAs("kmumu_dimuonplots.pdf[")
    for i, qbin in enumerate(qsqbins):
        qsqmin, qsqmax = qbin
        nbins = 10
        if i == 0 :
            nbins = 40
        if i > 9:
            nbins = 20
        histp = ROOT.TH1D("hp", "", nbins, qsqmin, qsqmax)
        histp.GetXaxis().SetTitle('#it{q}^{2} [GeV^{2}/#it{c}^{4}]')
        tp.Draw("qsq>>hp", cut, "goff")
        c.cd()
        histp.Draw("e")
        c.SaveAs("pimumu_dimuonplots.pdf")
        tk.Draw("qsq>>hp", cut, "goff")
        c2.cd()
        histp.Draw("e")
        c2.SaveAs("kmumu_dimuonplots.pdf")
    c.SaveAs("pimumu_dimuonplots.pdf]")
    c2.SaveAs("kmumu_dimuonplots.pdf]")



    #probNNpi plots


    pass
