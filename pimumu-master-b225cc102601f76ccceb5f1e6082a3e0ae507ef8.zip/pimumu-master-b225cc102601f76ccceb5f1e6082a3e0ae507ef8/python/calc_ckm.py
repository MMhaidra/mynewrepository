#! /usr/bin/env python



from ROOT import RooRealVar, RooFormulaVar



rflow = RooRealVar("fflow", "fflow", 0.56)
rflow.setError(0.20)
rfhigh = RooRealVar("ffhigh", "ffhigh", 0.46)
rfhigh.setError(0.17)

if __name__ == '__main__':
    #pimumu



