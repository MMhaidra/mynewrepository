

import time
import ROOT

from ROOT import RooFit, RooRealVar, RooArgList, RooArgSet


from pars import jpsikfilename, jpsipifilename, kmumufilename, pimumufilename
from pars import mass_min, mass_mid, mass_max
from pars import qsqbins


import pandas as pd
import numpy as np

import os

ROOT.PyConfig.IgnoreCommandLineOptions = True




def calc_sys(options):
    qsqmin, qsqmax = qsqbins[options.bin]

    wfname = os.path.join(options.basedir, "pimumu_workspace.root")
    wf = ROOT.TFile(wfname, "READ")
    ws = wf.Get("pimumu_workspace")

    fitwfname = os.path.join(options.basedir, "fitresults_workspace.root")
    fitwsname = "workspace%s" % options.bin
    fitwf = ROOT.TFile(fitwfname, "READ")
    fitws = fitwf.Get(fitwsname)
    mass = fitws.var("B_M")
    qsq = fitws.var("qsq")
    bdt = fitws.var("BDT_4")
    probnnk = fitws.var("muplus_ProbNNk")
    args = ROOT.RooArgSet(mass, qsq, bdt, probnnk)
    args.setName("args")
    mass.Print()
    print "getting", pimumufilename
    pimumufile = ROOT.TFile(pimumufilename, "READ")
    pimumutree = pimumufile.Get("DecayTree")
    pimumutree.SetBranchStatus("*", 0)
    pimumutree.SetBranchStatus("B_M", 1)
    pimumutree.SetBranchStatus("qsq", 1)
    pimumutree.SetBranchStatus("BDT_4", 1)
    pimumutree.SetBranchStatus("muplus_ProbNNk", 1)
    kcutval = 0.4
    if options.sysku:
        kcutval = 0.35
    if options.syskd:
        kcutval = 0.45
    bdtcut = "BDT_4>0.5 && muplus_ProbNNk<%s && qsq>%g && qsq<%g" % (kcutval, qsqmin, qsqmax)
    pimumudata = ROOT.RooDataSet("pimumudata", "", pimumutree, args, bdtcut)
    
    pimumudata.Print()

    n = pimumudata.sumEntries()
    if options.nevents > 0:
        n = options.nevents

    scale = float(n) / float(pimumudata.sumEntries())
    cenval = fitws.var("npimumu").getVal() * scale
    print scale, cenval
    #exit()
    #variables in the workspace
    args2 = fitws.allVars()
    args2.Print()
    iter = args2.createIterator()
    while iter :
        #print iter
        try:
            iter.setConstant(True)
            iter.Next()
        except:
            break

    #construct proper pdf
    genpdf = fitws.pdf("pimumupdf")

    #construct systematic pdf
    sigpdf = fitws.pdf("jpsiksigpdf")
    misidpdf = fitws.pdf("misID")
    bkgpdf = fitws.pdf("pimumuexppdf")
    fzpdf = fitws.pdf("f0keyspdf")
    rhopdf = fitws.pdf("rhokeyspdf")
    slpdf = fitws.pdf("semilepbkgexpgausspdf")


    #systematics
    if options.syssl:
        #slpdf = ws.pdf("semilepexppdf")
        semilepvar = fitws.var("semilepexpg_trans")
        origslval = semilepvar.getVal()
        semilepvar.setConstant(False)
        semilepvar.Print()
    if options.sysfz:
        fzpdf = ws.pdf("f0bkgexpgausspdf")
    if options.sysrho:
        rhopdf = ws.pdf("rhobkgexpgausspdf")
    if options.sysmu:
        mass.setMax(7000)
    if options.sysmd:
        mass.setMax(5700)
    if options.sysmis:
        misidm2 = RooRealVar("misidm2", "", 5223.6)
        misids2 = RooRealVar("misids2", "", 27.17)
        misida2 = RooRealVar("misida2", "", 0.512)
        misidn2 = RooRealVar("misidn2", "", 35)
        misidpdf = ROOT.RooCBShape("misidpdf2", "", mass, misidm2, misids2, misida2, misidn2)

    print sigpdf, misidpdf, bkgpdf, fzpdf, rhopdf, slpdf

    nmisid = RooRealVar("nmisid2", "", 0, n)
    nrho = RooRealVar("nrho2", "", 0, n)
    nsl = RooRealVar("nsemi2", "", 0, n)
    nf0 = RooRealVar("nfz2", "", 0, n)
    npi = RooRealVar("npi2", "", 0, n)
    nbkg = RooRealVar("nbkg2", "", 0, n)

    pivars = RooArgList(npi, nmisid, nbkg, nrho, nf0, nsl)
    pipdfs = RooArgList(sigpdf, misidpdf, bkgpdf, rhopdf, fzpdf, slpdf)

    fitpdf = ROOT.RooAddPdf("fitpdf", "", pipdfs, pivars)

    fitws.Print()


    #constraints
    import numpy as np
    from math import sqrt
    misidvals = [40, 7.1, 7.1, 7.7, 8.5, 7.2, 7.6, 5.7, 3.5, 0, 18, 16]
    misidvals = np.array([40, 8.5, 10.5, 8.1, 8.7, 5.1, 5.8, 7.3, 2.6, 0, 18, 16])/1.1
    misiderrs = np.array([7, 1.2, 1.4, 1.1, 1.0, 0.7, 0.9, 1.1, 0.6, 0, 5, 5])/1.1

    misidmean = RooRealVar("misidcmean", "", 0)
    misidsigma = RooRealVar("misidcsigma", "", 10.1)
    misidgaus = ROOT.RooGaussian("misidcgaus", "", nmisid,
                                 misidmean, misidsigma)

    f0vals = [8.7, 1., 1., 1.2, 1.6, 1.4, 1.4, 0.8, 0.2, 0, 2.8, 2.4]
    f0errs = [2.4, 0.3, 0.3, 0.4, 0.5, 0.4, 0.4, 0.3, 0.1, 0.1, 0.6, 0.7]
    rhovals = np.array([9.8, 1., 1., 1.2, 1.5, 1.4, 1.4, 0.4, 0.2, 0, 2.8, 2.8])*3
    rhoerrs = np.array([2.4, 0.3, 0.3, 0.4, 0.5, 0.4, 0.4, 0.3, 0.1, 0.1, 0.6, 0.7])*sqrt(3)

    f0mean = RooRealVar("f0cmean", "", 0)
    f0sigma = RooRealVar("f0csigma", "", 0)
    f0gaus = ROOT.RooGaussian("f0cgaus", "", nf0,
                              f0mean, f0sigma)
    rhomean = RooRealVar("rhocmean", "", 0)
    rhosigma = RooRealVar("rhocsigma", "", 0)
    rhogaus = ROOT.RooGaussian("rhocgaus", "", nrho,
                               rhomean, rhosigma)


    misidmean.setVal(misidvals[options.bin] * scale)
    misidsigma.setVal(misiderrs[options.bin] * scale)
    rhomean.setVal(rhovals[options.bin] * scale)
    rhosigma.setVal(rhoerrs[options.bin] * scale)
    f0mean.setVal(f0vals[options.bin] * scale)
    f0sigma.setVal(f0errs[options.bin] * scale)



    c = ROOT.TCanvas("c", "", 800, 600)
    name = "toys_debug"
    if options.syssl:
        name += "_syssl"
    if options.sysfz:
        name += "_sysfz"
    if options.sysrho:
        name += "_sysrho"
    if options.sysku:
        name += "_sysku"
    if options.syskd:
        name += "_syskd"
    if options.sysmu:
        name += "_sysmu"
    if options.sysmd:
        name += "_sysmd"
    if options.sysmis:
        name += "_sysmis"

    name += ".pdf"
    print name
    c.SaveAs(name+"[")
        
    consts = RooArgSet(misidgaus, f0gaus, rhogaus)#, piexpgaus, kexpgaus

    h = ROOT.TH1D("h", "", 20, -5, 5)

    for i in range(options.ntoys):
        if i%(options.ntoys/10) == 0:
            print "processed", i
        if options.syssl:
            semilepvar.setVal(origslval)
        #nevents
        gendata = genpdf.generate(args, n)

        nmisid.setVal(misidvals[options.bin] * scale)
        nrho.setVal(rhovals[options.bin] * scale) 
        nf0.setVal(f0vals[options.bin] * scale)

        #set other values to starting parameters
        npi.setVal(cenval)
        nbkg.setVal(0)
        nsl.setVal(10 * scale)

        res = fitpdf.fitTo(gendata, RooFit.Save(True),
                           RooFit.Extended(True),
                           RooFit.Strategy(2),
                           RooFit.ExternalConstraints(consts)
                          )
        pull = (cenval - npi.getVal())/ npi.getError()

        if i < 10:
            res.Print()
            print "pull", pull
            p = mass.frame()
            gendata.plotOn(p)
            fitpdf.plotOn(p)
            fitpdf.plotOn(p, RooFit.Components(misidpdf.GetName()),
                          RooFit.LineColor(ROOT.kMagenta+2))
            fitpdf.plotOn(p, RooFit.Components(slpdf.GetName()),
                          RooFit.LineColor(ROOT.kMagenta+2),
                          RooFit.LineStyle(ROOT.kDashed))
            fitpdf.plotOn(p, RooFit.Components(fzpdf.GetName()),
                          RooFit.LineColor(ROOT.kRed),
                          RooFit.LineStyle(ROOT.kDashed))
            fitpdf.plotOn(p, RooFit.Components(rhopdf.GetName()),
                          RooFit.LineColor(ROOT.kBlue),
                          RooFit.LineStyle(ROOT.kDashed))
            p.Draw()
            c.SaveAs(name)
            del p
        
        h.Fill(pull)
        del gendata

    ROOT.gStyle.SetOptFit(1011)
    h.GetXaxis().SetTitle("yield pull")
    r = h.Fit("gaus", "SLEM")
    h.Draw("e")
    c.SaveAs(name)
    c.SaveAs(name+"]")
    wf.Close()
    fitwf.Close()
    return r



def write(options, res, sysname):
    res.Print()
    m = res.Parameter(1)
    s = res.Parameter(2)
    if options.write:
        df = pd.read_csv("systematics.data", sep='\t', index_col=0)
        #print df
        cenval = df['cenval'][options.bin]
        if "cenval" in sysname:
            print "centre", m
            syst = m
        else:
            syst = (cenval - m)
            print sysname, syst, cenval, m, s
        df.loc[options.bin,sysname] = syst
        print df
        df.to_csv("systematics.data", sep='\t')

basedir = "~/pimumu/python"


if __name__ == '__main__':

    start = time.time()
    print time.asctime(time.localtime())
    ROOT.gROOT.SetBatch(True)
    ROOT.gROOT.LoadMacro("RooExpAndGauss.cpp+")
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()

    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument("-t", "--ntoys", dest="ntoys", type=int, default=100,
                        help="number of toys")
    parser.add_argument("-e", "--nevts", dest="nevents", type=int, default=-1,
                        help="number of toys")
    parser.add_argument("-s", "--seed", dest="seed", type=int, default=1,
                        help="random seed")
    parser.add_argument("--basedir", dest="basedir", type=str, default=basedir,
                        help="basedir")
    parser.add_argument("-b", "--bin", dest="bin", type=int, default=0,
                        help="bins")
    parser.add_argument("-d", "--debug", dest="debug", action="store_true",
                        default=False, help="testing")
    parser.add_argument("-a", "--all", dest="all", action="store_true",
                        default=False, help="all")
    parser.add_argument("-w", "--write", dest="write", action="store_true",
                        default=False, help="write output")
    parser.add_argument("-c", "--create", dest="create", action="store_true",
                        default=False, help="create output")
    parser.add_argument("--sysrho", dest="sysrho", action='store_true', default=False, help="sysrho")
    parser.add_argument("--sysfz", dest="sysfz", action='store_true', default=False, help="sysfz")
    parser.add_argument("--syssl", dest="syssl", action='store_true', default=False, help="syssl")
    parser.add_argument("--sysku", dest="sysku", action='store_true', default=False, help="sysku")
    parser.add_argument("--syskd", dest="syskd", action='store_true', default=False, help="syskd")
    parser.add_argument("--sysmu", dest="sysmu", action='store_true', default=False, help="sysmass")
    parser.add_argument("--sysmd", dest="sysmd", action='store_true', default=False, help="sysmass")
    parser.add_argument("--sysmis", dest="sysmis", action='store_true', default=False, help="sysmisid")
    #

    options = parser.parse_args()

    if not options.debug:
        ROOT.RooMsgService.instance().setGlobalKillBelow(RooFit.ERROR)
        ROOT.RooMsgService.instance().setSilentMode(True)

    sysname = "cenval"
    if options.sysrho:
        sysname = "sysrho"
    if options.sysfz:
        sysname = "sysfz"
    if options.syssl:
        sysname = "syssl"
    if options.sysku:
        sysname = "sysku"
    if options.syskd:
        sysname = "syskd"
    if options.sysmu:
        sysname = "sysmu"
    if options.sysmd:
        sysname = "sysmd"
    if options.sysmis:
        sysname = "sysmis"

    systs = ["cenval", "sysrho", "sysfz", "syssl", "sysku",
             "syskd", "sysmu", "sysmd", "sysmis"]

    print "systematic", sysname

    if options.create:
        print "creating sysfile"
        df = pd.DataFrame(0, index=range(len(qsqbins)), columns=systs)
        df.to_csv("systematics.data", sep='\t')
        exit()


    ROOT.RooRandom.randomGenerator().SetSeed(options.seed)

    if options.all:
        for i, b in enumerate(qsqbins):
            r = calc_sys(options)
            if options.write:
                write(options, r, sysname)
    else:
        r = calc_sys(options)
        if options.write:
            write(options, r, sysname)


    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start


