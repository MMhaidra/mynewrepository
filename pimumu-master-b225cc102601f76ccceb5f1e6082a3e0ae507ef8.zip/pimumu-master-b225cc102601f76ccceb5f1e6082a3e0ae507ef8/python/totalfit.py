import ROOT

from ROOT import RooRealVar, RooCBShape, RooAddPdf
from ROOT import RooFit, RooRealVar, RooArgList, RooArgSet
from ROOT import RooGaussian, RooDataSet, RooWorkspace
from ROOT import RooSimultaneous, RooCategory
from fitmodels import oppoCB, expo, expgauss, chebychev


from pars import qsqbins

def runtotalfit(mass, args, workspace, kmumudata, pimumudata, options, ext=""):
    #construct PDFs
    #get form jpsik workspace
    #if not options.fitjpsik:
    #    wfj = ROOT.TFile("jpsikmassfit.root", "READ")
    #    wsj = wfj.Get("jpsikworkspace")
    sigpdf = workspace.pdf("jpsiksigpdf")
    #sigpdfs, sigpars = oppoCB(mass, "signal")
    #sigpdf = sigpdfs[0]
    bkgpdfs1, bkgpars1 = expo(mass, "jpsik")
    bkgpdfs2, bkgpars2 = expo(mass, "kmumu")
    bkgpdfs3, bkgpars3 = expo(mass, "pimumu")
    bkgpdfs4, bkgpars4 = expo(mass, "pimumu2")
     
    pibkgpar = bkgpars3[0]
    #pibkgpar2 = bkgpars4[0]
    kbkgpar = bkgpars2[0]

    pibkgpar.setMax(-1E-8)
    #pibkgpar2.setMax(0E2)
    pibkgpar.setVal(-0.00179)
    #pibkgpar2.setVal(-5E-2)
    #pibkgpar2.setMin(-1E-1)
    pibkgpar.setMin(-5E-3)
    kbkgpar.setMax(1E2)
    kbkgpar.setMin(-1E-2)


    #njpsik = RooRealVar("njpsik", "", 0, jpsikdata.sumEntries())
    nkmumu = RooRealVar("nkmumu", "", 0, kmumudata.sumEntries())
    npimumu = RooRealVar("npimumu", "", 0, pimumudata.sumEntries())
    #njpsikbkg = RooRealVar("njpsikbkg", "", 0, 0, jpsikdata.sumEntries())
    npibkg = RooRealVar("npimumubkg", "", 0, 0, pimumudata.sumEntries())
    nkbkg = RooRealVar("nkmumubkg", "", 0, 0, kmumudata.sumEntries())

    misIDmean = RooRealVar("misIDmean", "", 5235.3, 5100, 5250)
    misIDsigma = RooRealVar("misIDsigma", "", 25.6, 0, 50)
    misIDalpha = RooRealVar("misIDalpha", "", 0.71, 0, 10)
    misIDnval = RooRealVar("misIDnval", "", 2.586, 0, 30)
    misIDmean.setConstant(not options.fitmisid)
    misIDsigma.setConstant(not options.fitmisid)
    misIDalpha.setConstant(not options.fitmisid)
    misIDnval.setConstant(not options.fitmisid)
    misIDpdf = RooCBShape("misID", "", mass, misIDmean,
                          misIDsigma, misIDalpha, misIDnval)
    nmisidy = RooRealVar("nmisidy2", "", 0, 1E7)
    nmisidb = RooRealVar("nmisidb2", "", 0, 1E7)
    totmisidpdf = RooAddPdf("totmisidpdf", "",
                            RooArgList(misIDpdf, bkgpdfs4[0]),
                            RooArgList(nmisidy, nmisidb)
                           )

    partrecopdf2, partrecovars2 = expgauss(mass, "kmumu_pr")
    partrecopdf3, partrecovars3 = expgauss(mass, "pimumu_pr")
    partrecopdf1, partrecovars1 = expgauss(mass, "jpsik_pr")

    partrecovars2[0].setMax(5150)
    partrecovars2[1].setMin(10)
    partrecovars2[1].setMax(100)
    #pimumu
    partrecovars3[0].setVal(5070)
    partrecovars3[1].setMin(30)
    partrecovars3[1].setMax(80)
    partrecovars3[2].setVal(5070)
    #pasemileptonic part reco??
    #wfs = ROOT.TFile("semilep_workspace.root", "READ")
    #wss = wfs.Get("semilep")
    #semileppdf = workspace.pdf("slkeyspdf")
    semileppdf = workspace.pdf("semilepbkgexpgausspdf")
    if options.syssl:
        semileppdf = workspace.pdf("semilepexppdf")
        semilepvar = workspace.var("semilepexpl")
        semilepvar.setConstant(False)

    #wfbkg = ROOT.TFile("bkgs_workspace.root", "READ")
    #wsbkg = wfbkg.Get("bkgs")
    f0pdf = workspace.pdf("f0keyspdf")
    if options.sysfz:
        f0pdf = workspace.pdf("f0bkgexpgausspdf")
    rhopdf = workspace.pdf("rhokeyspdf")
    if options.sysrho:
        rhopdf = workspace.pdf("rhobkgexpgausspdf")

    #set constants
    #partrecovars2[1].setConstant(True)
    partrecovars2[2].setConstant(True)
    #partrecovars3[1].setConstant(True)
    partrecovars1[2].setConstant(True)
    partrecovars3[2].setConstant(True)

    nmisid = RooRealVar("nmisid", "", 0, pimumudata.sumEntries())
    npartpi = RooRealVar("npartrecopi", "", 0, pimumudata.sumEntries())
    nparts = RooRealVar("npartsemi", "", 0, pimumudata.sumEntries())
    npartk = RooRealVar("npartrecok", "", 0, kmumudata.sumEntries())
    #npartj = RooRealVar("npartrecoj", "", 0, jpsikdata.sumEntries())

    nf0 = RooRealVar("nf0mumu", "", 0, pimumudata.sumEntries())
    nrho = RooRealVar("nrhomumu", "", 0, pimumudata.sumEntries())

    pimumupartrecopdf = partrecopdf3[0]
    #pimumupartrecopdf = bkgpdfs4[0]
    kmumupartrecopdf = partrecopdf2[0]

    sigpdf.Print()
    bkgpdfs3[0].Print()
    misIDpdf.Print()
    semileppdf.Print()
    pimumupartrecopdf.Print()
    rhopdf.Print()
    f0pdf.Print()

    pipdfs = RooArgList(sigpdf, bkgpdfs3[0], misIDpdf,
                        semileppdf,
                        #pimumupartrecopdf,
                        rhopdf, f0pdf)
    pivals = RooArgList(npimumu, npibkg, nmisid,
                        nparts,
                        #npartpi,
                        nrho, nf0)


    #jpsikpdf = RooAddPdf("jpsikpdf", "",
    #                     RooArgList(sigpdf, bkgpdfs1[0], partrecopdf1[0]),
    #                     RooArgList(njpsik, njpsikbkg, npartj))
    import numpy as np
    from math import sqrt
    misidvals = [40, 7.1, 7.1, 7.7, 8.5, 7.2, 7.6, 5.7, 3.5, 0, 18, 16]
    misidvals = np.array([40, 8.5, 10.5, 8.1, 8.7, 5.1, 5.8, 7.3, 2.6, 0, 18, 16])/1.1
    misiderrs = np.array([7, 1.2, 1.4, 1.1, 1.0, 0.7, 0.9, 1.1, 0.6, 0, 5, 5])/1.1

    misidmean = RooRealVar("misidcmean", "", 0)
    misidsigma = RooRealVar("misidcsigma", "", 10.1)
    misidgaus = ROOT.RooGaussian("misidcgaus", "", nmisid,
                                 misidmean, misidsigma)
    piexpmean = RooRealVar("piexpcmean", "", 0)
    piexpsigma = RooRealVar("piexpcsigma", "", 10.1)
    piexpgaus = ROOT.RooGaussian("piexpcgaus", "", pibkgpar,
                                 piexpmean, piexpsigma)
    kexpmean = RooRealVar("kexpcmean", "", 0)
    kexpsigma = RooRealVar("kexpcsigma", "", 10.1)
    kexpgaus = ROOT.RooGaussian("kexpcgaus", "", kbkgpar,
                                kexpmean, kexpsigma)
    f0vals = [8.7, 1., 1., 1.2, 1.6, 1.4, 1.4, 0.8, 0.2, 0, 2.8, 2.4]
    f0errs = [2.4, 0.3, 0.3, 0.4, 0.5, 0.4, 0.4, 0.3, 0.1, 0.1, 0.6, 0.7]
    rhovals = np.array([9.8, 1., 1., 1.2, 1.5, 1.4, 1.4, 0.4, 0.2, 0, 2.8, 2.8])*3
    rhoerrs = np.array([2.4, 0.3, 0.3, 0.4, 0.5, 0.4, 0.4, 0.3, 0.1, 0.1, 0.6, 0.7])*sqrt(3)

    f0mean = RooRealVar("f0cmean", "", 0)
    f0sigma = RooRealVar("f0csigma", "", 0)
    f0gaus = ROOT.RooGaussian("f0cgaus", "", nf0,
                              f0mean, f0sigma)
    rhomean = RooRealVar("rhocmean", "", 0)
    rhosigma = RooRealVar("rhocsigma", "", 0)
    rhogaus = ROOT.RooGaussian("rhocgaus", "", nrho,
                               rhomean, rhosigma)


    #mass.setRange("range_jpsik", mass_mid, mass_max)

    #mass.setRange("fitRange_kmumu", mass_mid, mass_max)
    #mass.setRange("fitRange_pimumu", mass_min, mass_max)
    maxxmin = mass.getMin()
    maxxmax = mass.getMax()
    #mass.Print("V")

    cat = RooCategory("cat", "cat")
    #cat.defineType("jpsik")
    cat.defineType("kmumu", 0)
    cat.defineType("pimumu", 1)
    cat.defineType("jpsik", 2)
    cat.defineType("misid", 3)

    #if options.fitjpsik:
    #    simpdf.addPdf(jpsikpdf, "jpsik")
    #if options.fitmisid:
    #    simpdf.addPdf(totmisidpdf, "misid")


    c3 = ROOT.TCanvas("c3", "", 800, 600)
    name3 = "kmumufitresults"+ext+".pdf"
    c3.SaveAs(name3+"[")
    c1 = ROOT.TCanvas("c1", "", 800, 600)
    name2 = "pimumufitresults"+ext+".pdf"
    c2 = ROOT.TCanvas("c2", "", 800, 600)
    c2.SaveAs(name2+"[")
    wfname2 = "fitresults_workspace"+ext+".root"
    wf = ROOT.TFile(wfname2, "RECREATE")
    wss = []
    ress = []
    mass.setRange("full", maxxmin, maxxmax)
    mass.setRange("upper", 5400, maxxmax)

    valmisids = []
    errmisids = []
    valrhos = []
    errrhos = []
    valf0s = []
    errf0s = []

    for i, q in enumerate(qsqbins):
        qsqmin, qsqmax = q
        if options.bin > 0 and i != options.bin:
            print "skipping inb", i
            continue
        pimumupdf = RooAddPdf("pimumupdf", "", pipdfs, pivals)
        kmumupdf = RooAddPdf("kmumupdf", "",
                             RooArgList(sigpdf, bkgpdfs2[0], kmumupartrecopdf),
                             RooArgList(nkmumu, nkbkg, npartk)
                            )

        consts = RooArgSet(misidgaus, f0gaus, rhogaus)#, piexpgaus, kexpgaus
        simpdf = RooSimultaneous("simpdf"+str(i), "", cat)
        simpdf.addPdf(kmumupdf, "kmumu")
        simpdf.addPdf(pimumupdf, "pimumu")
        simbkgpdf = RooSimultaneous("simbkgpdf"+str(i), "", cat)
        simbkgpdf.addPdf(bkgpdfs2[0], "kmumu")
        simbkgpdf.addPdf(bkgpdfs3[0], "pimumu")


        c1name = "fitresults_bin%s_%s_%s" % (i, qsqmin, qsqmax)
        c1name = c1name.replace(".", "_")+".pdf"
        c1.SaveAs(c1name+"[")
        qsqcut = "(%.1f < qsq) && (qsq < %.1f)" % (qsqmin, qsqmax)
        print qsqcut
        subkmumudata = kmumudata.reduce(qsqcut)
        subpimumudata = pimumudata.reduce(qsqcut)
        subkmumudata.Print()
        subpimumudata.Print()

        combdata = RooDataSet("combdata"+str(i), "combdata", args,
                              RooFit.Index(cat),
                              RooFit.Import("kmumu", subkmumudata),
                              RooFit.Import("pimumu", subpimumudata),
                             )

        #starting parameters
        nparts.setVal(10)
        nparts.setConstant(False)
        npibkg.setVal(10)
        print i
        misidmean.setVal(misidvals[i])
        misidsigma.setVal(misiderrs[i])
        nmisid.setVal(misidvals[i])
        rhomean.setVal(rhovals[i])
        nrho.setVal(rhovals[i])
        rhosigma.setVal(rhoerrs[i])
        f0mean.setVal(f0vals[i])
        nf0.setVal(f0vals[i])
        f0sigma.setVal(f0errs[i])

        #set other values to starting parameters
        npimumu.setVal(subpimumudata.numEntries())
        nkmumu.setVal(subkmumudata.numEntries())
        nkbkg.setVal(0)
        npibkg.setVal(0)
        npartk.setVal(subkmumudata.numEntries()/2.)
        
        #fit upper mass sideband
        pibkgpar.setVal(-0.01)
        kbkgpar.setVal(-0.01)
        res = simbkgpdf.fitTo(combdata, RooFit.Save(True),
                              RooFit.Range("upper"))
        #if not options.all:
        res.Print()
        piexpmean.setVal(pibkgpar.getVal())
        piexpsigma.setVal(pibkgpar.getError())
        #
        kexpmean.setVal(kbkgpar.getVal())
        kexpsigma.setVal(kbkgpar.getError())
        #kumum parameter configuration
        partrecovars2[2].setConstant(True)
        partrecovars2[2].setVal(5020)
        partrecovars2[0].setVal(5044)
        partrecovars2[1].setVal(60)
        npartk.setVal(subkmumudata.numEntries()/2.)
        if i in [3, 4, 6]:
            partrecovars2[1].setVal(10)
        #if i == 3:
        #    #partrecovars2[2].setConstant(False)
        #    #partrecovars2[2].setMin(4800)
        #    #partrecovars2[0].setMin(4800)


        #if not options.all:
        #    piexpmean.Print()
        #    kexpmean.Print()
        #    piexpsigma.Print()
        #    kexpsigma.Print()
        #    misidgaus.Print()
        #    rhogaus.Print()
        #    f0gaus.Print()
        #    piexpgaus.Print()
        #    kexpgaus.Print()



        res = simpdf.fitTo(combdata,
                           RooFit.Extended(True),
                           RooFit.NumCPU(5),
                           RooFit.Save(True),
                           RooFit.Strategy(2),
                           #RooFit.Minimizer("Minuit2", "minimize"),
                           RooFit.ExternalConstraints(consts),
                           #RooFit.Range("full")
                          )
        if not options.all:
            res.Print("v")
        else :
            res.Print("v")
        c1.cd()
        mass.SetTitle("#it{m}(#pi^{+}#mu^{+}#mu^{-})")
        p = mass.frame(RooFit.Range("fitRange_pimumu"))
        subpimumudata.plotOn(p, RooFit.Binning(60))
        pimumupdf.plotOn(p, RooFit.LineColor(ROOT.kBlack))
        pimumupdf.plotOn(p, RooFit.Components(sigpdf.GetName()),
                         RooFit.LineStyle(ROOT.kDashed),
                         RooFit.LineColor(ROOT.kBlue))
        pimumupdf.plotOn(p, RooFit.Components(misIDpdf.GetName()),
                         RooFit.LineStyle(ROOT.kDashed),
                         RooFit.LineColor(ROOT.kMagenta+2))
        pimumupdf.plotOn(p, RooFit.Components(bkgpdfs3[0].GetName()),
                         RooFit.LineStyle(ROOT.kDashed),
                         RooFit.LineColor(ROOT.kRed))
        #pimumupdf.plotOn(p, RooFit.Components(pimumupartrecopdf.GetName()),
        #                 RooFit.LineStyle(ROOT.kDashed),
        #                 RooFit.LineColor(ROOT.kOrange-3))
        pimumupdf.plotOn(p, RooFit.Components(semileppdf.GetName()),
                         RooFit.LineStyle(ROOT.kDotted),
                         RooFit.LineColor(ROOT.kOrange-3))
        pimumupdf.plotOn(p, RooFit.Components(rhopdf.GetName()),
                         RooFit.LineStyle(ROOT.kDotted),
                         RooFit.LineColor(ROOT.kMagenta+2))
        pimumupdf.plotOn(p, RooFit.Components(f0pdf.GetName()),
                         RooFit.LineStyle(ROOT.kDotted),
                         RooFit.LineColor(ROOT.kBlue))

        c1.SetLogy(False)
        c1.cd()
        p.SetMinimum(0)
        p.Draw()
        c1.SaveAs(c1name)
        c1.SetLogy(True)
        c1.cd()
        p.SetMinimum(0.01)
        p.Draw()
        c1.SaveAs(c1name)
        c2.cd()
        p.SetMinimum(0)
        p.Draw()
        c2.SaveAs(name2)
        p.Delete()
        del p
        n = subkmumudata.sumEntries()
        mass.SetTitle("#it{m}(#it{K}^{+}#mu^{+}#mu^{-})")
        p = mass.frame(RooFit.Range("fitRange_kmumu"))
        subkmumudata.plotOn(p, RooFit.Binning(40))
        kmumupdf.plotOn(p, RooFit.LineColor(ROOT.kBlack)
                        , RooFit.Normalization(n, ROOT.RooAbsReal.NumEvent)
                       )
        kmumupdf.plotOn(p, RooFit.Components(sigpdf.GetName()),
                        RooFit.LineColor(ROOT.kBlue)
                        , RooFit.Normalization(n, ROOT.RooAbsReal.NumEvent)
                       )
        kmumupdf.plotOn(p, RooFit.Components(bkgpdfs2[0].GetName()),
                        RooFit.LineStyle(ROOT.kDashed),
                        RooFit.LineColor(ROOT.kRed)
                        , RooFit.Normalization(n, ROOT.RooAbsReal.NumEvent)
                       )
        kmumupdf.plotOn(p, RooFit.Components(kmumupartrecopdf.GetName()),
                        RooFit.LineStyle(ROOT.kDashed),
                        RooFit.LineColor(ROOT.kOrange-3))

        c1.SetLogy(False)
        c1.cd()
        p.SetMinimum(0)
        p.Draw()
        c1.SaveAs(c1name)
        c1.SetLogy(True)
        c1.cd()
        p.SetMinimum(0.01)
        p.Draw()
        c1.SaveAs(c1name)
        #dimuon inv mass distributiond
        c1.cd()
        c1.SaveAs(c1name+"]")
        c3.cd()
        p.SetMinimum(0)
        p.Draw()
        c3.SaveAs(name3)
        p
        p.Delete()
        del p

        print "saving to workspace"


        ws = RooWorkspace("workspace"+str(i))
        getattr(ws, 'import')(simpdf, ROOT.RooCmdArg())
        getattr(ws, 'import')(subpimumudata, ROOT.RooCmdArg())
        getattr(ws, 'import')(subkmumudata, ROOT.RooCmdArg())
        ws.importClassCode(ROOT.RooExpAndGauss.Class(), True)
        wss += [ws]    
        ress += [res]
        del subpimumudata
        del subkmumudata

        #summary plots
        valmisids += [nmisid.getVal()]
        errmisids += [nmisid.getError()]
        valrhos += [nrho.getVal()]
        errrhos += [nrho.getError()]
        valf0s += [nf0.getVal()]
        errf0s += [nf0.getError()]

        if not options.all:
            break
    c2.cd()
    c2.SaveAs(name2+"]")
    c3.cd()
    c3.SaveAs(name3+"]")


    #summary plots


    for i, res in enumerate(ress):
        print "bin", i, "result", res.status(), res.covQual() 
    
    wf.cd()
    for ws, res in zip(wss, ress):
        ws.Write() # ws.GetName(), ROOT.TObject.kOverwrite)
        res.Write()
    wf.Close()
    del wf


