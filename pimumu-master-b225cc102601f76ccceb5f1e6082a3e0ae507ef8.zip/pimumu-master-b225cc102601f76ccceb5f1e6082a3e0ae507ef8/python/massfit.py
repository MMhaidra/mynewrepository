#! /usr/bin/env python

import time
import ROOT

from ROOT import RooFit, RooRealVar, RooArgList, RooArgSet

ROOT.PyConfig.IgnoreCommandLineOptions = True

from pars import jpsikfilename, jpsipifilename, kmumufilename, pimumufilename
from pars import mass_min, mass_mid, mass_max


if __name__ == '__main__':

    start = time.time()
    print time.asctime(time.localtime())
    ROOT.gROOT.SetBatch(True)
    ROOT.gROOT.LoadMacro("RooExpAndGauss.cpp+")
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()

    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument("-d", "--debug", dest="debug", action="store_true",
                        default=False, help="testing")
    parser.add_argument("-p", "--poly", dest="poly", action="store_true",
                        default=False, help="poly background fit")
    parser.add_argument("-a", "--all", dest="all", action="store_true",
                        default=False, help="all")
    parser.add_argument("-m", "--fitmisid", dest="fitmisid",
                        action="store_true",
                        default=False, help="fit misid")
    parser.add_argument("-j", "--fitjpsik", dest="fitjpsik",
                        action="store_true",
                        default=False, help="fit fitjpsik")
    parser.add_argument("--fitjpsipi", dest="fitjpsipi",
                        action="store_true",
                        default=False, help="fit fitjpsipi")
    parser.add_argument("-b", "--bin", dest="bin", type=int, default=-1,
                        help="all")
    parser.add_argument("--numjpsik", dest="numjpsik", type=int, default=20000,
                        help="all")
    parser.add_argument("--min", dest="massmin", type=int, default=5040,
                        help="all")
    parser.add_argument("--max", dest="massmax", type=int, default=6000,
                        help="all")
    parser.add_argument("-c", "--create", dest="create", action='store_true',
                        default=False, help="create base workspace")
    parser.add_argument("-t", "--total", dest="total", action='store_true',
                        default=False, help="total")
    parser.add_argument("--minuit", dest="minuit", action='store_true',
                        default=False, help="use minuit2")
    #systematics
    parser.add_argument("-v", "--value", dest="bdtvalue", type=float, default=0.5, help="bdt cut value")
    parser.add_argument("-k", "--kaon", dest="kaoncut", type=float, default=0.4, help="kaon cut value")
    parser.add_argument("--sysrho", dest="sysrho", action='store_true', default=False, help="sysrho")
    parser.add_argument("--sysfz", dest="sysfz", action='store_true', default=False, help="sysfz")
    parser.add_argument("--syssl", dest="syssl", action='store_true', default=False, help="syssl")

    options = parser.parse_args()

    if not options.debug:
        ROOT.RooMsgService.instance().setGlobalKillBelow(RooFit.ERROR)
        ROOT.RooMsgService.instance().setSilentMode(True)


    wfname = "pimumu_workspace.root"
    if options.create:
        mass_min = options.massmin
        mass_max = options.massmax
        masstitle = "m_{K#mu^{+}#mu^{-}}"
        dileptitle = "m_{#mu^{+}#mu^{-}}^{2}"
        mass = RooRealVar("B_M", masstitle, 4800, 7000, "MeV/#it{c}^{2}")
        dilepton = RooRealVar("qsq", "q^{2}", 0, 25, "GeV^2/#it{c}^{4}")
        bdt = RooRealVar("BDT_4", "bdt", -1, 1, "")
        probnnk = RooRealVar("muplus_ProbNNk", "", 0, 1, "")
        args = ROOT.RooArgSet(mass, dilepton, bdt, probnnk)
        args.setName("args")
        print "creating workspace"
        wf = ROOT.TFile(wfname, "RECREATE")
        ws = ROOT.RooWorkspace("pimumu_workspace")
        getattr(ws, 'import')(args, ROOT.RooCmdArg() )
        ws.importClassCode(ROOT.RooExpAndGauss.Class(), True)
        ws.Write()
        wf.Close()
        exit()
        
    wf = ROOT.TFile(wfname, "UPDATE")
    ws = wf.Get("pimumu_workspace")
    mass = ws.var("B_M")
    qsq = ws.var("qsq")
    bdt = ws.var("BDT_4")
    probnnk = ws.var("muplus_ProbNNk")
    args = ROOT.RooArgSet(mass, qsq, bdt, probnnk)
    args.setName("args")
    mass.setMin(options.massmin)
    mass.setMax(options.massmax)
    mass.Print()




    if options.fitjpsik:
        #jpsik
        print "getting", jpsikfilename
        jpsikfile = ROOT.TFile(jpsikfilename, "READ")
        jpsiktree = jpsikfile.Get("DecayTree")
        jpsiktree.SetBranchStatus("*", 0)
        jpsiktree.SetBranchStatus("B_M", 1)
        jpsiktree.SetBranchStatus("qsq", 1)
        jpsikdata = ROOT.RooDataSet("jpsikdata", "", jpsiktree, args, "3.046<sqrt(qsq) && sqrt(qsq)<3.146")
        jpsikdata.Print()
        if options.hist:
            #jpsikhist = ROOT.RooDataHist("jpsihist", "", args, jpsikdata)
            jpsikhist = jpsikdata.reduce(RooFit.EventRange(0, options.numjpsik))
        else:
            jpsikhist = jpsikdata # .reduce(RooFit.EventRange(0, 20000))
        from fits import jpsikfit
        jpsikfit(mass, jpsikhist, ws)
        jpsikfile.Close()
        wf.cd()
        ws.Write()
    if options.fitjpsipi:
        #
        jpsipifile = ROOT.TFile(jpsipifilename, "READ")
        jpsipitree = jpsipifile.Get("DecayTree")
        jpsipitree.SetBranchStatus("*", 0)
        jpsipitree.SetBranchStatus("B_M", 1)
        jpsipitree.SetBranchStatus("qsq", 1)
        jpsipidata = ROOT.RooDataSet("jpsipidata", "", jpsipitree, args, "3.046<sqrt(qsq) && sqrt(qsq)<3.146")
        jpsipidata.Print()
        from fits import jpsipifit
        jpsipifit(mass, jpsipidata, options, ws)
        jpsipifile.Close()
        wf.cd()
        ws.Write()
    if options.total:
        bdtcut = "BDT_4>%g" % options.bdtvalue
        bdtcut += " && muplus_ProbNNk<%g"%options.kaoncut
        print bdtcut
        #config extension
        ext = ("_bdt%g_kpid%g" % (options.bdtvalue, options.kaoncut)).replace(".", "")
        if ext == "_bdt05_kpid04":
            ext = "" #default
        if options.sysrho:
            ext += "_sysrho"
        if options.sysfz:
            ext += "_sysfz"
        if options.syssl:
            ext += "_syssl"
        #kmumu
        print "getting", kmumufilename
        kmumufile = ROOT.TFile(kmumufilename, "READ")
        kmumutree = kmumufile.Get("DecayTree")
        kmumutree.SetBranchStatus("*", 0)
        kmumutree.SetBranchStatus("B_M", 1)
        kmumutree.SetBranchStatus("qsq", 1)
        kmumutree.SetBranchStatus("BDT_4", 1)
        kmumutree.SetBranchStatus("muplus_ProbNNk", 1)
        kmumudata = ROOT.RooDataSet("kmumudata", "", kmumutree, args, bdtcut)
        kmumudata.Print()
        print "getting", pimumufilename
        pimumufile = ROOT.TFile(pimumufilename, "READ")
        pimumutree = pimumufile.Get("DecayTree")
        pimumutree.SetBranchStatus("*", 0)
        pimumutree.SetBranchStatus("B_M", 1)
        pimumutree.SetBranchStatus("qsq", 1)
        pimumutree.SetBranchStatus("BDT_4", 1)
        pimumutree.SetBranchStatus("muplus_ProbNNk", 1)
        pimumudata = ROOT.RooDataSet("pimumudata", "", pimumutree, args, bdtcut)
        pimumudata.Print()

        from totalfit import runtotalfit
        runtotalfit(mass, args, ws, kmumudata, pimumudata, options, ext)
        kmumufile.Close()
        pimumufile.Close()
    wf.Close()

    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start


