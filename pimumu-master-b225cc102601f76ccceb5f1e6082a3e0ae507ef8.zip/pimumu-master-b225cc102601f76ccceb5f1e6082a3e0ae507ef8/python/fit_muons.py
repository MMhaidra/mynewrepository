
from fit_data_mc import  fit_jpsidata

from write_file import write_result


from create_dataset import DatasetCreator, construct_vars, jpsi_min, jpsi_mid, jpsi_max, mass_min, mass_mid, mass_max

from create_dataset import qsq_bins, jpsi_qsq_min, jpsi_qsq_mid, jpsi_qsq_max

from plot_pdfs import mmbinning

def fit_muons( options ) :

    #straight fit to data


    

    from ROOT import RooFit

    vars = construct_vars(True)

    mass = vars[0]
    """
    dc = DatasetCreator(  options.jpsimmsimfile,
                                    options.jpsimmsimtree,
                                    vars
                                    )

    jpsisim = dc.getDataset( jpsi_qsq_mid, jpsi_qsq_max, False, False )
    jpsisimpars,vals1 = fit_jpsidata(mass,jpsisim,None,None,"kjpsimm_simfit_oppo",True,False,None,False)
    dc = DatasetCreator(  options.mmsimfile,
                                    options.mmsimtree,
                                    vars
                                    )
     
    mmsim = dc.getDataset( 1.0, 6.0, False, False )
    mmsimpars,vals3 = fit_jpsidata(mass,mmsim,jpsisimpars,None,"kmm_simfit_from_cb",True,False,None,False)


    return"""
    # DATA
    extracut = None
    if options.year > 0 : 
        extracut = "year=="+str(options.year)
    if options.polarity != 0 : 
        extracut = "polarity=="+str(options.polarity)


 
    dc = DatasetCreator(  options.jpsimmdatafile,
                                    options.jpsimmdatatree,
                                    vars
                                    )

    jpsidata = dc.getDataset( jpsi_qsq_mid, jpsi_qsq_max, False, False, extracut )
    #mass.setBins(mmbinning)
    print "get binned clone ", mass.getBins()
    jpsihist = jpsidata #.binnedClone()
    print "binned clone done"
    #jpsihist = jpsidata.reduce(RooFit.EventRange(0,500000))
    #jpsihist = jpsidata.reduce("year==2012")
    jpsidatapars,vals1 = fit_jpsidata(mass,jpsihist,None,None,"kjpsimm_datafit_oppo",True,False,None,False)
    write_result("norm","kjpsimm",vals1)
    #jpsidatapars,vals1 = fit_jpsidata(mass,jpsidata,None,None,"kjpsimm_datafit_ipathia",False,True,None,False,True)
    #write_result("ipahia","kjpsimm",vals1)
    #jpsidatapars2,vals2 = fit_jpsidata(mass,jpsihist,None,None,"kjpsimm_datafit_double",False,True,None,False)
    #write_result("doublecb","kjpsimm",vals2)

    del dc

    
    dc = DatasetCreator(  options.mmdatafile,
                                    options.mmdatatree,
                                    vars
                                    )
     
    mmdata = dc.getDataset( 1.0, 6.0, False, False, extracut )
    #mmdata = mmdata.reduce("year==2012")
    mmdatapars,vals3 = fit_jpsidata(mass,mmdata,jpsidatapars,None,"kmm_datafit_from_cb",True,False,None,False)
    write_result("norm","kmm",vals3)
    #mmdatapars,vals4 = fit_jpsidata(mass,mmdata,jpsidatapars2,None,"kmm_datafit_double",False,True,None,False)
    #write_result("doublecb","kmm",vals4)
    
    del dc

    print "params"

    print jpsidatapars
    print mmdatapars

    return 


