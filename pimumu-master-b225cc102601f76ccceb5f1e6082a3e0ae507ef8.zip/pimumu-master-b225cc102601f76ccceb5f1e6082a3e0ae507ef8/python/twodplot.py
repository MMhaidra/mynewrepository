#! /usr/bin/env python
import ROOT

def plottwodlow():
    twomargin2 = 0.15  
    mass_min = 4500
    mass_max = 5700
    mumu_max = 4
    mumu_min = 0
    epem_max = 4
    epem_min = 0
    nbins_mass = 100
    nbins_mumu = 50
    nbins_epem = 50
    eename = "/home/alexshires/data/Pimm/allqsq/kmumu_11_12_selected.root"
    mmname = "/home/alexshires/data/Pimm/allqsq/pimumu_11_12_selected.root"
    fe = ROOT.TFile(eename)
    te = fe.Get("DecayTree")
    fm = ROOT.TFile(mmname)
    tm = fm.Get("DecayTree")
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()
    ROOT.gStyle.SetPadRightMargin(0.15)
    #ROOT.gStyle.SetPadTopMargin(topmargin)
    ROOT.gStyle.SetOptStat(0)
    ROOT.gStyle.SetPalette(51)
    c = ROOT.TCanvas("c", "", 800, 600)
    #c.SetLogz()
    h1 = ROOT.TH2D("he", "", nbins_mass, mass_min, mass_max, nbins_epem, epem_min, epem_max)
    h2 = ROOT.TH2D("hm", "", nbins_mass, mass_min, mass_max, nbins_mumu, mumu_min, mumu_max)
    h1.GetXaxis().SetTitle('#font[12]{m}(#it{#pi}^{+}#it{#mu}^{+}#it{#mu}^{#font[122]{-}})[MeV/#font[12]{c}^{2}]')
    h1.GetYaxis().SetTitle('#it{q}^{2} [GeV^{2}/#it{c}^{4}]')
    h2.GetXaxis().SetTitle('#font[12]{m}(#it{K}^{+}#it{#mu}^{+}#it{#mu}^{#font[122]{-}})[MeV/#font[12]{c}^{2}]')
    h2.GetYaxis().SetTitle('#it{q}^{2} [GeV^{2}/#it{c}^{4}]')
    #h1.GetZaxis().SetRangeUser(1, 1.1*h1.GetBinContent(h1.GetMaximumBin()))
    #h2.GetZaxis().SetRangeUser(1, 1.1*h2.GetBinContent(h2.GetMaximumBin()))
    tm.Draw("qsq:B_M>>he", "", "goff")
    te.Draw("qsq:B_M>>hm", "", "goff")
    h1.Draw("colz")
    #lhcbName1 = ROOT.TPaveText(0.15, 0.80, 0.35, 0.90, "BRNDC")
    #lhcbName1.AddText("LHCb")
    #lhcbName1.SetFillColor(0)
    #lhcbName1.SetBorderSize(0)
    #lhcbName1.Draw()
    c.SaveAs("pimumu2Dlow.pdf")
    c.SaveAs("pimumu2Dlow.png")
    c.SaveAs("pimumu2Dlow.eps")
    c.SaveAs("pimumu2Dlow.C")
    h2.Draw("colz")
    #lhcbName1 = ROOT.TPaveText(0.15, 0.80, 0.35, 0.90, "BRNDC")
    #lhcbName1.AddText("LHCb")
    #lhcbName1.SetFillColor(0)
    #lhcbName1.SetBorderSize(0)
    #lhcbName1.Draw()
    c.SaveAs("kmumu2Dlow.pdf")
    c.SaveAs("kmumu2Dlow.png")
    c.SaveAs("kmumu2Dlow.eps")
    c.SaveAs("kmumu2Dlow.C")
    fe.Close()
    fm.Close()


def plottwod(all=False):
    twomargin2 = 0.15  
    mass_min = 5000
    mass_max = 5700
    mumu_max = 25
    mumu_min = 0
    epem_max = 25
    epem_min = 0
    nbins_mass = 100
    nbins_mumu = 100
    nbins_epem = 100
    eename = "/home/alexshires/data/Pimm/allqsq/kmumu_11_12_selected.root"
    mmname = "/home/alexshires/data/Pimm/allqsq/pimumu_11_12_selected.root"
    fe = ROOT.TFile(eename)
    te = fe.Get("DecayTree")
    fm = ROOT.TFile(mmname)
    tm = fm.Get("DecayTree")
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()
    ROOT.gStyle.SetPadRightMargin(0.2)
    #ROOT.gStyle.SetPadTopMargin(topmargin)
    ROOT.gStyle.SetOptStat(0)
    ROOT.gStyle.SetPalette(51)
    ROOT.gStyle.SetTitleOffset(1.0,"Z")
    #ROOT.TGaxis.SetMaxDigits(2)
    c = ROOT.TCanvas("c", "", 800, 600)
    #c.SetLogz()
    h1 = ROOT.TH2D("he", "", nbins_mass, mass_min, mass_max, nbins_epem, epem_min, epem_max)
    h2 = ROOT.TH2D("hm", "", nbins_mass, mass_min, mass_max, nbins_mumu, mumu_min, mumu_max)
    h1.GetXaxis().SetTitle('#font[12]{m}(#it{#pi}^{+}#it{#mu}^{+}#it{#mu}^{-})[MeV/#font[12]{c}^{2}]')
    h1.GetYaxis().SetTitle('#it{q}^{2} [GeV^{2}/#it{c}^{4}]')
    h2.GetXaxis().SetTitle('#font[12]{m}(#it{K}^{+}#it{#mu}^{+}#it{#mu}^{-})[MeV/#font[12]{c}^{2}]')
    h2.GetYaxis().SetTitle('#it{q}^{2} [GeV^{2}/#it{c}^{4}]')
    h1.GetZaxis().SetTitle('Candidates')
    h2.GetZaxis().SetTitle('Candidates')
    #h1.GetZaxis().SetRangeUser(1, 1.1*h1.GetBinContent(h1.GetMaximumBin()))
    #h2.GetZaxis().SetRangeUser(1, 1.1*h2.GetBinContent(h2.GetMaximumBin()))
    tm.Draw("qsq:B_M>>he", "", "goff")
    te.Draw("qsq:B_M>>hm", "", "goff")
    h1.Draw("colz")
    lhcbName1 = ROOT.TPaveText(0.15, 0.80, 0.35, 0.90, "BRNDC")
    lhcbName1.AddText("LHCb")
    lhcbName1.SetFillColor(0)
    lhcbName1.SetBorderSize(0)
    lhcbName1.Draw()
    c.SaveAs("pimumu2D.pdf")
    if all:
        c.SaveAs("pimumu2D.png")
        c.SaveAs("pimumu2D.eps")
        c.SaveAs("pimumu2D.C")
    h2.Draw("colz")
    lhcbName1 = ROOT.TPaveText(0.15, 0.80, 0.35, 0.90, "BRNDC")
    lhcbName1.AddText("LHCb")
    lhcbName1.SetFillColor(0)
    lhcbName1.SetBorderSize(0)
    lhcbName1.Draw()
    c.SaveAs("kmumu2D.pdf")
    if all:
        c.SaveAs("kmumu2D.png")
        c.SaveAs("kmumu2D.eps")
        c.SaveAs("kmumu2D.C")
    fe.Close()
    fm.Close()

if __name__=='__main__':
    print " setting batch mode " 
    ROOT.gROOT.SetBatch(True)
    print " here goes " 
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument("-t", "--two", dest="two", action="store_true", default=False , help="testing")
    options = parser.parse_args()
    if options.two:
        plottwod()
        plottwodlow()

