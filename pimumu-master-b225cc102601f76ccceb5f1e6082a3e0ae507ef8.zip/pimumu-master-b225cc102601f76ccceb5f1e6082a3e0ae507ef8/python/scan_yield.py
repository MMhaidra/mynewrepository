import ROOT 

ROOT.gROOT.SetBatch(True)
ROOT.RooMsgService.instance().setGlobalKillBelow(ROOT.RooFit.ERROR)
ROOT.RooMsgService.instance().setSilentMode(True)
import sys


def getError(graph, npts):
    miny = 1.0E8
    maxy = 0
    x = ROOT.Double(0)
    y = ROOT.Double(0)
    for i in range(npts):
        graph.GetPoint(i, x, y)
        nx = float(x)
        ny = float(y)
        if ny < miny:
            miny = ny
            minx = float(x)
    low = -1
    high = -1
    for i in range(npts):
        gr.GetPoint(i, x, y)
        nx = float(x)
        ny = float(y)
        if low < 0 and ny < (miny + 1.0):
            low = nx
        gr.GetPoint(npts - i - 1, x, y)
        if high < 0 and ny < (miny + 1.0):
            high = nx
    down = minx - low
    upp = high - minx
    return (minx, down, upp)








def scan_yield(nsig, pdf, data, min=None, max=None, steps=1000):
    '''
    Profile likelihood of nsig paramater
    '''
    from ROOT import TGraph
    gr_likelihood = TGraph() 
    
    if min == None or min < nsig.getMin(): min = nsig.getMin()
    if max == None or max > nsig.getMax(): max = nsig.getMax()

    step = (max - min)/(1.0*steps)

    scan_point = [] 
    
    for i in range(0,steps):
        if (i%(steps/10) == 0):
            print i
        val = min + i*step
        
        nsig.setVal(val)
        nsig.setConstant(True)

        result = pdf.fitTo(data, ROOT.RooFit.Save(True), ROOT.RooFit.NumCPU(5))

        scan_point += [[val, 2.0*result.minNll()]]
        
        val += step


    minLL = float('inf')

    for point in scan_point:
        if point[1] < minLL: minLL = point[1]

    for i in range(0, len(scan_point)):
        #print i, scan_point[i][0], scan_point[i][1] - minLL
        gr_likelihood.SetPoint(i, scan_point[i][0], scan_point[i][1] - minLL)
    return gr_likelihood
    
from ROOT import TCanvas, TH1F
from lhcbStyle import setLHCbStyle
setLHCbStyle()

from pars import qsqbins

ef = open("errors.tex", 'w')

nevts = 500

from ROOT import TFile
outfile = TFile("pimumu_scan.root", 'RECREATE')
tfile = TFile.Open('fitresults_workspace.root', "READ")
can = TCanvas() 
can.SaveAs("pimumu_scan_nsig.pdf[")
for i, qsqmin in enumerate(qsqbins):
    twspc = tfile.Get("workspace" + str(i))
    #twspc.Print() 
    tdata = twspc.data("pimumudata")
    #args
    tspdf = twspc.pdf("pimumupdf") 
    tnsig = twspc.var('npimumu')
    nsigval = tnsig.getVal()
    args2 = twspc.allVars()
    #args2.Print()
    iter1 = args2.createIterator()
    while iter1:
        #print iter
        try:
            #iter.Print()
            iter1.setConstant(True)
            iter1.Next()
        except:
            break
    tnsig.setConstant(False)
    nmax = tnsig.getVal() * 1.6
    nmin = tnsig.getVal() * 0.4
    ntot = tnsig.getVal() * 2.0
    print "from", 0.9*tnsig.getVal(), 1.1* tnsig.getVal()
    can.cd()
    frame = TH1F('frame', 'frame', 1, 0, ntot)
    frame.SetStats(0)
    frame.SetXTitle('n_{sig}')
    frame.SetYTitle('-2 log L')
    frame.SetMinimum(0)
    frame.SetMaximum(2)
    frame.Draw()
    gr = scan_yield(tnsig, tspdf, tdata, nmin, nmax, nevts)
    gr.Draw('l')
    can.SaveAs("pimumu_scan_nsig.pdf")
    outfile.cd()
    gr.Write("pimumu_" + str(i) + "_likelihood")
    mid, down, up = getError(gr, nevts)
    line = "%g & %g & %g & %g & %g & %g \\\\\n" % \
            (i, nsigval, tnsig.getError(), mid, down, up)
    ef.write(line)
    
can.SaveAs("pimumu_scan_nsig.pdf]")
outfile.Close()

