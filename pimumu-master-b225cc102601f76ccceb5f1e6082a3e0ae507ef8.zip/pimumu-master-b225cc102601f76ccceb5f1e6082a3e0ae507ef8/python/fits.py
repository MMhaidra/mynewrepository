import ROOT
from ROOT import RooRealVar, RooAddPdf, RooFit, RooArgList

from fitmodels import oppoCB, expo, expgauss


def jpsikfit(mass, jpsikdata, workspace):
    sigpdfs, sigpars = oppoCB(mass, "jpsik")
    bkgpdfs1, bkgpars1 = expo(mass, "jpsik")
    partrecopdfs, partrecovars = expgauss(mass, "jpsik")
    partrecovars[2].setVal(5110)
    partrecovars[2].setConstant(True)

    sigpars[0].setVal(5283)
    sigpars[1].setVal(25)
    sigpars[2].setVal(4.6)
    sigpars[3].setVal(-5)
    sigpars[4].setVal(1)
    sigpars[5].setVal(13)
    sigpars[6].setVal(0.42)
    sigpars[7].setVal(14)

    for sigpar in sigpars:
        sigpar.Print()
    
    jpsipifile = ROOT.TFile("jpsipi_workspace.root")
    jpsipiws = jpsipifile.Get("jpsipi")
    #ijpsipipdf = jpsipiws.pdf("jpsipiaskcb_cbshape1")
    #ijpsipipdf.Print()

    pimean = jpsipiws.var("jpsipicb_mean")
    pis = jpsipiws.var("jpsipicb_sig1")
    pin = jpsipiws.var("jpsipicb_n1")
    pia = jpsipiws.var("jpsipicb_alpha1")
    from ROOT import RooCBShape
    jpsipipdf = RooCBShape("jpsipipdf", "", mass, pimean, pis, pia, pin)

    print jpsipipdf

    sigpdf = sigpdfs[0]
    bkgpdf1 = bkgpdfs1[0]
    prpdf = partrecopdfs[0]


    ntot = jpsikdata.sumEntries()
    numsig = RooRealVar("njpsik", "", 0, ntot)
    numbkg1 = RooRealVar("njpsikbkg", "", 0, ntot)
    numpart = RooRealVar("njpsikpart", "", 0, ntot)
    numjpsipi = RooRealVar("njpsipi", "", 0, 2000)
    totpdf = RooAddPdf("totpdf", "", RooArgList(sigpdf, bkgpdf1, prpdf, jpsipipdf),
                       RooArgList(numsig, numbkg1, numpart, numjpsipi))

    res = totpdf.fitTo(jpsikdata,
                       RooFit.Extended(True),
                       RooFit.NumCPU(6),
                       RooFit.Save(True),
                       RooFit.Strategy(2),
                       #RooFit.Minimizer("Minuit2", "minimize")
                      )

    res.Print("v")

    c = ROOT.TCanvas("c", "", 800, 600)
    c.SaveAs("jpsiktest.pdf[")
    mass.SetTitle("#it{m}(#it{K}^{+}#mu^{+}#mu^{-})")
    p = mass.frame()
    jpsikdata.plotOn(p, RooFit.Binning(70))
    totpdf.plotOn(p, RooFit.LineColor(ROOT.kBlack))
    totpdf.plotOn(p, RooFit.Components(sigpdf.GetName()),
                  RooFit.LineColor(ROOT.kBlue))
    totpdf.plotOn(p, RooFit.Components(bkgpdf1.GetName()),
                  RooFit.LineColor(ROOT.kRed))
    totpdf.plotOn(p, RooFit.Components(prpdf.GetName()),
                  RooFit.LineColor(ROOT.kGreen))
    totpdf.plotOn(p, RooFit.Components(jpsipipdf.GetName()),
                  RooFit.LineColor(ROOT.kGreen))
    p.SetMinimum(0)
    p.Draw()
    c.SaveAs("jpsiktest.pdf")
    p.SetMinimum(1)
    c.SetLogy()
    p.Draw()
    c.SaveAs("jpsiktest.pdf")
    c.SaveAs("jpsiktest.pdf]")

    #fix parameters, save in workspace
    for par in sigpars:
        #if "nval" in par.GetName():
        par.setConstant(True)
        #if "alpha" in par.GetName():
        #    par.setConstant(True)
    #totpdf.Print("v")

    wfjname = "jpsikmassfit.root"
    wfj = ROOT.TFile(wfjname, "RECREATE")
    wsj = ROOT.RooWorkspace("jpsikworkspace")
    getattr(wsj, 'import')(totpdf, ROOT.RooCmdArg())
    getattr(wsj, 'import')(jpsikdata, ROOT.RooCmdArg())
    wsj.importClassCode(ROOT.RooExpAndGauss.Class(), True)
    wsj.Write() # ws.GetName(), ROOT.TObject.kOverwrite)
    res.Write()
    wfj.Close()
    del wsj
    del wfj

    getattr(workspace, 'import')(sigpdf, ROOT.RooCmdArg())



def jpsipifit(mass, jpsipidata, options, workspace=None):
    sigpdfs, sigpars = oppoCB(mass, "jpsipi")
    bkgpdfs, bkgpars = expo(mass, "jpsipi")
    partrecopdfs, partrecovars = expgauss(mass, "jpsipi")
    sigpdf = sigpdfs[0]
    bkgpdf = bkgpdfs[0]
    prpdf = partrecopdfs[0]
    from ROOT import RooCBShape
    misIDmean = RooRealVar("misIDmean", "", 5228.6, 5100, 5250)
    misIDsigma = RooRealVar("misIDsigma", "", 24, 0, 50)
    misIDalpha = RooRealVar("misIDalpha", "", 0.46, 0, 10)
    misIDnval = RooRealVar("misIDnval", "", 15, 0, 30)
    misIDpdf = RooCBShape("misID", "", mass, misIDmean,
                          misIDsigma, misIDalpha, misIDnval)
    misIDmean.setConstant(not options.fitmisid)
    misIDsigma.setConstant(not options.fitmisid)
    misIDalpha.setConstant(not options.fitmisid)
    misIDnval.setConstant(not options.fitmisid)
    #contributions
    #wfbkg = ROOT.TFile("bkgs_workspace.root", "READ")
    #wsbkg = wfbkg.Get("bkgs")
    f0pdf = workspace.pdf("f0keyspdf")
    rhopdf = workspace.pdf("rhokeyspdf")
    f0pdf.Print()
    rhopdf.Print()
    ntot = jpsipidata.sumEntries()
    numsig = RooRealVar("njpsipi", "", 0, ntot)
    numbkg = RooRealVar("njpsipibkg", "", 100, 0, ntot)
    numpart = RooRealVar("njpsipipart", "", 100, 0, ntot)
    nummisid = RooRealVar("nmisid", "", 100, 0, ntot)
    numf0 = RooRealVar("nf0mumu", "", 100, 0, jpsipidata.sumEntries())
    numrho = RooRealVar("nrhomumu", "", 100, 0, jpsipidata.sumEntries())
    pdfs = RooArgList(sigpdf, bkgpdf, prpdf, misIDpdf, f0pdf, rhopdf)
    vals = RooArgList(numsig, numbkg, numpart, nummisid, numf0, numrho)
    totpdf = RooAddPdf("totpdf", "", pdfs, vals)
    #constraints?
    misidmean = RooRealVar("misidcmean", "", 6900)
    misidsigma = RooRealVar("misidcsigma", "", 1000.1)
    misidgaus = ROOT.RooGaussian("misidcgaus", "", nummisid,
                                 misidmean, misidsigma)
    f0mean = RooRealVar("f0cmean", "", 2000)
    f0sigma = RooRealVar("f0csigma", "", 500)
    f0gaus = ROOT.RooGaussian("f0cgaus", "", numf0,
                              f0mean, f0sigma)
    rhomean = RooRealVar("rhocmean", "", 1600)
    rhosigma = RooRealVar("rhocsigma", "", 500)
    rhogaus = ROOT.RooGaussian("rhocgaus", "", numrho,
                               rhomean, rhosigma)
    from ROOT import RooArgSet
    consts = RooArgSet(misidgaus, f0gaus, rhogaus)

    res = totpdf.fitTo(jpsipidata,
                       RooFit.Extended(True),
                       RooFit.NumCPU(5),
                       RooFit.Save(True),
                       RooFit.Strategy(2),
                       #RooFit.ExternalConstraints(consts)
                      )
    res.Print()

    c = ROOT.TCanvas("c", "", 800, 600)
    c.SaveAs("jpsipitest.pdf[")
    mass.SetTitle("#it{m}(#it{#pi}^{+}#mu^{+}#mu^{-})")
    p = mass.frame()
    jpsipidata.plotOn(p, RooFit.Binning(70))
    totpdf.plotOn(p, RooFit.LineColor(ROOT.kBlack))
    totpdf.plotOn(p, RooFit.Components(sigpdf.GetName()),
                  RooFit.LineStyle(ROOT.kDashed),
                  RooFit.LineColor(ROOT.kBlue))
    totpdf.plotOn(p, RooFit.Components(bkgpdf.GetName()),
                  RooFit.LineStyle(ROOT.kDotted),
                  RooFit.LineColor(ROOT.kRed))
    totpdf.plotOn(p, RooFit.Components(misIDpdf.GetName()),
                  RooFit.LineColor(ROOT.kMagenta+2))
    totpdf.plotOn(p, RooFit.Components(prpdf.GetName()),
                  RooFit.LineStyle(ROOT.kDashed),
                  RooFit.LineColor(ROOT.kGreen))
    totpdf.plotOn(p, RooFit.Components(f0pdf.GetName()),
                  RooFit.LineStyle(ROOT.kDashed),
                  RooFit.LineColor(ROOT.kBlue))
    totpdf.plotOn(p, RooFit.Components(rhopdf.GetName()),
                  RooFit.LineStyle(ROOT.kDashed),
                  RooFit.LineColor(ROOT.kRed))
    p.SetMinimum(0)
    p.Draw()
    c.SaveAs("jpsipitest.pdf")
    p.SetMinimum(1)
    c.SetLogy()
    p.Draw()
    c.SaveAs("jpsipitest.pdf")
    c.SaveAs("jpsipitest.pdf]")

    #fix parameters, save in workspace
    for par in sigpars:
        #if "nval" in par.GetName():
        par.setConstant(True)
        #if "alpha" in par.GetName():
        #    par.setConstant(True)
    #totpdf.Print("v")

    wfjname = "jpsipimassfit.root"
    wfj = ROOT.TFile(wfjname, "RECREATE")
    wsj = ROOT.RooWorkspace("jpsipiworkspace")
    getattr(wsj, 'import')(totpdf, ROOT.RooCmdArg())
    getattr(wsj, 'import')(jpsipidata, ROOT.RooCmdArg())
    wsj.Write() # ws.GetName(), ROOT.TObject.kOverwrite)
    res.Write()
    wfj.Close()
    del wsj
    del wfj

    getattr(workspace, 'import')(totpdf, ROOT.RooCmdArg())


