#! /usr/bin/env python

import ROOT
if __name__ == '__main__':
    wfname = "pimumu_workspace.root"
    ROOT.gROOT.SetBatch(True)
    wf = ROOT.TFile(wfname, "READ")
    ws = wf.Get("pimumu_workspace")
    mass = ws.var("B_M")
    pdfs = ws.allPdfs()
    iter = pdfs.createIterator()
    var = iter.Next()
    c = ROOT.TCanvas("c", "", 800, 600)
    name = "pimumu_workspace_pdfs.pdf"
    c.SaveAs(name+"[")
    while var:
        print var.GetName()
        p = mass.frame()
        var.plotOn(p)
        p.SetTitle(var.GetName())
        p.Draw()
        c.SaveAs(name)
        var = iter.Next()
    c.SaveAs(name+"]")



