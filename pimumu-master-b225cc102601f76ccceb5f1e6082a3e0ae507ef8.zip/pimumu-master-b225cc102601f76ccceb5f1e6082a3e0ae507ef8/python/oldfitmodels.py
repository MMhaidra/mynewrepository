import ROOT

mean_low = 4900
mean_min = 5178
mean_max = 5380
mean_mid = 5284

sig1_min = 5
sig1_max = 100
sig1_mid = 17

sig2_min = 1
sig2_max = 50
sig2_mid = 17.5

alpha_min = 1.1
alpha_max = 10
alpha_mid = 1.4

nval_min = 0
nval_max = 50
nval_mid = 25


RooFit = ROOT.RooFit
RooRealVar = ROOT.RooRealVar
RooArgList = ROOT.RooArgList
RooArgSet = ROOT.RooArgSet
RooCBShape = ROOT.RooCBShape
RooAddPdf = ROOT.RooAddPdf
RooExponential = ROOT.RooExponential


def expo(massvar, name = ""):
    expl = RooRealVar(name+"expl", "", -0.005, -0.1, 0)
    exp = RooExponential(name+"exppdf", "", massvar, expl)
    return ([exp], [expl])

def expgauss(mass, name=""):
    ROOT.gROOT.LoadMacro("RooExpAndGauss.cpp++")
    mean = RooRealVar(name+"expg_mean", "", 5070, mean_low, 5150)
    sigma = RooRealVar(name+"expg_sigma", "", 30, 0, 60)
    trans = RooRealVar(name+"expg_trans", "", 5000, mean_low, 5150)
    sigshape1 = ROOT.RooExpAndGauss(name+"bkgexpgausspdf", "",
                                    mass, mean, sigma, trans)
    vars1 = [mean, sigma, trans]
    pdfs = [sigshape1]
    return (pdfs, vars1)




def oppoCB(massvar, name=""):
    #same sig, diff crystal ball pars, one n fixed
    mean = RooRealVar(name+"cb_mean", "", mean_mid, mean_min, mean_max)
    sig1 = RooRealVar(name+"cb_sig1", "", sig1_mid, sig1_min, sig1_max)
    sig2 = RooRealVar(name+"cb_sig2", "", sig2_mid, sig2_min, sig2_max)
    #sig2_scale = RooRealVar(name+"cb_sig2_scale", "", 
    #                        sig2_mid, sig2_min, sig2_max)
    #sig2 = RooFormulaVar(name+"cb_sig2", "", "@0*@1", 
    #                     RooArgList(sig1, sig2_scale))
    alpha1 = RooRealVar(name+"cb_alpha1", "", alpha_mid, 
                        alpha_min, alpha_max)
    alpha2 = RooRealVar(name+"cb_alpha2", "", -1.0*alpha_mid, 
                        -1.0*alpha_max, -1.0*alpha_min)
    nval1 = RooRealVar(name+"cb_n1", "", 25) # nval_mid, nval_min, 50)
    nval2 = RooRealVar(name+"cb_n2", "", 35) # nval_mid, nval_min, 50)
    sigshape1 = RooCBShape(name+"cb_cbshape1", "", massvar, 
                           mean, sig1, alpha1, nval1)
    sigshape2 = RooCBShape(name+"cb_cbshape2", "", massvar, 
                           mean, sig2, alpha2, nval2)
    frac_cb = RooRealVar(name+"frac_cb", "", 0, 1)
    totsig = RooAddPdf(name+"sigpdf", "totsig", 
                       RooArgList(sigshape1, sigshape2), RooArgList(frac_cb))

    variables = [mean, sig1, alpha1, alpha2, nval1, nval2,
                 frac_cb, sig2, nval2]#, sig2_scale]
    ppdfs = [totsig, sigshape1, sigshape2]
    return (ppdfs, variables)
