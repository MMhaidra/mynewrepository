#! /usr/bin/env python


import ROOT

from tree import TTree


"""phase space correction"""
m_mu = 0.1057
m_K = 0.4977
m_pi = 0.1354
m_nu = 0.0
m_B = 5.2780
m_D = 1.800

from math import sqrt

def generateK(n, s):
    from ROOT import TGenPhaseSpace, TLorentzVector, TH1D, TH2D
    pB = TLorentzVector(0.0, 0.0, 30.0, sqrt(30.0*30.0 + 5.279*5.279))
    masses1 = [m_mu, m_nu, m_D]
    masses2 = [m_mu, m_nu, m_pi]
    masses3 = [m_mu, m_nu, m_K]
    import array
    masses1arr = array.array('d', masses1)
    masses2arr = array.array('d', masses2)
    masses3arr = array.array('d', masses3)

    ext = "_%s_%s" % ( n, s)


    event1 = TGenPhaseSpace()
    event2 = TGenPhaseSpace()
    event3 = TGenPhaseSpace()
    event1.SetDecay(pB, 3, masses1arr)
    from ROOT import TFile, TTree
    f = TFile("genleveldists"+ext+".root", "RECREATE")
    t = TTree("GenLevelTree", "GenLevelTree")
    import array
    mkarr = array.array('f', [0])
    mpiarr = array.array('f', [0])
    weight1arr = array.array('f', [0])
    weight2arr = array.array('f', [0])
    weight3arr = array.array('f', [0])
    t.Branch("weightBD", weight1arr, "weightBD/F")
    t.Branch("weightDk", weight2arr, "weightDk/F")
    t.Branch("weightDpi", weight3arr, "weightDpi/F")
    t.Branch("mass_Kmumu", mkarr, "weightDpi/F")
    t.Branch("mass_pimumu", mpiarr, "weightDpi/F")
    hist1 = TH1D("hist1", "", 70, 4.700, 5.400)
    hist2 = TH1D("hist2", "", 70, 4.700, 5.400)
    nmax = n # 1000000
    for i in xrange(nmax):
        if i%(nmax/100) == 0:
            print i
        weight = event1.Generate()
        mu1 = event1.GetDecay(0)
        D = event1.GetDecay(2)
        #basic kinematic cuts?
        event2.SetDecay(D, 3, masses2arr)
        event3.SetDecay(D, 3, masses3arr)

        wgt2 = event2.Generate()
        wgt3 = event3.Generate()
        mu2 = event2.GetDecay(0)
        mu3 = event3.GetDecay(0)
        k = event2.GetDecay(2)
        pi = event3.GetDecay(2)

        #Bmasses
        Bm1 = mu1 + mu2 + k
        Bm2 = mu1 + mu3 + pi


        if Bm1.M() < 4.5 or Bm2.M() < 4.5:
            continue
        #print Bm1.M(), Bm2.M()

        hist1.Fill(Bm1.M(), weight*wgt2)
        hist2.Fill(Bm2.M(), weight*wgt3)

        weight1arr[0] = weight
        weight2arr[0] = wgt2
        weight3arr[0] = wgt3
        mkarr[0] = Bm1.M()
        mpiarr[0] = Bm2.M()

        t.Fill()
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()
    from ROOT import TCanvas
    c = TCanvas("c", "", 800, 600)
    hist1.GetXaxis().SetTitle("#it{m}(#it{K}#mu#mu)")
    hist2.GetXaxis().SetTitle("#it{m}(#pi#mu#mu)")
    hist1.SetLineColor(ROOT.kBlack)
    hist1.SetMarkerColor(ROOT.kBlack)
    hist2.SetLineColor(ROOT.kBlue)
    hist2.SetMarkerColor(ROOT.kBlue)
    hist1.Draw("e")
    hist2.Draw("esame")
    c.SaveAs("comp_semi_masses"+ext+".pdf")
    #save histograms

    #create ratio
    t.Write()
    f.Close()


if __name__ == '__main__':
    import time
    start = time.time()
    print time.asctime(time.localtime())
    ROOT.gROOT.SetBatch(True)
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument("-d", "--debug", dest="debug", action="store_true",
                        default=False, help="testing")
    parser.add_argument("-s", "--seed", dest="seed", type=int,
                        default=1, help="seed")
    parser.add_argument("-n", "--nevts", dest="nevts", type=int,
                        default=1E6, help="num events")
    parser.add_argument("-g", "--gen", dest="gen", action='store_true',
                        default=False, help="generate")
    parser.add_argument("-w", "--weight", dest="weight", action='store_true',
                        default=False, help="weight")
    parser.add_argument("-f", "--file", dest="file", default=None, 
                        type=str, help="filename")
    parser.add_argument("-t", "--tree", dest="tree", default="DecayTree", 
                        type=str, help="treename")

    options = parser.parse_args()

    from ROOT import TRandom3

    ROOT.gRandom = TRandom3(options.seed)

    if options.gen:
        generateK(options.nevts, options.seed)
    if options.weight:
        from ROOT import TFile
        f = TFile(options.file, "READ")
        tree = f.Get(options.tree)
        nfname = options.file[:-5]+"_weight.root"
        nf = TFile(nfname, "RECREATE")
        tree.SetBranchStatus("*", 1)
        nt = tree.CloneTree(-1, "fast")
        nt.SetBranchStatus("*", 0)
        nt.SetBranchStatus("B_M", 1)
        #open file
        gf = TFile("genleveldists_%s_%s.root" % (options.nevts, options.seed), "READ")
        gt = gf.Get("GenLevelTree")
        #draw hist
        from ROOT import TH1D, TCanvas
        khist = TH1D("khist", "", 50, 4.8, 5.4)
        pihist = TH1D("pihist", "", 50, 4.8, 5.4)
        rhist = TH1D("rhist", "", 50, 4.8, 5.4)
        khist.Sumw2()
        pihist.Sumw2()
        rhist.Sumw2()
        gt.Draw("mass_Kmumu>>khist", "weightBD*weightDk")
        gt.Draw("mass_pimumu>>pihist", "weightBD*weightDpi")
        rhist.Divide(pihist,khist)
        c = TCanvas("c", "", 800, 600)
        c.SaveAs("semilephists.pdf[")
        khist.Draw("e")
        c.SaveAs("semilephists.pdf")
        pihist.Draw("e")
        c.SaveAs("semilephists.pdf")
        rhist.Draw("e")
        c.SaveAs("semilephists.pdf")
        c.SaveAs("semilephists.pdf]")
        #loop
        n = tree.GetEntries()
        res_tuple = {}
        w = 0
        for i in range(n):
            if i%(n/10) == 0:
                print i, w, tree.B_M
            nt.GetEntry(i)
            w = 0
            if tree.B_M > 4800:
                w = rhist.GetBinContent(rhist.FindBin(nt.B_M*1E-3))
            nt.AddVar(w, "weight", res_tuple)
            nt.FillVars(res_tuple)
        nt.SetBranchStatus("*", 1)
        nf.cd()
        nt.Write()
        nf.Close()
        f.Close()
        gf.Close()

    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start


