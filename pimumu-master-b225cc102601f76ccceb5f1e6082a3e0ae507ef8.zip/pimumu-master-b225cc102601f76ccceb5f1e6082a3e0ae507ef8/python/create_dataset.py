import os,sys,math,ROOT,array


# converts TTree into RooDataSet using specified configuration

#binning scheme

qsq_bins = [ (0.0,1.0), (1.0, 6.0), (6.0,11.0), (11.0,15.0), (14.5, 25.0) ] 
nonres_bins = [ (0.0,1.0), (1.0, 6.0),  (15.0, 25.0) ] 

#definitions

jpsi_min = 2450.
jpsi_mid = 2946.
jpsi_max = 3176.
ee_min = 1000.
ee_max = 2450.


jpsi_qsq_min = 6.0 # jpsi_min*jpsi_min / 1.0E6 ;
jpsi_qsq_mid = 8.68 # jpsi_mid*jpsi_mid / 1.0E6 ;
jpsi_qsq_max = 10.09 # jpsi_max*jpsi_max / 1.0E6 ;
    
    
spd_min = 0.
spd_max = 800.

const_min = 0.
const_max = 15000.

mass_min = 4880
mass_mid = 5175
mass_max = 5700

jpsimmcut = "B_M>%s && B_M<%s && qsq_free>%s && qsq_free<%s" % ( mass_mid, mass_max, jpsi_mid, jpsi_max ) 
jpsieecut = "B_M>%s && B_M<%s && qsq_free>%s && qsq_free<%s && B_FullFit_Mass>%s && B_FullFit_Mass<%s" % ( mass_min, mass_max, jpsi_min, jpsi_max , mass_mid, mass_max ) 
mmcut = "B_M>%s && B_M<%s && qsq_free>%s && qsq_free<%s" % ( mass_mid, mass_max, ee_min, ee_max ) 
eecut = "B_M>%s && B_M<%s && qsq_free>%s && qsq_free<%s" % ( mass_min, mass_max, ee_min, ee_max ) 

electoscut = "(B_L0ElectronDecision_TOS==1)"
hadtoscut = "(B_L0ElectronDecision_TOS==0 && B_L0HadronDecision_TOS==1)"
tiscut = "(B_L0ElectronDecision_TOS==0 && B_L0HadronDecision_TOS==0)" #&& (B_L0ElectronDecision_TIS==1 || B_L0HadronDecision_TIS==1 || B_L0MuonDecision_TIS==1 || B_L0PhotonDecision_TIS==1))"
#tiscut = "(B_L0ElectronDecision_TIS==1 || B_L0HadronDecision_TIS==1 || B_L0MuonDecision_TIS==1 || B_L0PhotonDecision_TIS==1))"

bremzerocut = "(eplus_HasBremAdded+eminus_HasBremAdded==0)"
bremonecut = "(eplus_HasBremAdded+eminus_HasBremAdded==1)"
bremtwocut = "(eplus_HasBremAdded+eminus_HasBremAdded==2)"

mptcut = "Kplus_PT>3000 && muplus_PT>3000 && muminus_PT>3000"
eptcut = "Kplus_PT>3000 && eplus_PT>3000 && eminus_PT>3000"

def construct_vars( muons=False ) :

    from ROOT import RooRealVar

    masstitle = "m_{Ke^{+}e^{-}}"
    dileptitle = "m_{e^{+}e^{-}}^{2}"
    cmasstitle = "m_{Ke^{+}e^{-}}^{const}"
    if muons : 
        masstitle = "m_{K#mu^{+}#mu^{-}}"
        dileptitle = "m_{#mu^{+}#mu^{-}}^{2}"
        cmasstitle = "m_{K#mu^{+}#mu^{-}}^{const}"

    if muons :
        mass = RooRealVar("B_M",masstitle,mass_mid,mass_max,"MeV/c^{2}")
    else :
        mass = RooRealVar("B_M",masstitle,mass_min,mass_max,"MeV/c^{2}")

    #spdhits = RooRealVar("nSPDHits","SPD multi",spd_min,spd_max,"")
    gpstime = RooRealVar("year","year",2010,2020)
    pol = RooRealVar("polarity","polarity",-2,2)
    weight = RooRealVar("kin_weight","kienamtic weight",0,100,"")
    constmass = RooRealVar("B_FullFit_Mass",cmasstitle,const_min,const_max,"MeV/c^{2}")
    dilepton = RooRealVar("qsq_free",dileptitle,0,25,"MeV^2/c^{4}")
    epbrem = RooRealVar("eplus_HasBremAdded","electron multi",0,3,"")
    embrem = RooRealVar("eminus_HasBremAdded","electron multi",0,3,"")
    electos = RooRealVar("B_L0ElectronDecision_TOS","electron TOS",0,3,"")
    hadtos = RooRealVar("B_L0HadronDecision_TOS","hadron TOS",0,3,"")
    kaonpt = RooRealVar("Kplus_PT","",0,25000,"MeV/c^{2}")
    if muons :
        lppt = RooRealVar("muplus_PT","",0,25000,"MeV/c^{2}")
        lmpt = RooRealVar("muminus_PT","",0,25000,"MeV/c^{2}")
    else :
        lppt = RooRealVar("eplus_PT","",0,25000,"MeV/c^{2}")
        lmpt = RooRealVar("eminus_PT","",0,25000,"MeV/c^{2}")

    if muons: 
        return [ mass, constmass, dilepton, gpstime, pol, weight ]    
    else :
        return [ mass, constmass, dilepton, epbrem, embrem, electos, hadtos, gpstime, pol , weight ]    




class DatasetCreator :

    file = None
    tree = None
    vars = None
    args = None
    mass = None
    weight = None
    name = "test"
    muons = False


    #requires variables already

    def __init__(self, filename , treename, vars, _muons=True ) :
        self.file = ROOT.TFile ( filename,"READ" ) 
        if not self.file.IsOpen() :
            print "file %s failed to open"%file
            return 
        self.file.Print()
        self.tree = self.file.Get( treename ) 
        if not self.tree :
            print "no tree %s in file %s "%(treename,filename)
    
        self.vars = vars
        self.mass = vars[0]
        from ROOT import RooArgSet
        self.args = RooArgSet() 
        #add everything but weight to argset
        for var in self.vars[:-1] :
            self.args.add( var ) 
        self.weight = vars[-1]
        self.name = filename+treename
        self.muons = _muons


    def __del__(self) :
        if self.file:
            self.file.Close()


    def getDataset(self, qsq_min = 1.0, qsq_max = 6.0 , weight = False,  const = True, extracut = None ): 

        if not self.tree :
            return None
  
        #configure cut
        from math import sqrt
        cut = "qsq_free>%s && qsq_free<%s" % ( qsq_min , qsq_max )
        if self.muons :
            cut = "qsq_free>%s && qsq_free<%s" % ( qsq_min, qsq_max )
        if const :
            cut += " && B_FullFit_Mass>%s && B_FullFit_Mass<%s"%(mass_mid,mass_max)
        if extracut:
            cut += " && " + extracut
        print cut
        #if self.muons:
        #    cut += " && " + mptcut 
        #else :
        #    cut += " && " + eptcut 

        data = None
        from ROOT import RooDataSet,RooArgSet
        if not weight :
            tmpdata = RooDataSet("data","data"
                    , self.tree
                    , self.args 
                    , cut
                    )
            n = tmpdata.numEntries()
            data = RooDataSet("data","data"
                    , self.args
                    )
            frac = n/10
            factor = 3
            for i in xrange(n):
                #hack to select 10% of data
                if (i>(factor*frac)) and (i < (factor+1)*frac) :
                    continue
                args = tmpdata.get(i)
                data.add( args ) 


        else :
            self.args.add( self.weight )
            tmpdata = RooDataSet("tmpdata"+self.name,""
                    , self.tree
                    , RooArgSet( self.args ) 
                    , cut
                    )
            #now calculate sum of weights
            n = tmpdata.numEntries()
            sumw = 0.0
            weightname = self.weight.GetName()
            for i in xrange( n ) :
                sumw += tmpdata.get(i).getRealValue( weightname )
            scale = float(n)/sumw
            scale *= 1.0
            print "scale %f = %f / %f"%(scale,n,sumw)
            data = RooDataSet("data","data"
                    , self.args
                    , ROOT.RooFit.WeightVar( weightname ) 
                    )
            for i in xrange(n):
                #hack to select 10% of data
                args = tmpdata.get(i)
                wgt = args.getRealValue( weightname ) 
                data.add( args, wgt * scale ) 

        print "data from getDataset"
        data.Print()
        return data

