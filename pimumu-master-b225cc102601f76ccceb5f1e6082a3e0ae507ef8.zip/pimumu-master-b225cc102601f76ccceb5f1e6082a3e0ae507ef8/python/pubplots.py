#! /usr/bin/env python


import ROOT
from ROOT import RooFit

from twodplot import plottwod

jpsikbinning = 24
jpsikplotname = "jpsik"
kmumubinning = 24
kmumuplotname = "kmumu"
pimumubinning = 24
pimumuplotname = "pimumu"

from pars import qsqbins

def plotpimumu(all=False):
    f = ROOT.TFile("fitresults_workspace.root", "READ")

    w = f.Get("workspace0")
    w.Print()
    #components
    var = w.var("B_M")
    tot = w.pdf("pimumupdf")
    sig = w.pdf("jpsiksigpdf")
    bkg = w.pdf("pimumuexppdf")
    misidpdf = w.pdf("misID")
    semipdf = w.pdf("semilepbkgexpgausspdf")
    rhopdf = w.pdf("rhokeyspdf")
    fzpdf = w.pdf("f0keyspdf")
    data = w.data("pimumudata")

    pdfs = [sig, misidpdf, semipdf, rhopdf, fzpdf, bkg]
    names = []
    colours = [ROOT.kBlue+2, ROOT.kMagenta+2, ROOT.kGreen+3, ROOT.kOrange+2,
              ROOT.kCyan+2, ROOT.kRed+2]
    styles = [3004, 3005, 3004, 3005, 3004, 3005]
    name = ""

    pdfs = pdfs[::-1]

    for pdf in pdfs:
        if len(name) > 0 :
            name += "," + pdf.GetName()
        else:
            name += pdf.GetName()
        names += [name]
        print name

    
    names = names[::-1]

    can = ROOT.TCanvas("c", "", 800, 600)
    var.SetTitle("#it{m}(#pi^{+}#mu^{+}#mu^{-})")
    var.setUnit("MeV/#it{c}^{2}")
    var.Print()
    p = var.frame()
    data.plotOn(p, RooFit.Binning(pimumubinning))
    for n, c, s in zip(names, colours, styles):
        tot.plotOn(p, RooFit.Components(n),
                   RooFit.DrawOption("F"),
                   RooFit.FillColor(ROOT.kWhite),
                  )
        tot.plotOn(p, RooFit.Components(n),
                   RooFit.DrawOption("F"),
                   RooFit.FillColor(c),
                   #RooFit.FillStyle(s),
                  )

    #tot.plotOn(p,
    #        RooFit.LineColor(ROOT.kBlue+2)
    #        )
    data.plotOn(p, RooFit.Binning(pimumubinning))
    ytitle = p.GetYaxis().GetTitle()
    ytitle = ytitle.replace('Events', 'Candidates')
    p.SetYTitle(ytitle)
    #p.SetMinimum(1)
    #c.SetLogy()
    p.Draw()
    printLHCb("R")
    can.SaveAs(pimumuplotname+".pdf")
    if all:
        can.SaveAs(pimumuplotname+".eps")
        can.SaveAs(pimumuplotname+".png")
        can.SaveAs(pimumuplotname+".C")
    f.Close()




def plotkmumu(all=False):
    f = ROOT.TFile("fitresults_workspace.root", "READ")
    w = f.Get("workspace0")
    w.Print()
    #components
    var = w.var("B_M")
    tot = w.pdf("kmumupdf")
    sig = w.pdf("jpsiksigpdf")
    bkg = w.pdf("kmumuexppdf")
    part = w.pdf("kmumu_prbkgexpgausspdf") 
    data = w.data("kmumudata")

    c = ROOT.TCanvas("c", "", 800, 600)
    var.SetTitle("#it{m}(#it{K}^{+}#mu^{+}#mu^{-})")
    var.setUnit("MeV/#it{c}^{2}")
    var.Print()
    p = var.frame()
    data.plotOn(p, RooFit.Binning(kmumubinning))
    tot.plotOn(p,
               RooFit.DrawOption("F"),
               RooFit.FillColor(ROOT.kBlue+2)
              )
    tot.plotOn(p, RooFit.Components(part.GetName()+","+bkg.GetName()),
               RooFit.DrawOption("F"),
               RooFit.FillColor(ROOT.kGreen+3)
              )
    tot.plotOn(p, RooFit.Components(bkg.GetName()),
               RooFit.DrawOption("F"),
               RooFit.FillColor(ROOT.kRed+2)
              )

    data.plotOn(p, RooFit.Binning(kmumubinning))
    #p.SetMinimum(1)
    #c.SetLogy()
    ytitle = p.GetYaxis().GetTitle()
    ytitle = ytitle.replace('Events', 'Candidates')
    p.SetYTitle(ytitle)
    p.Draw()
    printLHCb("R")
    c.SaveAs(kmumuplotname+".pdf")
    if all:
        c.SaveAs(kmumuplotname+".eps")
        c.SaveAs(kmumuplotname+".png")
        c.SaveAs(kmumuplotname+".C")
    f.Close()

def plotjpsik(all=False):
    #jpsik
    f = ROOT.TFile("jpsikmassfit.root", "READ")
    w = f.Get("jpsikworkspace")
    w.Print()

    #components
    var = w.var("B_M")
    tot = w.pdf("totpdf")
    sig = w.pdf("jpsiksigpdf")
    bkg = w.pdf("jpsikexppdf")
    part = w.pdf("jpsikbkgexpgausspdf") 
    data = w.data("jpsikdata")

    c = ROOT.TCanvas("c", "", 800, 600)
    var.SetTitle("#it{m}(#it{K}^{+}#mu^{+}#mu^{-})")
    var.setUnit("MeV/#it{c}^{2}")
    var.Print()
    p = var.frame(RooFit.Range("fit_kmumu"))
    data.plotOn(p, RooFit.Binning(jpsikbinning))
    tot.plotOn(p,
               RooFit.DrawOption("F"),
               RooFit.FillColor(ROOT.kBlue+2)
              )
    tot.plotOn(p, RooFit.Components(part.GetName()+","+bkg.GetName()),
               RooFit.DrawOption("F"),
               RooFit.FillColor(ROOT.kGreen+3)
              )
    tot.plotOn(p, RooFit.Components(bkg.GetName()),
               RooFit.DrawOption("F"),
               RooFit.FillColor(ROOT.kRed+2)
              )

    #p.SetMinimum(1)
    ytitle = p.GetYaxis().GetTitle()
    ytitle = ytitle.replace('Events', 'Candidates')
    p.SetYTitle(ytitle)
    #c.SetLogy()
    data.plotOn(p, RooFit.Binning(jpsikbinning))
    p.Draw()
    printLHCb("R")
    c.SaveAs(jpsikplotname+".pdf")
    if all:
        c.SaveAs(jpsikplotname+".eps")
        c.SaveAs(jpsikplotname+".png")
        c.SaveAs(jpsikplotname+".C")
    f.Close()


if __name__ == '__main__':
    ROOT.gROOT.SetBatch(True)
    from lhcbStyle import setLHCbStyle, printLHCb
    ROOT.gROOT.LoadMacro("RooExpAndGauss.cpp+")
    l = setLHCbStyle()
    #publication plots
    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument("-a", "--all", dest="all", action="store_true",
                        default=False, help="all")
    parser.add_argument("-j", "--jpsik", dest="jpsik",
                        action="store_true")
    parser.add_argument("-k", "--kmumu", dest="kmumu",
                        action="store_true")
    parser.add_argument("-p", "--pimumu", dest="pimumu",
                        action="store_true")
    parser.add_argument("-t", "--two", dest="two",
                        action="store_true")
    options = parser.parse_args()

    #two dimensional pimumu dataset
    if options.two:
        plottwod(options.all)
    if options.jpsik:
        plotjpsik(options.all)
    if options.kmumu:
        plotkmumu(options.all)
    if options.pimumu:
        plotpimumu(options.all)
    #kmumu

    #total fit range
