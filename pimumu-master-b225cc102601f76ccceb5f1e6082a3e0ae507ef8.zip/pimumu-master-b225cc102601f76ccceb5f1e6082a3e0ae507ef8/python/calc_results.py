#! /usr/bin/env python

from value import Value

mass_min = 5040
mass_mid = 5175
mass_max = 7000

from pars import qsqbins

import pandas as pd

def read_effs(filename='effs.txt', header=False):
    if header:
        df = pd.read_csv(filename, sep='\t')
    else:
        df = pd.read_csv(filename, sep='\t', header=None)
    return df

import numpy as np


import ipdb

#ALI
theory_bins = [(0.05, 2.0), (2, 4.3), (4.3, 8.68), (10.09, 12.86),
               (14.18, 16.), (16, 18), (18, 22), (22, 26.4)]
theory_xvals = []
theory_xerrs = []
for bin in theory_bins:
    qsqlow, qsqhigh = bin
    theory_xvals += [0.5*(qsqhigh+qsqlow)]
    theory_xerrs += [0.5*(qsqhigh-qsqlow)]

theory_xvals = np.array(theory_xvals)
theory_xerrs = np.array(theory_xerrs)


theorybrvals = np.array([0.15, 0.19, 0.37, 0.25, 0.15, 0.15, 0.25, 0.13]) * 10
theorybrerrsup = np.array([0.03, 0.03, 0.06, 0.04, 0.03, 0.03, 0.04, 0.02]) * 10
theorybrerrsdo = np.array([0.02, 0.02, 0.04, 0.03, 0.02, 0.02, 0.03, 0.02]) * 10

#divide by bin width
theorybrvals /= (2*theory_xerrs)
theorybrerrsup /= (2*theory_xerrs)
theorybrerrsdo /= (2*theory_xerrs)


theory_bins2 = [(0.05, 2.0), (2, 4.3), (4.3, 8.68), (10.09, 12.86),
               (14.18, 16.), (16, 18), (18, 22), (22, 26.4)]

theory_xvals2 = []
theory_xerrs2 = []
for bin in theory_bins:
    qsqlow, qsqhigh = bin
    theory_xvals2 += [0.5*(qsqhigh+qsqlow)]
    theory_xerrs2 += [0.5*(qsqhigh-qsqlow)]
theory_xvals2 = np.array(theory_xvals2)
theory_xerrs2 = np.array(theory_xerrs2)
theorybrvals2 = np.array([0.18, 0.22, 0.43, 0.29, 0.19, 0.20, 0.32, 0.16])*10
theorybrerrsup2 = np.array([0.02, 0.02, 0.04, 0.03, 0.02, 0.02, 0.05, 0.05])*10
theorybrerrsdo2 = np.array([0.02, 0.02, 0.03, 0.03, 0.01, 0.02, 0.04, 0.04])*10

kmumubinslow = np.array([0.1, 1.1, 2, 3, 4, 5, 6, 7, 11, 11.8, 15, 16, 17, 18, 19, 20, 21])
kmumubinshigh = np.array([0.98, 2, 3, 4, 5, 6, 7, 8, 11.8, 12.5, 16, 17, 18, 19, 20, 21, 22])
kmumu_xvals2 = []
kmumu_xerrs2 = []
for qsqlow, qsqhigh in zip(kmumubinslow, kmumubinshigh):
    kmumu_xvals2 += [0.5*(qsqhigh+qsqlow)]
    kmumu_xerrs2 += [0.5*(qsqhigh-qsqlow)]
kmumubrvals2 = np.array([33.2, 23.3, 28.2, 25.4, 22.1, 23.1, 24.5, 23.1,
                17.7, 19.3, 16.1, 16.4, 20.6, 13.7, 7.4, 5.9, 4.3])
kmumubrerrs2 = np.array([1.8, 1.5, 1.6, 1.5, 1.4, 1.4, 1.4, 1.4, 1.3,
               1.2, 1.0, 1.0, 1.1, 1.0, 0.8, 0.7, 0.7])



import time
import ROOT

def legend():
    from ROOT import TPaveText
    lhcbName = TPaveText(0.75, 0.75, 0.90, 0.85, "BRNDC")
    lhcbName.AddText("LHCb")
    lhcbName.SetFillColor(0)
    lhcbName.SetBorderSize(0)
    lhcbName.Draw()
    return lhcbName



def calc_qsq_bin_res(options, filename="fitresults_workspace.root"):
    ROOT.gROOT.LoadMacro("RooExpAndGauss.cpp+")
    y_jpsik = RooRealVar("njpsik", "", 0, 1E6)
    y_kmumu = RooRealVar("nkmumu", "", 0, 1E5)
    y_pimumu = RooRealVar("npimumu", "", 0, 1E4)

    #efficiency in qsq bins for each decay in percent!
    ejpi = RooRealVar("ejpi", "ejpsiktopi", 0, 10)
    ejk = RooRealVar("ejk", "ejpsiktok", 0, 10)
    ekpi = RooRealVar("ekpi", "ekmumutopimumu", 0, 10)
    brjpsik = RooRealVar("brjpsik", "brjpsik", 6.120E-5)
    brjpsik.setError(0.19E-5)
 
    ratio_pij = RooFormulaVar("ratio_pij", "(@0*@1)/(@2)",
                              RooArgList(y_pimumu, ejpi, y_jpsik)
                             )
    brpimumu = RooFormulaVar("brpimumu", "@0*@1",
                             RooArgList(ratio_pij, brjpsik)
                            )
    ratio_kj = RooFormulaVar("ratio_kj", "(@0*@1)/(@2)",
                             RooArgList(y_kmumu, ejk, y_jpsik)
                            )
    brkmumu = RooFormulaVar("brkmumu", "@0*@1",
                            RooArgList(ratio_kj, brjpsik)
                           )

    ratio_pik = RooFormulaVar("ratio", "(@0*@1/@2)",
                              RooArgList(y_pimumu, ekpi, y_kmumu))


    #get jpsi from workspace
    wfj = ROOT.TFile("jpsikmassfit.root", "READ")
    wsj = wfj.Get("jpsikworkspace")
    nj = wsj.var("njpsik")
    y_jpsik.setVal(nj.getVal())
    y_jpsik.setError(nj.getError())

    #dataframe containing effs
    if True:
        df = read_effs("efficiencyList_pidcalib.txt", True)
        print df
        #ipdb.set_trace()
        #ratio_pimumu = df[0].tolist()
        #errs_pimumu = df[1].tolist()
        #ratio_kmumu = df[2].tolist()
        #errs_kmumu = df[3].tolist()
        ratio_kpi = df["kmmpimmEff"].tolist()
        errs_kpi = df["kmmpimmErr"].tolist()
        ratio_jpi = df["jpsikpimmEff"].tolist()
        errs_jpi = df["jpsikpimmErr"].tolist()
        ratio_jk = df["jpsikkmmEff"].tolist()
        errs_jk = df["jpsikkmmErr"].tolist()

    if False:
        df = read_effs('effs.txt', False)
        print df
        ratio_kpi = df[0].tolist()
        errs_kpi = df[1].tolist()
        ratio_jpi = df[2].tolist()
        errs_jpi = df[3].tolist()
        ratio_jk = df[4].tolist()
        errs_jk = df[5].tolist()



    xvals = []
    xerrs = []
    pimumuvals = []
    pimumuerrs = []
    kmumuvals = []
    kmumuerrs = []
    ratiovals = []
    ratioerrs = []

    qsqscale = 1.34

    qsqmins = []
    qsqmaxs = []
    piyvals = []
    piyerrs = []
    kyvals = []
    kyerrs = []

    pimumubrs = []
    kmumubrs = []
    bins = []

    wf = ROOT.TFile(filename, "READ")
    of1 = open('results.tex', 'w')
    of2 = open('yields.tex', 'w')

    for i, qsqbin in enumerate(qsqbins):
        bins += [i]
        qsqmin, qsqmax = qsqbin
        xerrs += [0.5 * (qsqmax - qsqmin)]
        xvals += [0.5 * (qsqmax + qsqmin)]
        #open workspace
        ws = wf.Get("workspace"+str(i))
        #ws.Print()
        res = wf.Get("fitresult_simpdf"+str(i)+"_combdata"+str(i))
        #print wf, ws
        #ws.Print("v")
        #get vars
        npimumu = ws.var("npimumu")
        nkmumu = ws.var("nkmumu")
        #print npimumu, nkmumu, njpsik
        y_pimumu.setVal(npimumu.getVal())
        y_kmumu.setVal(nkmumu.getVal())
        y_pimumu.setError(npimumu.getError())
        y_kmumu.setError(nkmumu.getError())
        #assing vlaues
        #calc results

        #calc roo formula vars
        ekpi.setVal(ratio_kpi[i])
        ekpi.setError(errs_kpi[i])
        ejpi.setVal(ratio_jpi[i])
        ejpi.setError(errs_jpi[i])
        ejk.setVal(ratio_jk[i])
        ejk.setError(errs_jk[i])
        #print qsqmin, qsqmax
        npimumu.Print() 
        nkmumu.Print() 
        pimmscale = 1E9 / (qsqmax-qsqmin)
        kmmscale = 1E9 / (qsqmax-qsqmin)
        if i == 0:
            pimmscale = 1E9 / ((8-0.1)+(12.5-11)+(25-15)) #/ 1.360
            kmmscale = 1E9 / ((8-0.1)+(12.5-11)+(22-15)) #/ 1.412
        #print "BR", brkmumu.getVal() , "+/-", brkmumu.getPropagatedError(res)
        #print "Kmumu dBR/dqsq", brkmumu.getVal() * kmmscale, "+/-", brkmumu.getPropagatedError(res) * kmmscale
        #print "BR", brpimumu.getVal(), "+/-", brpimumu.getPropagatedError(res)
        #print "pimumu dBR/dqsq", brpimumu.getVal() * pimmscale, "+/-", brpimumu.getPropagatedError(res) * pimmscale


        pimumuvals += [brpimumu.getVal() * pimmscale]
        pimumuerrs += [brpimumu.getPropagatedError(res) * pimmscale]
        kmumuvals += [brkmumu.getVal() * kmmscale]
        kmumuerrs += [brkmumu.getPropagatedError(res)* kmmscale]
        ratiovals += [ratio_pik.getVal()]
        ratioerrs += [ratio_pik.getPropagatedError(res)]
        qsqmins += [qsqmin]
        qsqmaxs += [qsqmax]
        piyvals += [y_pimumu.getVal()]
        piyerrs += [y_pimumu.getError()]
        kyvals += [y_kmumu.getVal()]
        kyerrs += [y_kmumu.getError()]

        line = "%s&\t%s&\t$%.3g\\pm%.3g$&\t$%.3g\\pm%.3g$\\\\\n" % (qsqmin, qsqmax,
                            pimumuvals[i],
                            pimumuerrs[i],
                            kmumuvals[i],
                            kmumuerrs[i]
                            )
        of1.write(line)
        line = "%s&\t%s&\t$%.3g\\pm%.3g$&\t$%.3g\\pm%.3g$\\\\\n" % (qsqmin, qsqmax,
                            piyvals[i],
                            piyerrs[i],
                            kyvals[i],
                            kyerrs[i]
                           )
        of2.write(line)


    of1.write(line)

    of1.close()
    of2.close()

    df['bin'] = bins
    df['piv'] = pimumuvals
    df['pie'] = pimumuerrs
    df['kv'] = kmumuvals
    df['ke'] = kmumuerrs
    df['rv'] = ratiovals
    df['re'] = ratioerrs
    df['qsqmin'] = qsqmins
    df['qsqmax'] = qsqmaxs
    df['piyv'] = piyvals
    df['piye'] = piyerrs
    df['kyv'] = kyvals
    df['kye'] = kyerrs


    #write output file

    return df



def plots(df, options, ext):
    pimumuvals = df['piv']
    pimumuerrs = df['pie']
    kmumuvals = df['kv']
    kmumuerrs = df['ke']
    ratiovals = df['rv']
    ratioerrs = df['re']
    qsqmins = df['qsqmin']
    qsqmaxs = df['qsqmax']
    piyvals = df['piyv']
    piyerrs = df['piye']
    kyvals = df['kyv']
    kyerrs = df['kye']

    xvals = []
    xerrs = []

    for qsqbin in qsqbins:
        qsqmin, qsqmax = qsqbin
        xerrs += [0.5 * (qsqmax - qsqmin)]
        xvals += [0.5 * (qsqmax + qsqmin)]


    #plot
    from ROOT import TGraphErrors, TGraphAsymmErrors
    import array
    gr_pi = TGraphErrors(len(xvals[1:-2]),
                         array.array('f', xvals[1:-2]),
                         array.array('f', pimumuvals[1:-2]),
                         array.array('f', xerrs[1:-2]),
                         array.array('f', pimumuerrs[1:-2])
                        )

    gr_pi_2 = TGraphErrors(len(xvals[-2:]),
             array.array('d', xvals[-2:]),
             array.array('d', pimumuvals[-2:]),
             array.array('d', xerrs[-2:]),
             array.array('d', pimumuerrs[-2:])
                        )

    gr_pi_3 = TGraphErrors(len(xvals[:1]),
             array.array('d', xvals[:1]),
             array.array('d', pimumuvals[:1]),
             array.array('d', xerrs[:1]),
             array.array('d', pimumuerrs[:1])
                        )
    
    gr_pi_th = TGraphAsymmErrors(len(theory_xvals),
                        array.array('d', theory_xvals),
                        array.array('d', theorybrvals),
                        array.array('d', theory_xerrs),
                        array.array('d', theory_xerrs),
                        array.array('d', theorybrerrsup),
                        array.array('d', theorybrerrsdo)
                                )

    gr_pi_th2 = TGraphAsymmErrors(len(theory_xvals2),
                        array.array('d', theory_xvals2),
                        array.array('d', theorybrvals2),
                        array.array('d', theory_xerrs2),
                        array.array('d', theory_xerrs2),
                        array.array('d', theorybrerrsup2),
                        array.array('d', theorybrerrsdo2)
                                 )


    gr_k = TGraphErrors(len(xvals[1:-2]),
                        array.array('d', xvals[1:-2]),
                        array.array('d', kmumuvals[1:-2]),
                        array.array('d', xerrs[1:-2]),
                        array.array('d', kmumuerrs[1:-2])
                       )

    gr_k_lhcb = TGraphErrors(len(kmumu_xvals2),
                        array.array('d', kmumu_xvals2),
                        array.array('d', kmumubrvals2),
                        array.array('d', kmumu_xerrs2),
                        array.array('d', kmumubrerrs2)
                            )

    gr_r = TGraphErrors(len(xvals[1:-2]),
                        array.array('d', xvals[1:-2]),
                        array.array('d', ratiovals[1:-2]),
                        array.array('d', xerrs[1:-2]),
                        array.array('d', ratioerrs[1:-2])
                       )
    gr_pi_2.SetLineColor(ROOT.kRed)
    gr_pi_2.SetMarkerColor(ROOT.kRed)
    gr_pi_3.SetLineColor(ROOT.kBlue)
    gr_pi_3.SetMarkerColor(ROOT.kBlue)

    gr_k_lhcb.SetLineColor(ROOT.kBlue)
    gr_k_lhcb.SetMarkerColor(ROOT.kBlue)
    #lhcb results
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()
    ROOT.gStyle.SetPadRightMargin(0.05)
    lhcbName1 = ROOT.TLatex()
    lhcbName1.SetTextSize(0.04)
    c = ROOT.TCanvas("c", "", 800, 600)
    c.SaveAs("dbr_results"+ext+".pdf[")
    h = ROOT.TH1D("h", "", 1, 0, 27)
    h.GetYaxis().SetRangeUser(0, 4)
    h.GetXaxis().SetTitle("#it{q}^{2} [GeV^{2}/#it{c}^{4}]")
    h.GetYaxis().SetTitle("dB/dq^{2} [10^{-9}]")
    h.Draw()
    gr_pi_th.SetFillColor(ROOT.kMagenta+2)
    gr_pi_th.Draw("2")
    gr_pi_3.Draw("p")
    gr_pi_2.Draw("p")
    gr_pi.Draw("p")
    #lhcbName1.DrawLatex(10, 0.12, "B\\rightarrow #pi^{+}#mu^{+}#mu^{-}")
    c.SaveAs("dbr_results"+ext+".pdf")
    h.Draw()
    gr_pi_th2.SetFillColor(ROOT.kMagenta+2)
    gr_pi_th2.Draw("2")
    gr_pi_3.Draw("p")
    gr_pi_2.Draw("p")
    gr_pi.Draw("p")
    #lhcbName1.DrawLatex(10, 0.12, "B\\rightarrow #pi^{+}#mu^{+}#mu^{-}")
    c.SaveAs("dbr_results"+ext+".pdf")
    h.GetYaxis().SetTitle("dB/dq^{2} [10^{-9}]")
    h.GetYaxis().SetRangeUser(0, 100)
    h.Draw()
    gr_k.Draw("p")
    gr_k_lhcb.Draw("p")
    c.SaveAs("dbr_results"+ext+".pdf")
    h.GetYaxis().SetTitle("R_{#pi/K}")
    h.GetYaxis().SetRangeUser(0, 0.1)
    h.Draw()
    gr_r.Draw("p")
    c.SaveAs("dbr_results"+ext+".pdf")
    c.SaveAs("dbr_results"+ext+".pdf]")


def process(options):
    ext = options.filename[:-5][20:]
    print ext

    df = calc_qsq_bin_res(options, options.filename)

    if options.plots:
        plots(df, options, ext)


    #print df

    print len(qsqbins)


    f = open("results"+ext+".txt", 'w')
    line = "%.1f\t%.1f\t%.1f\t%.1f\t%.3f\t%.3f\t%.1f\t%.1f\t%.3f\t%.3f\n"
    for index, row in df.iterrows():
        fline = line % (row['qsqmin'], row['qsqmax'], 
                        row['piyv'], row['piye'], row['piv'], row['pie'],
                        row['kyv'], row['kye'], row['kv'], row['ke']
                        )
        f.write(fline)
    f.close()

    f = open("results"+ext+".data", 'w')
    df.to_csv(f, sep='\t')
    f.close()


def branchingfraction(options):

    df = pd.read_csv("results_with_sys_tot.data", sep='\t', index_col='bin')

    fpi = 1.360
    fk = 1.39
    pidqsq = 7.9+1.5+10
    kdqsq = 7.9+1.5+7


    print "total BR"
    brv = df['piv'][0] * fpi * pidqsq 
    bre = df['pie'][0] * fpi * pidqsq
    brs = df['pisysup'][0] * fpi * pidqsq
    line1 = "%.3f \\pm %.3f \\pm %.3f " % (brv, bre, brs)
    print "pimumu", line1
    brv = df['kv'][0] * fk * kdqsq
    bre = df['ke'][0] * fk * kdqsq
    brs = df['ksysup'][0] * fk * kdqsq
    line2 = "%.3f \\pm %.3f \\pm %.3f " % (brv, bre, brs)
    print "kmumu", line2
    brv = df['rv'][0] * (fpi/fk) * (pidqsq/kdqsq) * 1E2 
    bre = df['re'][0] * (fpi/fk) * 1E2
    brs = df['rsysup'][0] * (fpi/fk) * (pidqsq/kdqsq) * 1E2
    line3 = "%.3f \\pm %.3f \\pm %.3f " % (brv, bre, brs)
    print "ratio", line3 , "x10^-2"

    f = open("branchingfraction.data", 'w' )
    f.write(line1+"\n")
    f.write(line2+"\n")
    f.write(line3+"\n")
    f.close()



def compare(options):
    df4 = pd.read_csv("results.data", sep='\t', index_col='bin')
    df3 = pd.read_csv("results_bdt05_kpid045.data", sep='\t')
    df5 = pd.read_csv("results_bdt05_kpid035.data", sep='\t')
    pass 
    xvals = []
    xerrs = []

    for qsqbin in qsqbins:
        qsqmin, qsqmax = qsqbin
        xerrs += [0.5 * (qsqmax - qsqmin)]
        xvals += [0.5 * (qsqmax + qsqmin)]

    xvals = xvals[1:-2]
    xerrs = xerrs[1:-2]

    print xvals, xerrs
    dbr4vals = df4['piyv'].tolist()[1:-2]
    dbr4errs = df4['piye'].tolist()[1:-2]
    dbr5vals = df5['piyv'].tolist()[1:-2]
    dbr5errs = df5['piye'].tolist()[1:-2]
    dbr3vals = df3['piyv'].tolist()[1:-2]
    dbr3errs = df3['piye'].tolist()[1:-2]
    print dbr4vals, dbr4errs
    import array
    c = ROOT.TCanvas("c", "", 800, 600)
    g4 = ROOT.TGraphErrors(len(xvals),
                           array.array('d', xvals),
                           array.array('d', dbr4vals),
                           array.array('d', xerrs),
                           array.array('d', dbr4errs)
                          )
    g5 = ROOT.TGraphErrors(len(xvals),
                           array.array('d', xvals),
                           array.array('d', dbr5vals),
                           array.array('d', xerrs),
                           array.array('d', dbr5errs)
                          )
    g3 = ROOT.TGraphErrors(len(xvals),
                           array.array('d', xvals),
                           array.array('d', dbr3vals),
                           array.array('d', xerrs),
                           array.array('d', dbr3errs)
                          )

    g4.SetLineColor(ROOT.kBlack)
    g4.SetMarkerColor(ROOT.kBlack)
    g5.SetLineColor(ROOT.kBlue)
    g5.SetMarkerColor(ROOT.kBlue)
    g3.SetLineColor(ROOT.kMagenta+2)
    g3.SetMarkerColor(ROOT.kMagenta+2)

    h = ROOT.TH1D("h", "", 1, 0, 27)
    h.GetYaxis().SetRangeUser(0, 40)
    h.GetXaxis().SetTitle("#it{q}^{2} [GeV^{2}/#it{c}^{4}]")
    h.GetYaxis().SetTitle("dB/dq^{2} [10^{-9}]")
    h.Draw()
    g4.Draw("p")
    g5.Draw("p")
    g3.Draw("p")
    c.SaveAs("comppid.pdf")


def systematics(options, sysnames, sysvals, ext):
    #load central value dataframe
    from pandas import read_csv, Series
    cendf = read_csv("results.data", sep='\t', index_col='bin')
    #for each systematic, calculate difference
    #print
    #calculate systematics and write TEX tables
    cendf[ext+'sysup'] = np.zeros(len(qsqbins))
    cendf[ext+'sysdo'] = np.zeros(len(qsqbins))

    for sys, sysval in zip(sysnames, sysvals):
        print sys, sysval
        cendf[ext+'sysup'] += sysval
        cendf[ext+'sysdo'] += sysval

    #ipdb.set_trace()
    cendf[ext+'sysup'] = np.sqrt(cendf[ext+'sysup'].tolist()) * cendf[ext+'v'] / 100.0 
    cendf[ext+'sysdo'] = np.sqrt(cendf[ext+'sysdo'].tolist()) * cendf[ext+'v'] / 100.0
    lines = []
    print ext
    for i in range(len(qsqbins)):
        line = "%.1f & %.1f & %.3f \\pm %.3f \\pm^{ %.3f }_{ %.3f }" % \
                (cendf['qsqmin'][i], cendf['qsqmax'][i], cendf[ext+'v'][i], \
                 cendf[ext+'e'][i], cendf[ext+'sysup'][i], cendf[ext+'sysdo'][i])
        lines += [line]


    f = open("results_with_sys_"+ext+".tex", 'w')
    for line in lines:
        f.write(line + '\n')
    f.close()
    f = open("results_with_sys_"+ext+".data", 'w')
    cendf.to_csv(f, sep='\t')
    f.close()


def allsystematics(options, extdict, sysnames):
    #load central value dataframe
    from pandas import read_csv, Series
    cendf = read_csv("results.data", sep='\t', index_col='bin')
    #for each systematic, calculate difference
    #print
    #calculate systematics and write TEX tables
    for ext, sysvals in extdict.iteritems():
        cendf[ext+'sysup'] = np.zeros(len(qsqbins))
        cendf[ext+'sysdo'] = np.zeros(len(qsqbins))
        for sys, sysval in zip(sysnames, sysvals):
            cendf[ext+'sysup'] += sysval
            cendf[ext+'sysdo'] += sysval
        cendf[ext+'sysup'] = np.sqrt(cendf[ext+'sysup'].tolist()) * cendf[ext+'v'] / 100.0 
        cendf[ext+'sysdo'] = np.sqrt(cendf[ext+'sysdo'].tolist()) * cendf[ext+'v'] / 100.0
        lines = []

    #print cendf

    for i in range(len(qsqbins)):
        line = "%.1f & %.1f " % (cendf['qsqmin'][i], cendf['qsqmax'][i])
        line += "&$ %.3f \\pm %.3f \\pm %.3f $" % \
                (cendf['piv'][i], cendf['pie'][i], cendf['pisysup'][i])
        line += "&$ %.3f \\pm %.3f \\pm %.3f $" % \
                (cendf['kv'][i], cendf['ke'][i], cendf['ksysup'][i])
        line += "&$ %.3f \\pm %.3f \\pm %.3f $" % \
                (cendf['rv'][i], cendf['re'][i], cendf['rsysup'][i])
        lines += [line]


    f = open("results_with_sys_tot.tex", 'w')
    for line in lines:
        f.write(line + '\n')
    f.close()
    f = open("results_with_sys_tot.data", 'w')
    cendf.to_csv(f, sep='\t')
    f.close()





if __name__ == '__main__':
    start = time.time()
    print time.asctime(time.localtime())
    ROOT.gROOT.SetBatch(True)
    from ROOT import RooMsgService, RooArgList, RooFit
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()

    from argparse import ArgumentParser

    parser = ArgumentParser()
    parser.add_argument("-d", "--debug", dest="debug", action="store_true",
                        default=False, help="testing")
    parser.add_argument("-t", "--total", dest="total", action="store_true",
                        default=False, help="testing")
    parser.add_argument("-v", "--plots", dest="plots", action="store_true",
                        default=False, help="testing")
    parser.add_argument("-f", "--filename", dest="filename", type=str,
                        default="fitresults_workspace.root", help="testing")
    parser.add_argument("-s", "--sys", dest="sys", action='store_true',
                        default=False, help="testing")
    parser.add_argument("-p", "--process", dest="process", action='store_true',
                        default=False, help="testing")
    parser.add_argument("-c", "--compare", dest="compare", action='store_true',
                        default=False, help="testing")
    parser.add_argument("-b", "--br", dest="br", action='store_true',
                        default=False, help="testing")
    options = parser.parse_args()

    if not options.debug:
        RooMsgService.instance().setGlobalKillBelow(RooFit.WARNING)
        RooMsgService.instance().setSilentMode(True)
    from ROOT import RooFormulaVar, RooRealVar

    if options.process:
        process(options)
    if options.compare:
        compare(options)
    if options.br:
        branchingfraction(options)

    sysnames = ['sysrho', 'sysfz', 'syssl', 'sysk', 'sysm', 'sysmis'] + \
               ['sysgen', 'syshpid', 'sysmpid', 'sysbdt', 'systrig']
    pisysvals = [0.6, 0.07, 0.3, 0, 0.6, 0.3, 0.05] + \
               [0.3, 2.0, 0.02, 1.4, 2]
    ksysvals = [0.6, 0.07, 0.3, 0, 0.6, 0.3, 0.05] + \
               [0.3, 0.04, 0.04, 1.4, 2]
    rsysvals = [0.6, 0.07, 0.3, 0, 0.6, 0.3, 0.05] + \
               [0.3, 1.5, 0.06, 1.4, 2]

    if options.sys:
        systematics(options, sysnames, pisysvals, "pi")
        systematics(options, sysnames, ksysvals, "k")
        systematics(options, sysnames, rsysvals, "r")
        extdict = {}
        extdict["pi"] = pisysvals
        extdict["k"] = ksysvals
        extdict["r"] = rsysvals
        allsystematics(options, extdict, sysnames)



    end = time.time()
    print time.asctime(time.localtime())
    print "time taken", end-start


