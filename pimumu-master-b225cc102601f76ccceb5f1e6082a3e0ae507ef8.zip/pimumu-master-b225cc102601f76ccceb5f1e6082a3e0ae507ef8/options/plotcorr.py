#! /usr/bin/env python

""" GIVES RATIO OF PHASE SPACE< NO FORM FACTORS!!! """

binning_scheme = [
        (0., 2.),
        (2., 4.),
        (4., 6.),
        (6., 8.),
        (11., 12.5),
        (15., 17.),
        (17., 19.),
        (19., 22.),
        (22., 25.),
        ]

theory = [ (1., 6.) , (15., 20.) ]

value_ckm = 0.216
error_ckm = 0.0


br_kmm = 4.4E-7
er_kmm = 0.05E-7

br_kmm = 4.4E-7
er_kmm = 0.05E-7


from math import sqrt
from array import array

def create_qsq( tkmm, tpimm, bins ) : 
    xvals = []
    xerrs = []
    yvals = []
    yerrs = []
    for x, y in bins:
        cut = "(qsq>%g && qsq<%g)" % (x, y)
        print cut
        nkmm = float(tkmm.GetEntries(cut))
        npimm = float(tpimm.GetEntries(cut))
        xvals += [ 0.5*(y+x) ]
        xerrs += [ 0.5*(y-x) ]
        f = npimm / nkmm / value_ckm
        e =  f 
        e *= sqrt( 1.0/npimm + 1.0/npimm + \
                   error_ckm*error_ckm/value_ckm/value_ckm)
        yvals += [ f ]
        yerrs += [ e ]
        print xvals[-1], yvals[-1], yerrs[-1]
    g = ROOT.TGraphErrors( len(xvals) ,
                    array('d', xvals),
                    array('d', yvals),
                    array('d', xerrs),
                    array('d', yerrs)
                    )
    return g







if __name__ == '__main__' :
    #
    import ROOT
    ROOT.gROOT.SetBatch(True)
    from lhcbStyle import setLHCbStyle
    setLHCbStyle()

    kmm_num = 12113002
    f1 = ROOT.TFile( "tuple-%s.root"% kmm_num ) 
    t1 = f1.Get("MCDecayTree")
    pimm_num = 12113024
    f2 = ROOT.TFile( "tuple-%s.root"% pimm_num ) 
    t2 = f2.Get("MCDecayTree")
    g1 = create_qsq( t1, t2, binning_scheme )
    g2 = create_qsq( t1, t2, theory )
    g2.SetLineColor(4)
    g2.SetMarkerColor(4)
    g2.SetMarkerStyle(22)

    c = ROOT.TCanvas("c", "", 800, 600)
    c.SaveAs("testqsq.pdf[")
    g1.Draw("apl")
    g1.GetHistogram().GetXaxis().SetTitle("q^{2}")
    g1.GetHistogram().GetYaxis().SetTitle("B(#pi#mu#mu)/B(K#mu#mu)")
    g1.GetHistogram().GetYaxis().SetRangeUser(0, 2)
    g1.Draw("ap")
    g2.Draw("p")
    c.SaveAs("testqsq.pdf")
    c.SaveAs("testqsq.pdf]")


