import math

__author__ = "Alex Shires"

"""reading xml gen logs and processing cut efficiency"""

if __name__ == '__main__' :
    from GenXmlLogParser import GenStats, GenEfficiency
    print "pimumu"
    stat1 = GenStats('GeneratorLog_12113021.xml')
    print stat1
    result = stat1.makeGenerationResults()
    eff = result['I2'] / result['I1']
    err = math.sqrt(result['I2']*(result['I1']-result['I2'])/result['I1']**3)
    print eff, err
    stat2 = GenStats('GeneratorLog_12113024.xml')
    result = stat2.makeGenerationResults()
    print stat2
    eff = result['I2'] / result['I1']
    err = math.sqrt(result['I2']*(result['I1']-result['I2'])/result['I1']**3)
    print eff, err
    stat3 = GenStats('GeneratorLog_12113026.xml')
    print stat3
    result = stat3.makeGenerationResults()
    eff = result['I2'] / result['I1']
    err = math.sqrt(result['I2']*(result['I1']-result['I2'])/result['I1']**3)
    print eff, err


    totstat = stat1 + stat2 + stat3
    result = totstat.makeGenerationResults()
    eff = result['I2'] / result['I1']
    err = math.sqrt(result['I2']*(result['I1']-result['I2'])/result['I1']**3)
    print eff, err

    print "kmumu"

    stat1 = GenStats('GeneratorLog_12113001.xml')
    print stat1
    result = stat1.makeGenerationResults()
    eff = result['I2'] / result['I1']
    err = math.sqrt(result['I2']*(result['I1']-result['I2'])/result['I1']**3)
    print eff, err
    stat2 = GenStats('GeneratorLog_12113002.xml')
    result = stat2.makeGenerationResults()
    print stat2
    eff = result['I2'] / result['I1']
    err = math.sqrt(result['I2']*(result['I1']-result['I2'])/result['I1']**3)
    print eff, err
    stat3 = GenStats('GeneratorLog_12113003.xml')
    print stat3
    result = stat3.makeGenerationResults()
    eff = result['I2'] / result['I1']
    err = math.sqrt(result['I2']*(result['I1']-result['I2'])/result['I1']**3)
    print eff, err



