"""add qsq to ntuple"""
import ROOT
from tree import TTree
if __name__ == "__main__": 
    from argparse import ArgumentParser
    parser = ArgumentParser()
    parser.add_argument( "-d", "--dir", dest="dir", default=None
            , type=str, help="testing" ) 
    parser.add_argument( "-f", "--file", dest="filename", default="" 
            , type=str, help="filename" ) 
    parser.add_argument( "-t", "--tree", dest="treename"
            , default="DecayTree" 
            , type=str, help="treename" ) 
    parser.add_argument( "-e", "--elec", dest="elec", default=False,
            action='store_true' ) 

    options = parser.parse_args()
    f = ROOT.TFile( options.filename, "UPDATE" )
    t = f.Get( options.treename ) 
    res_tuple = {}
    n = t.GetEntries()
    print "processing ", n 
    for i in range(n) :
        if n > 10 :
            if (i % (n/10)  )== 0        :
                print "processed %g" % i
        t.GetEntry(i)
        if options.elec :
            qsq = ( (t.eminus_TRUEP_E+t.eplus_TRUEP_E)**2 \
            - (t.eminus_TRUEP_X+t.eplus_TRUEP_X)**2 \
            - (t.eminus_TRUEP_Y+t.eplus_TRUEP_Y)**2 \
            - (t.eminus_TRUEP_Z+t.eplus_TRUEP_Z)**2 ) / 1E6
        else :
            qsq = ( (t.muminus_TRUEP_E+t.muplus_TRUEP_E)**2 \
            - (t.muminus_TRUEP_X+t.muplus_TRUEP_X)**2 \
            - (t.muminus_TRUEP_Y+t.muplus_TRUEP_Y)**2 \
            - (t.muminus_TRUEP_Z+t.muplus_TRUEP_Z)**2 ) / 1E6
        #calc inv masses
        t.AddVar( qsq, "qsq", res_tuple )
        t.FillVars(res_tuple)
    t.Write()
    f.Close() 
