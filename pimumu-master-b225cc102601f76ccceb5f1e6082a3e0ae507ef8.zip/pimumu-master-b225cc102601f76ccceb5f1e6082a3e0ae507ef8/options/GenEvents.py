#IS THIS ALL??

from Gaudi.Configuration import *
importOptions("$GAUSSOPTS/Gauss-Job.py")
#from Gauss.Configuration import *
#--Generator phase, set random numbers
#GaussGen = GenInit("GaussGen")
#GaussGen.FirstEventNumber = 1
#GaussGen.RunNumber        = 1082

importOptions("$GAUSSOPTS/Gauss-2012.py")
#--Pick beam conditions as set in AppConfig
#from Gaudi.Configuration import *
#importOptions("$APPCONFIGOPTS/Gauss/Sim08-Beam4000GeV-md100-2012-nu2.5.py")
#--Set database tags using those for Sim08
#from Configurables import LHCbApp
#LHCbApp().DDDBtag   = "Sim08-20130503-1"
#LHCbApp().CondDBtag = "Sim08-20130503-1-vc-md100"

importOptions("$GAUSSOPTS/GenStandAlone.py")
#Gauss().Phases = ["Generator","GenToMCTree"] 
importOptions("$LBPYTHIA8ROOT/options/Pythia8.py")

from Configurables import Gauss
Gauss().Debug = False

from Configurables import LHCbApp
LHCbApp().EvtMax = 10000

from Configurables import GenInit, SimInit
GenInit("GaussGen").PrintFreq = 100
SimInit("MainEventGaussSkipGeant4").PrintFreq = 100


# todo - all BTOSLLBALL 05
#Kstmm - BTOSLLBALL
importOptions("$DECFILESROOT/options/11114001.py")

from Configurables import XmlCounterLogFile
#XmlCounterLogFile().FileName = "GeneratorLog_12113021.xml"
#importOptions("$DECFILESROOT/options/12113021.py")
#XmlCounterLogFile().FileName = "GeneratorLog_12113024.xml"
#importOptions("$DECFILESROOT/options/12113024.py")
XmlCounterLogFile().FileName = "GeneratorLog_12113026.xml"
importOptions("$DECFILESROOT/options/12113026.py")


#Kmm - BTOSLLBALL
#XmlCounterLogFile().FileName = "GeneratorLog_12113001.xml"
#importOptions("$DECFILESROOT/options/12113001.py")
#XmlCounterLogFile().FileName = "GeneratorLog_12113002.xml"
#importOptions("$DECFILESROOT/options/12113002.py")
#XmlCounterLogFile().FileName = "GeneratorLog_12113003.xml"
#importOptions("$DECFILESROOT/options/12113003.py")


