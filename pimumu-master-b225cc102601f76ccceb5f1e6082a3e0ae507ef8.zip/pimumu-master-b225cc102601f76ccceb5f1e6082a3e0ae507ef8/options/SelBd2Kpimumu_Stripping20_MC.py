from Configurables import DaVinci, DecayTreeTuple, TupleToolDecay, TupleToolTrigger, TupleToolRecoStats, TupleToolTISTOS, TupleToolDira,TupleToolKstarMuMu, GaudiSequencer, RawBankToSTClusterAlg, DeterministicPrescaler, TupleToolP2VV, TupleToolGeometry

tool_list = [
    "TupleToolPid",
    "TupleToolGeometry",
    "TupleToolKinematic",
    "TupleToolPrimaries",
    "TupleToolEventInfo",
    "TupleToolTrackInfo",
    "TupleToolDira",
    #"TupleToolRICHPid",
    "TupleToolMuonIso",
    "TupleToolKaonIso",
    "TupleToolPropertime",
    "TupleToolMCBackgroundInfo",
    "TupleToolMCTruth",
    "TupleToolTrackIsolation",
    "TupleToolTrackPosition"
]

trigger_list = [
    'L0HadronDecision',
    'L0MuonDecision',
    'L0DiMuonDecision',
    'Hlt1TrackAllL0Decision',
    'Hlt1TrackMuonDecision',
    'Hlt1MuTrackDecision',
    'Hlt2TopoOSTF2BodyDecision',
    'Hlt2TopoOSTF3BodyDecision',
    'Hlt2TopoOSTF4BodyDecision',
    'Hlt2Topo2BodySimpleDecision',
    'Hlt2Topo3BodySimpleDecision',
    'Hlt2Topo4BodySimpleDecision',
    'Hlt2Topo2BodyBBDTDecision',
    'Hlt2Topo3BodyBBDTDecision',
    'Hlt2Topo4BodyBBDTDecision',
    'Hlt2TopoMu2BodyBBDTDecision',
    'Hlt2TopoMu3BodyBBDTDecision',
    'Hlt2TopoMu4BodyBBDTDecision',
    'Hlt2SingleMuonDecision',
    'Hlt2DiMuonDetachedDecision',
    'Hlt2MuTrackDecision'
]

candidateLoc = "/Event/AllStreams/Phys/B2XMuMu_Line/Particles"

# instantiate and configure the DecayTreeTuple
kstarmumu_tuple = DecayTreeTuple()
kstarmumu_tuple.Decay = "[ B0 -> ^(K*(892)0 -> ^K+ ^pi-) ^(J/psi(1S) -> ^mu+ ^mu-)]CC"
kstarmumu_tuple.ToolList += tool_list
#kstarmumu_tuple.Inputs = [ candidateData.outputLocation()  ] 
kstarmumu_tuple.Inputs = [ candidateLoc  ] 

kstarmumu_tuple.addTool(TupleToolRecoStats, name = "TupleToolRecoStats")
kstarmumu_tuple.TupleToolRecoStats.Verbose = True
kstarmumu_tuple.ToolList += [ "TupleToolRecoStats" ]

kstarmumu_tuple.addTool( TupleToolGeometry, name='TupleToolGeometry' )
kstarmumu_tuple.TupleToolGeometry.Verbose = True
kstarmumu_tuple.ToolList += [ "TupleToolGeometry" ]

kstarmumu_tuple.Branches = {
    "K"       : "[ B0 -> (K*(892)0 -> ^K+ pi-) (J/psi(1S) -> mu+ mu-)]CC",
    "Pi"      : "[ B0 -> (K*(892)0 -> K+ ^pi-) (J/psi(1S) -> mu+ mu-)]CC",
    "Muplus"  : "[ B0 -> (K*(892)0 -> K+ pi-) (J/psi(1S) -> ^mu+ mu-)]CC",
    "Muminus" : "[ B0 -> (K*(892)0 -> K+ pi-) (J/psi(1S) -> mu+ ^mu-)]CC",
    "Jpsi"    : "[ B0 -> (K*(892)0 -> K+ pi-) ^(J/psi(1S) -> mu+ mu-)]CC",
    "Kstar"   : "[ B0 -> ^(K*(892)0 -> K+ pi-) (J/psi(1S) -> mu+ mu-)]CC",
    "B0" : "[^(B0 -> (K*(892)0 -> K+ pi-) (J/psi(1S) -> mu+ mu-))]CC"
}

kstarmumu_tuple.addTool( TupleToolDecay, name="Muplus" )
kstarmumu_tuple.Muplus.ToolList += [ "TupleToolMuonInfo" ]
kstarmumu_tuple.addTool( TupleToolDecay, name="Muminus" )
kstarmumu_tuple.Muminus.ToolList += [ "TupleToolMuonInfo" ]
kstarmumu_tuple.addTool(TupleToolDecay, name = "B0")
kstarmumu_tuple.B0.ToolList += [
    "TupleToolP2VV",
    "TupleToolVtxIsoln",
    "TupleToolKstarMuMu"]

kstarmumu_tuple.B0.addTool( TupleToolTISTOS, name='TupleToolTISTOS' )
kstarmumu_tuple.B0.TupleToolTISTOS.Verbose = True
kstarmumu_tuple.B0.TupleToolTISTOS.TriggerList = trigger_list
kstarmumu_tuple.B0.ToolList += [ "TupleToolTISTOS" ]


DaVinci().UserAlgorithms += [ kstarmumu_tuple ]

GlobalEventSeq = GaudiSequencer("GlobalEventSeq")
GlobalEventSeq.IgnoreFilterPassed = True

from Gaudi.Configuration import importOptions
importOptions("$STDOPTS/DecodeRawEvent.py") # needed to decode raw data...

createITClusters = RawBankToSTClusterAlg("CreateITClusters")
createITClusters.DetType     = "IT"
GlobalEventSeq.Members += [createITClusters]
DaVinci().UserAlgorithms += [ GlobalEventSeq]

DaVinci().TupleFile = "BKstarMuMu.root"
DaVinci().EvtMax = -1
DaVinci().DataType = '2012'
DaVinci().Simulation   = True
#DaVinci().Lumi = True
DaVinci().MainOptions  = ""

from Gaudi.Configuration import MessageSvc
MessageSvc().Format = "% F%80W%S%7W%R%T %0W%M"

DaVinci().DDDBtag   = 'Sim08-20130503-1'  ## latest strip20 tags as of Jan2013
DaVinci().CondDBtag = 'Sim08-20130503-1-vc-md100'
