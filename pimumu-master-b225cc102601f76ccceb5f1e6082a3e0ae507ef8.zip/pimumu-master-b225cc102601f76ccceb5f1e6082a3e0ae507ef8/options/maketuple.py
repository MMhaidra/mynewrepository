from Configurables import (
        DaVinci,
        EventSelector,
        PrintMCTree,
        MCDecayTreeTuple
        )
from DecayTreeTuple.Configuration import *

"""Configure the variables below with:
    decay: Decay you want to inspect, using 'newer' LoKi decay descriptor syntax,
    decay_heads: Particles you'd like to see the decay tree of,
    datafile: Where the file created by the Gauss generation phase is, and
    year: What year the MC is simulating.
    """

from DiLeptonTuple.DiLeptonTuple import Bd2eeKst, Bu2eeK, Bd2MuMuKst, Bu2MuMuK

nevts = 10000

# https://twiki.cern.ch/twiki/bin/view/LHCb/FAQ/LoKiNewDecayFinders
# Kmumu -> btosllball
decay = "[B+ => ^K+ ^mu+ ^mu- ]CC" #
decaynumber = 12113002 #BSLLBALL05
decay = "[B+ => ^pi+ ^mu+ ^mu- ]CC" #
decaynumber = 12113024 #BSLLBALL05
datafile = "Gauss-%s-%gev-20150128.xgen" % (decaynumber, nevts)






decay_heads = ["B0", "B~0", "B+", "B-"]


year = 2012

# For a quick and dirty check, you don't need to edit anything below here.
##########################################################################

# Create an MC DTT containing any candidates matching the decay descriptor
mctuple = MCDecayTreeTuple("MCDecayTreeTuple")
mctuple.Decay = decay
mctuple.ToolList = [
                "MCTupleToolHierarchy",
                "LoKi::Hybrid::MCTupleTool/LoKi_Photos"
                ]
mctuple.addTupleTool("MCTupleToolKinematic").Verbose = True
# Add a 'number of photons' branch
mctuple.addTupleTool("LoKi::Hybrid::TupleTool/LoKi_Photos").Variables = {
                            "nPhotos": "MCNINTREE(('gamma' == MCABSID))"
                            }

mctuple.addBranches( { 'B' : "^"+ decay.replace("^","") } ) 
mctuple.addTupleTool("TupleToolDecay/B")
#mctuple.B.ToolList += [ # "MCTupleToolP2VV" , 
#                       "LoKi::Hybrid::MCTupleTool/qsq"
#                       ] 
#mctuple.B.addTupleTool("MCTupleToolP2VV")
#mctuple.B.addTupleTool("LoKi::Hybrid::TupleTool/qsq").Variables = { "qsq" : "M23" }
mctuple.OutputLevel = 3

# Print the decay tree for any particle in decay_heads
printMC = PrintMCTree()
printMC.ParticleNames = decay_heads
printMC.OutputLevel = 3

# Name of the .xgen file produced by Gauss
EventSelector().Input = ["DATAFILE='{0}' TYP='POOL_ROOTTREE' Opt='READ'".format(datafile)]

DaVinci().PrintFreq = 1
# Configure DaVinci
DaVinci().TupleFile = "tuple-%s.root" % decaynumber
DaVinci().Simulation = True
DaVinci().Lumi = False
DaVinci().DataType = str(year)
DaVinci().UserAlgorithms = [
#                    printMC,
                    mctuple
                    ]
DaVinci().DDDBtag   = "Sim08-20130503-1"
DaVinci().CondDBtag = "Sim08-20130503-1-vc-md100"
DaVinci().EvtMax = -1
DaVinci().PrintFreq = 1000
