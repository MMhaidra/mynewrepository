#get stripped mc
#make nTuple

from Gaudi.Configuration import *
from PhysSelPython.Wrappers import Selection, SelectionSequence, DataOnDemand

from Configurables import ChargedProtoParticleMaker

name="pmmi"
veloprotos = ChargedProtoParticleMaker(name+"ProtoPMaker")
veloprotos.Inputs = ["Rec/Track/Best"]
veloprotos.Output = "Rec/ProtoP/myProtoPMaker/ProtoParticles"



from Gaudi.Configuration import *
from Configurables       import ProtoParticleCALOFilter, CombinedParticleMaker,NoPIDsParticleMaker

from CommonParticles.Utils import *



algorithm = NoPIDsParticleMaker('StdNoPIDsVeloPions',  Particle = 'pion',  )
algorithm.Input = "Rec/ProtoP/myProtoPMaker/ProtoParticles"
selector = trackSelector ( algorithm , trackTypes = ['Velo'] )

locations = updateDoD ( algorithm )


from Configurables import DecayTreeTuple, TupleToolRecoStats, TupleToolTrigger, TupleToolTISTOS
from DecayTreeTuple.Configuration import *
from Configurables import LoKi__Hybrid__TupleTool

# prepare to re-run the stripping (20)
from StrippingArchive.Stripping20.StrippingB2XMuMu import B2XMuMuConf
from StrippingSettings.Stripping20.LineConfigDictionaries_RD import B2XMuMu
from StrippingConf.Configuration import StrippingConf
from StrippingConf.StrippingStream import StrippingStream
from Configurables import ProcStatusCheck

# rerun the stripping if mc but remember to
# first kill the stripping banks
eventNodeKiller = EventNodeKiller('Stripkiller')
eventNodeKiller.Nodes = [ '/Event/AllStreams', '/Event/Strip' ]

# build the line
StrippingB2XMuMuConf = B2XMuMuConf("B2XMuMu", B2XMuMu['CONFIG'])
B2XMuMuLines         = StrippingB2XMuMuConf.lines()
SStream              = StrippingStream("SStream")
for line in B2XMuMuLines:
    print "INFO: Prepare to run stripping line: ", line.name()
stripline = B2XMuMuLines[0]
SStream.appendLines(B2XMuMuLines)    
# standard nonsense
filterBadEvents =  ProcStatusCheck()
sc = StrippingConf(
        Streams            = [SStream],
        MaxCandidates      = 2000,
        AcceptBadEvents    = False,
        BadEventSelection  = filterBadEvents,
        )
sc.OutputType         = "ETC" # Can be either "ETC" or "DST"

# create my tuple
tuple = DecayTreeTuple("mytuple")
tuple.Inputs = [stripline.outputLocation()]

tuple.ToolList =  [
     "TupleToolKinematic"
    , "TupleToolPrimaries"
    , "TupleToolEventInfo"
    , "TupleToolTrackInfo"
    , "TupleToolAngles"
    , "TupleToolPropertime"
    , "TupleToolRecoStats"
    , "TupleToolVtxIsoln"
    , "TupleToolMCTruth"
    , "TupleToolMCBackgroundInfo"
]
tuple.addBranches({
       "B" :       "[^(B+ -> (J/psi(1S) -> mu+ mu-) pi+)]CC"           
    ,  "hadron" :  "[B+ -> (J/psi(1S) -> mu+ mu-)  ^pi+]CC"
    ,  "muplus" :  "[B+ -> (J/psi(1S) -> ^mu+ mu-) pi+]CC"
    ,  "muminus" : "[B+ -> (J/psi(1S) -> mu+ ^mu-) pi+]CC"
    ,  "dimuon" : "[B+ -> ^(J/psi(1S) -> mu+ mu-)    pi+]CC"
})

from Configurables import TupleToolDecayTreeFitter
tuple.B.addTool(TupleToolDecayTreeFitter, name="DTF")
tuple.B.DTF.daughtersToConstrain = ['J/psi(1S)']
tuple.B.ToolList+=["TupleToolDecayTreeFitter/DTF"]



from Configurables import TupleToolApplyIsolation
tuple.B.addTool(TupleToolApplyIsolation, name="TupleToolApplyIsolationHard")
tuple.B.TupleToolApplyIsolationHard.OutputSuffix="_Hard"
tuple.B.TupleToolApplyIsolationHard.WeightsFile="weightsHard.xml"
tuple.B.ToolList+=["TupleToolApplyIsolation/TupleToolApplyIsolationHard"]

tuple.B.addTool(TupleToolApplyIsolation, name="TupleToolApplyIsolationSoft")
tuple.B.TupleToolApplyIsolationSoft.OutputSuffix="_Soft"
tuple.B.TupleToolApplyIsolationSoft.WeightsFile="weightsSoft.xml"
tuple.B.ToolList+=["TupleToolApplyIsolation/TupleToolApplyIsolationSoft"] 





from Configurables import TupleToolGeometry

tuple.addTool(TupleToolGeometry, name="TupleToolGeometry")
tuple.TupleToolGeometry.Verbose = True
#tuple.TupleToolGeometry.OutputLevel = 1
tuple.ToolList+=["TupleToolGeometry/TupleToolGeometry"]



tuple.ToolList += [ "TupleToolTISTOS" ]
tuple.addTool( TupleToolTISTOS, name = "TupleToolTISTOS" )
tuple.TupleToolTISTOS.Verbose = True

    
tuple.TupleToolTISTOS.TriggerList = [
'L0HadronDecision',
'L0MuonDecision',
'L0DiMuonDecision',


'Hlt1TrackAllL0Decision',
'Hlt1TrackMuonDecision',
'Hlt1GlobalDecision',
	
'Hlt2Topo2BodyBBDTDecision',
'Hlt2Topo3BodyBBDTDecision',
'Hlt2Topo4BodyBBDTDecision',
'Hlt2TopoMu2BodyBBDTDecision',
'Hlt2TopoMu3BodyBBDTDecision',
'Hlt2TopoMu4BodyBBDTDecision',
'Hlt2SingleMuonDecision',
'Hlt2DiMuonDecision',
'Hlt2DiMuonDetachedDecision',
'Hlt2GlobalDecision'
	
]

tuple.Decay = "[B+ -> ^(J/psi(1S) -> ^mu+ ^mu-) ^pi+]CC"
from Configurables import TupleToolPid
tuple.addTool(TupleToolGeometry, name="TupleToolPid")
tuple.TupleToolPid.Verbose = True
tuple.ToolList+=["TupleToolPid/TupleToolPid"]

from Configurables import DaVinci
DaVinci().TupleFile = "filename.root"
DaVinci().Simulation   = True
DaVinci().Lumi = True

DaVinci().DataType = '2012'
from Configurables import CondDB
CondDB.LatestGlobalTagsByDataType = "2012"

_myseq = GaudiSequencer("myseq")
_myseq.Members += [ tuple]
DaVinci().appendToMainSequence( [ eventNodeKiller ] )
DaVinci().appendToMainSequence( [ veloprotos ])
DaVinci().appendToMainSequence( [ algorithm ]) 
DaVinci().UserAlgorithms =  [sc.sequence()]+[_myseq]
DaVinci().MainOptions  = ""
